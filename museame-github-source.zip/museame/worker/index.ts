import * as collection from '../app/api/exhibits/route';
import * as exhibit from '../app/api/exhibits/[id]/route';
import * as auth from '../lib/auth';
import * as settings from '../app/api/settings/route';
import * as asset from '../app/api/assets/[id]/route';
import * as transfers from '../lib/upload-transfers';
import {setupSupabase,type LocalSetup} from '../lib/supabase-setup';
export default {
  async fetch(request:Request,env:{ASSETS:{fetch:(request:Request)=>Promise<Response>};LOCAL_SETUP?:LocalSetup}) {
    const url=new URL(request.url),pathname=url.pathname;
    try {
      if(pathname==='/api/setup/supabase')return setupSupabase(request,env.LOCAL_SETUP);
      if(pathname==='/api/auth/login'&&request.method==='POST')return auth.login(request);
      if(pathname==='/api/auth/logout'&&request.method==='POST')return auth.logout(request);
      if(pathname==='/api/auth/session'&&request.method==='GET')return auth.session(request);
      if(pathname==='/api/uploads'&&request.method==='POST')return transfers.prepare(request);
      const transfer=pathname.match(/^\/api\/uploads\/([a-f0-9-]{36})$/);
      if(transfer){
        if(request.method==='POST')return transfers.complete(request,transfer[1]);
        if(request.method==='DELETE')return transfers.cancel(request,transfer[1]);
        return new Response('Method not allowed',{status:405});
      }
      if(pathname==='/api/settings'){
        if(request.method==='GET')return settings.GET();
        if(request.method==='PATCH')return settings.PATCH(request);
        return new Response('Method not allowed',{status:405});
      }
      if(pathname==='/api/exhibits') {
        if(request.method==='GET')return collection.GET();
        if(request.method==='POST')return collection.POST(request);
        return new Response('Method not allowed',{status:405});
      }
      const match=pathname.match(/^\/api\/(exhibits|assets)\/([a-z0-9-]{1,80})$/);
      if(match){const params=Promise.resolve({id:match[2]});
        if(match[1]==='assets'&&request.method==='GET')return asset.GET(request,{params});
        if(match[1]==='exhibits'&&request.method==='PATCH')return exhibit.PATCH(request,{params});
        if(match[1]==='exhibits'&&request.method==='DELETE')return exhibit.DELETE(request,{params});
        return new Response('Method not allowed',{status:405});
      }
      if(pathname.startsWith('/api/'))return new Response('Not found',{status:404});
      if(['/', '/admin', '/admin/'].includes(pathname))url.pathname='/index.html';
      return env.ASSETS.fetch(new Request(url,request));
    }catch(error){console.error(error);return Response.json({error:'The museum is temporarily unavailable. Please try again.'},{status:503});}
  }
};
