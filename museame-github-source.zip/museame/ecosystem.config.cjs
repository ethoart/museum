const path = require('node:path');

module.exports = {
  apps: [{
    name: 'museum-of-love',
    cwd: __dirname,
    script: path.join(__dirname, 'scripts/start-pm2.mjs'),
    interpreter: process.execPath,
    node_args: ['--max-old-space-size=768'],
    instances: 1,
    exec_mode: 'fork',
    autorestart: true,
    restart_delay: 3000,
    max_memory_restart: '900M',
    kill_timeout: 20000,
    time: true,
    env: {NODE_ENV: 'production'},
  }],
};
