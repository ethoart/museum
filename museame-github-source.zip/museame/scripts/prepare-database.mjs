import {readFile,writeFile} from 'node:fs/promises';
import {SEED} from '../lib/exhibition.ts';
import {settingsDefaults} from '../lib/settings.ts';
const quote=s=>"'"+s.replaceAll("'","''")+"'";
const base=(await readFile('supabase/schema.sql','utf8')).split('-- BEGIN INITIAL COLLECTION')[0];
const statements=SEED.map(item=>`insert into public.museum_exhibits (id,exhibit) values (${quote(item.id)},${quote(JSON.stringify(item))}::jsonb) on conflict (id) do nothing;`);
statements.push(`insert into public.museum_settings (id,value) values ('birthday',${quote(JSON.stringify(settingsDefaults))}::jsonb) on conflict (id) do nothing;`);
await writeFile('supabase/schema.sql',base+'-- BEGIN INITIAL COLLECTION\n'+statements.join('\n')+'\n');
console.log('Supabase schema is ready.');
