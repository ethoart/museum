import {isIP} from 'node:net';

export function productionConfig(values = process.env) {
  let origin;
  try { origin = new URL(values.PUBLIC_ORIGIN); } catch { throw new Error('Set PUBLIC_ORIGIN to the HTTPS address of your museum.'); }
  if (origin.protocol !== 'https:' || origin.username || origin.password || origin.port || origin.search || origin.hash || origin.pathname !== '/' || isIP(origin.hostname) || !origin.hostname.includes('.')) {
    throw new Error('PUBLIC_ORIGIN must be an HTTPS domain without a path or custom port.');
  }
  let storage;
  try { storage = new URL(values.SUPABASE_URL); } catch { throw new Error('Set SUPABASE_URL to your project URL.'); }
  if (storage.protocol !== 'https:' || !/^[a-z0-9]{20}\.supabase\.co$/.test(storage.hostname) || storage.username || storage.password || storage.port || storage.search || storage.hash || storage.pathname !== '/') {
    throw new Error('Use the HTTPS project URL ending in .supabase.co.');
  }
  const key = values.SUPABASE_SECRET_KEY || '';
  let legacy = false;
  try { legacy = /^[\w-]+\.[\w-]+\.[\w-]+$/.test(key) && JSON.parse(Buffer.from(key.split('.')[1], 'base64url')).role === 'service_role'; } catch {}
  if (!/^sb_secret_[\w-]{20,200}$/.test(key) && !legacy) throw new Error('Set the Supabase secret server key; publishable keys cannot be used.');
  if (!/^[a-zA-Z0-9_-]{1,64}$/.test(values.ADMIN_USERNAME || '')) throw new Error('Set ADMIN_USERNAME using letters, numbers, dashes or underscores.');
  const password = (values.ADMIN_PASSWORD_HASH || '').match(/^pbkdf2-sha256:(\d+):([a-f0-9]{32}):([a-f0-9]{64})$/);
  if (!password || Number(password[1]) < 100000 || Number(password[1]) > 2000000) throw new Error('Run the configuration helper to set ADMIN_PASSWORD_HASH.');
  const fileLimit = Number(values.SUPABASE_MAX_FILE_BYTES || 52428800);
  if (![52428800, 104857600].includes(fileLimit)) throw new Error('Set SUPABASE_MAX_FILE_BYTES to 52428800 or 104857600.');
  const port = Number(values.PORT || 3000);
  if (!Number.isInteger(port) || port < 1024 || port > 65535) throw new Error('PORT must be between 1024 and 65535.');
  const proxyMode = values.PROXY_MODE || 'caddy';
  if (!['caddy', 'cloudflare'].includes(proxyMode)) throw new Error('PROXY_MODE must be caddy or cloudflare.');
  return {origin: origin.origin, port, proxyMode};
}
