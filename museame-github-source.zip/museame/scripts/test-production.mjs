// Actual production bundle behind the Node adapter, with a simulated Supabase.
import assert from 'node:assert/strict';
import {createHash, pbkdf2Sync} from 'node:crypto';
import {request as httpRequest} from 'node:http';
import {mkdtemp, mkdir, writeFile, rm} from 'node:fs/promises';
import {tmpdir} from 'node:os';
import path from 'node:path';
import {once} from 'node:events';
import {productionConfig} from './production-config.mjs';
import {createMuseumServer, staticAssets} from './production-server.mjs';

const secret = 'sb_secret_' + 'test_fixture_only'.repeat(2);
const password = 'deployment-test-only', salt = '0123456789abcdef0123456789abcdef';
const config = {
  PUBLIC_ORIGIN:'https://museum.example.com',
  ADMIN_USERNAME:'sadun',
  ADMIN_PASSWORD_HASH:'pbkdf2-sha256:100000:' + salt + ':' + pbkdf2Sync(password, Buffer.from(salt, 'hex'), 100000, 32, 'sha256').toString('hex'),
  SUPABASE_URL:'https://abcdefghijklmnopqrst.supabase.co',
  SUPABASE_SECRET_KEY:secret,
  SUPABASE_MAX_FILE_BYTES:'52428800',
  LOCAL_PREVIEW:'true', // The production bundle must override this.
};
assert.equal(productionConfig(config).origin, config.PUBLIC_ORIGIN);
for (const invalid of [
  {PUBLIC_ORIGIN:'http://museum.example.com'}, {PUBLIC_ORIGIN:'https://museum.example.com/path'},
  {PUBLIC_ORIGIN:'https://localhost'}, {SUPABASE_URL:'http://localhost'},
  {SUPABASE_SECRET_KEY:'sb_publishable_anything'}, {ADMIN_PASSWORD_HASH:''},
  {PORT:'80'}, {SUPABASE_MAX_FILE_BYTES:'999999999'},
  {PROXY_MODE:'trust-everything'},
]) assert.throws(() => productionConfig({...config,...invalid}));
Object.assign(process.env, config);
const sessions = new Map();
const expectedIP = '203.0.113.12';
let loginChecks = 0;
globalThis.fetch = async (input, init = {}) => {
  const url = new URL(input);
  assert.equal(url.origin, config.SUPABASE_URL);
  assert.equal(new Headers(init.headers).get('apikey'), secret);
  if (url.pathname === '/rest/v1/rpc/museum_allow_login') {
    loginChecks++;
    assert.equal(JSON.parse(init.body).client_key, createHash('sha256').update('museum-login:' + expectedIP).digest('hex'));
    return Response.json(true);
  }
  if (url.pathname === '/rest/v1/museum_sessions') {
    if (init.method === 'POST') {const item = JSON.parse(init.body); sessions.set(item.token_hash, item); return Response.json({});}
    const token = url.searchParams.get('token_hash').slice(3);
    if (init.method === 'DELETE') {sessions.delete(token); return Response.json({});}
    return Response.json(sessions.has(token) ? [sessions.get(token)] : []);
  }
  if (url.pathname === '/rest/v1/museum_settings') return Response.json([{value:{greeting:'Happy birthday, Manika!'}}]);
  throw new Error('Unexpected fixture request: ' + url.pathname);
};
const {default:worker} = await import('../dist/node/worker.mjs');
const directory = await mkdtemp(path.join(tmpdir(), 'museum-production-'));
let server;
try {
  await mkdir(path.join(directory, 'assets'));
  await writeFile(path.join(directory, 'index.html'), '<!doctype html><title>Museum fixture</title>');
  await writeFile(path.join(directory, 'assets', 'museum.js'), 'console.log("fixture");');
  await writeFile(path.join(directory, '.env'), 'must not be served');
  await writeFile(path.join(directory, 'large.glb'), Buffer.alloc(2 * 1024 * 1024, 42));
  const assets = await staticAssets(directory);
  for (const target of ['/.env', '/%2e%2e%2fprivate', '/assets%5c..%5c.env', '/%00file']) assert.equal((await assets.fetch(new Request(config.PUBLIC_ORIGIN + target))).status, 404);
  assert.equal((await assets.fetch(new Request(config.PUBLIC_ORIGIN + '/%bad'))).status, 400);
  const wrappedWorker = {fetch(req, bindings) {
    assert.equal(bindings.LOCAL_SETUP, undefined);
    if (new URL(req.url).pathname === '/test/cookies') return new Response('cookies', {headers:[['Set-Cookie','first=1; Secure'],['Set-Cookie','second=2; Secure']]});
    return worker.fetch(req, bindings);
  }};
  server = await createMuseumServer({worker:wrappedWorker, origin:config.PUBLIC_ORIGIN, directory});
  server.listen(0, '127.0.0.1');
  await once(server, 'listening');
  const port = server.address().port;
  function call(target, {method = 'GET', headers = {}, body} = {}) {
    return new Promise((resolve, reject) => {
      const request = httpRequest({hostname:'127.0.0.1', port, path:target, method, headers:{Host:'museum.example.com', 'X-Forwarded-Proto':'https', 'X-Museum-Client-IP':expectedIP, ...headers}}, response => {
        const chunks = [];
        response.on('data', chunk => chunks.push(chunk));
        response.on('end', () => resolve({status:response.statusCode, headers:response.headers, body:Buffer.concat(chunks)}));
        response.on('error', reject);
      });
      request.on('error', error => reject(new Error(`${method} ${target}: ${error.message}`, {cause:error})));
      request.end(body);
    });
  }
  for (const target of ['/', '/admin', '/admin/']) {
    const result = await call(target);
    assert.equal(result.status, 200);
    assert.match(result.body.toString(), /Museum fixture/);
    assert.equal(result.headers['x-content-type-options'], 'nosniff');
  }
  const script = await call('/assets/museum.js');
  assert.match(script.headers['cache-control'], /must-revalidate/);
  assert.equal((await call('/assets/museum.js', {headers:{'If-None-Match':script.headers.etag}})).status, 304);
  const head = await call('/assets/museum.js', {method:'HEAD'});
  assert.equal(head.status, 200); assert.equal(head.body.length, 0);
  assert.ok(Number(head.headers['content-length']) > 0);
  const large = await call('/large.glb');
  assert.equal(large.body.byteLength, 2 * 1024 * 1024);
  assert.equal(large.body[large.body.length - 1], 42);
  assert.equal((await call('/.env')).status, 404);
  assert.equal((await call('/missing')).status, 404);
  assert.equal((await call('/', {method:'POST'})).status, 405);
  assert.equal((await call('/healthz')).body.toString(), '{"ok":true}');
  assert.equal((await call('/', {headers:{Host:'evil.example'}})).status, 403);
  assert.equal((await call('/', {headers:{'X-Forwarded-Proto':'http'}})).status, 403);
  assert.equal((await call('/', {headers:{'X-Museum-Client-IP':''}})).status, 403);
  assert.equal((await call('/', {headers:{'X-Museum-Client-IP':'203.0.113.1, 203.0.113.2'}})).status, 403);
  assert.equal((await call('//evil.example')).status, 400);
  assert.equal((await call('/api/uploads', {method:'POST', headers:{'Content-Length':String(33 * 1024 * 1024)}})).status, 413);
  const cookieResponse = await call('/test/cookies');
  assert.equal(cookieResponse.headers['set-cookie'].length, 2);

  const loginBody = JSON.stringify({username:'sadun', password});
  const loginHeaders = {Origin:config.PUBLIC_ORIGIN, 'Content-Type':'application/json', 'CF-Connecting-IP':'198.51.100.99', 'X-Forwarded-For':'198.51.100.98'};
  assert.equal((await call('/api/auth/login', {method:'POST', headers:{...loginHeaders, Origin:'https://attacker.example'}, body:loginBody})).status, 403);
  const login = await call('/api/auth/login', {method:'POST', headers:loginHeaders, body:loginBody});
  assert.equal(login.status, 200, login.body.toString());
  assert.equal(loginChecks, 1);
  const cookie = login.headers['set-cookie'][0];
  assert.match(cookie, /__Host-museum_admin=/);
  assert.match(cookie, /; Secure/); assert.match(cookie, /HttpOnly/); assert.match(cookie, /SameSite=Strict/);
  assert.equal(login.headers['cache-control'], 'no-store');
  assert.ok(sessions.size, 'production login uses persistent sessions');
  const authenticated = {Cookie:cookie.split(';')[0], Origin:config.PUBLIC_ORIGIN};
  const session = await call('/api/auth/session', {headers:authenticated});
  assert.equal(JSON.parse(session.body).authenticated, true);
  assert.equal((await call('/api/setup/supabase', {method:'POST', headers:authenticated, body:'{}'})).status, 403);
  assert.equal((await call('/api/setup/supabase', {headers:authenticated})).status, 403);
  const settings = await call('/api/settings');
  assert.equal(JSON.parse(settings.body).settings.greeting, 'Happy birthday, Manika!');
  assert.equal(settings.headers['cache-control'], 'no-store');
  assert.ok(!settings.body.includes(secret));
  assert.equal((await call('/api/auth/logout', {method:'POST', headers:authenticated})).status, 200);
  assert.equal(JSON.parse((await call('/api/auth/session', {headers:authenticated})).body).authenticated, false);
  server.closeAllConnections();
  await new Promise(resolve => server.close(resolve));
  // Exercise the same app through cloudflared's headers. The app must not use
  // the Caddy header or a forged forwarded-for list in tunnel mode.
  server = await createMuseumServer({worker, origin:config.PUBLIC_ORIGIN, directory, proxyMode:'cloudflare'});
  server.listen(port, '127.0.0.1');
  await once(server, 'listening');
  assert.equal((await call('/')).status, 403, 'tunnel mode requires Cloudflare visitor IP');
  const cfHeaders = {...loginHeaders, 'CF-Connecting-IP':expectedIP, 'X-Museum-Client-IP':'198.51.100.222'};
  assert.equal((await call('/', {headers:cfHeaders})).status, 200);
  assert.equal((await call('/', {headers:{...cfHeaders, 'X-Forwarded-Proto':'http'}})).status, 403);
  assert.equal((await call('/', {headers:{...cfHeaders, 'CF-Connecting-IP':'bad'}})).status, 403);
  const tunnelLogin = await call('/api/auth/login', {method:'POST', headers:cfHeaders, body:loginBody});
  assert.equal(tunnelLogin.status, 200);
  assert.match(tunnelLogin.headers['set-cookie'][0], /__Host-museum_admin=.*; Secure/);
  assert.equal(loginChecks, 2);
  assert.equal((await call('/api/auth/login', {method:'POST', headers:{...cfHeaders, Origin:'https://attacker.example'}, body:loginBody})).status, 403);
  assert.equal(productionConfig({...config, PROXY_MODE:'cloudflare'}).proxyMode, 'cloudflare');
  console.log('Production checks passed: configuration, routes, static streaming/HEAD/cache, file boundaries, HTTPS cookies, trusted client IP, origin checks, Supabase sessions, logout, and disabled local setup.');
} finally {
  if (server) {server.closeAllConnections(); await new Promise(resolve => server.close(resolve));}
  const checked = path.resolve(directory);
  assert.equal(path.dirname(checked), path.resolve(tmpdir()));
  assert.ok(path.basename(checked).startsWith('museum-production-'));
  await rm(checked, {recursive:true, force:true});
}
