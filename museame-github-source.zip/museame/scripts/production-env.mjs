// Runtime values only. This module is bundled into the Node API, never the client.
export const env = {...process.env, LOCAL_PREVIEW: 'false'};
