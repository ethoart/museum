import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {runInNewContext} from 'node:vm';
const css=await readFile('app/appearance.css','utf8');
function variables(selector){const start=css.indexOf(selector+'{');assert.ok(start>=0);const block=css.slice(start+selector.length+1,css.indexOf('}',start));return Object.fromEntries([...block.matchAll(/(--[\w-]+):([^;]+)/g)].map(match=>[match[1],match[2]]));}
function lightness(hex){const rgb=hex.slice(1).match(/../g).map(part=>parseInt(part,16)/255).map(v=>v<=.04045?v/12.92:((v+.055)/1.055)**2.4);return rgb[0]*.2126+rgb[1]*.7152+rgb[2]*.0722;}
function contrast(a,b){const x=lightness(a),y=lightness(b);return (Math.max(x,y)+.05)/(Math.min(x,y)+.05);}
const base=':root[data-museum-palette]';let checks=0;
for(const palette of ['candlelight','olive','moonlight','rose'])for(const mode of ['light','dark']){
  const values={...variables(base),...(mode==='dark'?variables(base+'.dark'):{}),...(palette==='candlelight'?{}:variables(':root[data-museum-palette='+palette+']')),...(palette==='candlelight'||mode==='light'?{}:variables(':root[data-museum-palette='+palette+'].dark'))};
  const resolve=name=>values[name].startsWith('var(')?resolve(values[name].slice(4,-1)):values[name];
  for(const [foreground,background] of [['--foreground','--background'],['--foreground','--card'],['--muted-foreground','--card'],['--primary-foreground','--primary'],['--primary','--card']]){
    assert.ok(contrast(resolve(foreground),resolve(background))>=4.5,`${palette} ${mode} needs clearer ${foreground} on ${background}`);checks++;
  }
}
const boot=await readFile('client/boot-appearance.js','utf8');
for(const [mode,systemDark,expected] of [['light',true,false],['dark',false,true],['system',true,true],['system',false,false],[null,true,true]]){
  let dark=false;const root={classList:{toggle:(_,value)=>{dark=value;}},style:{},dataset:{}};
  runInNewContext(boot,{document:{documentElement:root},matchMedia:()=>({matches:systemDark}),localStorage:{getItem:name=>name==='museum-colour-mode'?mode:'olive'}});
  assert.equal(dark,expected);assert.equal(root.dataset.museumPalette,'olive');assert.equal(root.style.colorScheme,expected?'dark':'light');
}
let dark=false;runInNewContext(boot,{document:{documentElement:{classList:{toggle:(_,value)=>{dark=value;}}}},matchMedia:()=>({matches:true}),localStorage:{getItem(){throw new Error('Storage unavailable');}}});assert.equal(dark,true);
console.log(`PASS: ${checks} text/background contrast pairs, saved light/dark choices, system preference, palette restoration, and unavailable browser storage.`);
