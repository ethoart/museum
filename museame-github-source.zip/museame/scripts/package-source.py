"""Create the handoff archive, omitting secrets, dependencies, and local state."""
import os
import shutil
import zipfile
from pathlib import Path

root=Path(__file__).resolve().parents[1]
output=root.parents[1]/'outputs'
output.mkdir(exist_ok=True)
excluded={'.git','node_modules','.sites-runtime','.wrangler','.next','.vinext','.agents','.codex','.openai','dist','work','outputs','release','__pycache__'}
archive=output/'museum-of-love-source.zip'
count=0
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,strict_timestamps=False) as bundle:
    for directory,dirs,files in os.walk(root):
        dirs[:]=[name for name in dirs if name not in excluded]
        for name in files:
            path=Path(directory)/name
            if name.startswith('.env') and name!='.env.example':continue
            if path.suffix in {'.log','.pem','.tsbuildinfo','.pyc','.key','.token','.env','.p12','.pfx'}:continue
            if name=='.npmrc' and any(key in path.read_text(encoding='utf-8') for key in ('_authToken','_password','_auth=')):continue
            bundle.write(path,Path('museum-of-love')/path.relative_to(root))
            count+=1
with zipfile.ZipFile(archive) as bundle:
    assert bundle.testzip() is None
    assert not any(Path(name).name.startswith('.env') and Path(name).name!='.env.example' for name in bundle.namelist())
    assert 'museum-of-love/public/textures/starry-night-sky.png' in bundle.namelist()
shutil.copy2(root/'README.md',output/'Museum of Love — Setup.md')
shutil.copy2(root/'supabase/schema.sql',output/'museum-of-love-supabase.sql')
shutil.copy2(root/'GITHUB-PM2-CLOUDFLARE.md',output/'Museum-GitHub-PM2-Cloudflare.md')
print(f'Packaged {count} source files and assets; {archive.stat().st_size:,} bytes. Archive integrity and secret-file exclusions verified.')
