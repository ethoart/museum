import {rolldown} from 'rolldown';
import path from 'node:path';
import {pathToFileURL} from 'node:url';
const build=await rolldown({input:'scripts/test-garden.ts',platform:'node',external:['three'],resolve:{alias:{'@':process.cwd()}}});
await build.write({file:'.sites-runtime/garden-test.mjs',format:'es'});await build.close();
await import(pathToFileURL(path.resolve('.sites-runtime/garden-test.mjs')).href);
