import {loadEnvFile} from 'node:process';

try {
  // Read secrets inside the app process, rather than putting them into PM2's
  // ecosystem configuration or saved process list.
  loadEnvFile('/etc/museum/museum.env');
  await import('./serve-production.mjs');
} catch {
  console.error('Cannot read /etc/museum/museum.env. Run the PM2 configuration step for this Linux user.');
  process.exitCode = 1;
}
