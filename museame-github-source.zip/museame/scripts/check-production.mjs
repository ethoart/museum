import {productionConfig} from './production-config.mjs';
import {randomUUID} from 'node:crypto';

try {
  productionConfig();
  const key = process.env.SUPABASE_SECRET_KEY;
  const headers = {apikey:key, ...(!key.startsWith('sb_secret_') ? {Authorization:'Bearer ' + key} : {})};
  async function check(route, body) {
    const response = await fetch(new URL(route, process.env.SUPABASE_URL), {headers:{...headers,...(body ? {'Content-Type':'application/json'} : {})}, method:body ? 'POST' : 'GET', body:body ? JSON.stringify(body) : undefined, redirect:'error', signal:AbortSignal.timeout(20000)});
    if (!response.ok) {await response.body?.cancel(); throw new Error(`Supabase check failed (${response.status}). Check the project, server key and setup SQL.`);}
    return response.json();
  }
  const [bucket, settings] = await Promise.all([
    check('/storage/v1/bucket/museum-art'),
    check('/rest/v1/museum_settings?id=eq.birthday&select=value'),
    ...['museum_exhibits','museum_sessions','museum_uploads','museum_login_attempts'].map(table => check('/rest/v1/' + table + '?select=*&limit=0')),
  ]);
  if (bucket.public !== false) throw new Error('The museum-art bucket must be private.');
  if (!settings[0]?.value?.greeting) throw new Error('Run the complete setup SQL to add the birthday settings.');
  if (Number(bucket.file_size_limit) < Number(process.env.SUPABASE_MAX_FILE_BYTES || 52428800)) throw new Error('The museum-art bucket limit is below the configured file limit.');
  if (await check('/rest/v1/rpc/museum_allow_login', {client_key:'deployment-check:' + randomUUID()}) !== true) throw new Error('The sign-in function is not ready.');
  console.log('Supabase verified: private bucket, museum tables, birthday settings and sign-in function.');
  console.log('Also check the project-wide file limit in Supabase Storage settings.');
} catch (error) {
  console.error(error instanceof TypeError ? 'Cannot reach Supabase. Check the URL, project status and outbound network access.' : error.message);
  process.exitCode = 1;
}
