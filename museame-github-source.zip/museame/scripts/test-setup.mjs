import assert from 'node:assert/strict';
import {mkdir,readFile,writeFile,unlink,rmdir} from 'node:fs/promises';
import path from 'node:path';
import {randomUUID} from 'node:crypto';
import {localSupabaseSetup} from './local-supabase-setup.mjs';

const parent=path.resolve('.sites-runtime'),root=path.join(parent,'setup-test-'+randomUUID());
assert.equal(path.dirname(root),parent);await mkdir(root,{recursive:true});
const file=path.join(root,'.env.local'),original='ADMIN_USERNAME=sadun\nADMIN_PASSWORD_HASH=test-fixture-only\nSUPABASE_URL=https://old.invalid\n';
await writeFile(file,original);const key='sb_secret_'+randomUUID().replaceAll('-',''),url='https://abcdefghijklmnopqrst.supabase.co';
let calls=0,privateBucket=true,rejectKey=false;
const fixture=async(address,init)=>{
  calls++;assert.equal(new URL(address).origin,url);assert.equal(init.headers.apikey,key);assert.equal(init.redirect,'error');
  if(rejectKey)return new Response('',{status:401});
  if(address.includes('/bucket/'))return Response.json({public:!privateBucket,file_size_limit:104857600});
  if(address.includes('/museum_settings'))return Response.json([{value:{greeting:'Happy birthday'}}]);
  if(address.includes('/rpc/museum_allow_login')){assert.equal(init.method,'POST');assert.match(JSON.parse(init.body).client_key,/^setup-check:/);return Response.json(true);}
  return Response.json([]);
};
const setup=localSupabaseSetup(root,fixture);
try{
  for(const bad of ['http://127.0.0.1','https://abcdefghijklmnopqrst.supabase.co.attacker.invalid','https://user:pass@abcdefghijklmnopqrst.supabase.co','https://abcdefghijklmnopqrst.supabase.co/other','https://abcdefghijklmnopqrst.supabase.co?redirect=evil'])await assert.rejects(()=>setup.connect({url:bad,key}),/project URL/);
  await assert.rejects(()=>setup.connect({url,key:'sb_publishable_not_a_server_key'}),/secret server key/);
  await assert.rejects(()=>setup.connect({url,key:key+'\nADMIN_USERNAME=attacker'}),/secret server key/);
  assert.equal(calls,0,'invalid addresses and credentials rejected before any network call');
  rejectKey=true;await assert.rejects(()=>setup.connect({url,key}),/rejected this key/);assert.equal(await readFile(file,'utf8'),original,'failed checks preserve the existing environment');rejectKey=false;
  privateBucket=false;await assert.rejects(()=>setup.connect({url,key}),/must be private/);privateBucket=true;
  const values=await setup.connect({url,key,storedFileLimit:50});assert.equal(values.SUPABASE_MAX_FILE_BYTES,'52428800');
  const contents=await readFile(file,'utf8');assert.ok(contents.includes('ADMIN_PASSWORD_HASH=test-fixture-only'));assert.equal((contents.match(/^SUPABASE_URL=/gm)||[]).length,1);assert.ok(contents.includes('SUPABASE_SECRET_KEY='+key));assert.ok(!contents.includes('old.invalid'));
  const again=await setup.connect({url,key,storedFileLimit:100});assert.equal(again.SUPABASE_MAX_FILE_BYTES,'104857600');
  assert.equal((await readFile(file,'utf8')).split('SUPABASE_SECRET_KEY=').length,2,'reconnecting replaces credentials instead of duplicating them');
  console.log('PASS: local connection validation, private bucket and schema checks, sign-in RPC, failed-check rollback, restricted destination, key injection rejection, credential replacement, and preservation of the admin account. Supabase transport is simulated.');
}finally{await unlink(file);await rmdir(root);}
