import assert from 'node:assert/strict';
import path from 'node:path';
import {pathToFileURL} from 'node:url';
import {rolldown} from 'rolldown';
import {Document,WebIO} from '@gltf-transform/core';
import {ALL_EXTENSIONS} from '@gltf-transform/extensions';
import {MeshoptDecoder} from 'meshoptimizer/decoder';
import * as T from 'three';
import {GLTFLoader} from 'three/examples/jsm/loaders/GLTFLoader.js';
import sharp from 'sharp';

const build=await rolldown({input:'lib/optimize-upload.ts',platform:'node'});
await build.write({file:'.sites-runtime/optimizer-test.mjs',format:'es'});await build.close();
const {optimizeUpload}=await import(pathToFileURL(path.resolve('.sites-runtime/optimizer-test.mjs')).href);
const doc=new Document(),buffer=doc.createBuffer();
const geo=new T.SphereGeometry(2,128,64);
const accessor=(name,type,array)=>doc.createAccessor(name).setType(type).setArray(array).setBuffer(buffer);
const material=doc.createMaterial('Rose gold').setBaseColorFactor([.9,.7,.55,1]).setMetallicFactor(.55).setRoughnessFactor(.4);
const primitive=doc.createPrimitive().setAttribute('POSITION',accessor('position','VEC3',geo.attributes.position.array))
  .setAttribute('NORMAL',accessor('normal','VEC3',geo.attributes.normal.array))
  .setAttribute('TEXCOORD_0',accessor('uv','VEC2',geo.attributes.uv.array))
  .setIndices(accessor('indices','SCALAR',geo.index.array)).setMaterial(material);
const mesh=doc.createMesh('Keepsake').addPrimitive(primitive),node=doc.createNode('Keepsake').setMesh(mesh);
doc.createScene('Our sculpture').addChild(node);doc.getRoot().setDefaultScene(doc.getRoot().listScenes()[0]);
const sampler=doc.createAnimationSampler().setInput(accessor('time','SCALAR',new Float32Array([0,1])))
  .setOutput(accessor('position keys','VEC3',new Float32Array([0,0,0,0,1,0]))).setInterpolation('LINEAR');
doc.createAnimation('Float').addSampler(sampler).addChannel(doc.createAnimationChannel().setTargetNode(node).setTargetPath('translation').setSampler(sampler));
const io=new WebIO().registerExtensions(ALL_EXTENSIONS).registerDependencies({'meshopt.decoder':MeshoptDecoder});
const source=await io.writeBinary(doc),progress=[];
const optimized=await optimizeUpload(new File([source],'keepsake.glb',{type:'model/gltf-binary'}),'model',message=>progress.push(message));
assert.ok(optimized.size<source.byteLength*.65,'representative model should become substantially smaller');
const decoded=await io.readBinary(new Uint8Array(await optimized.arrayBuffer()));
assert.equal(decoded.getRoot().listAnimations().length,1,'animation survives compression');
assert.ok(decoded.getRoot().listMeshes().length>=1);assert.equal(decoded.getRoot().listMaterials()[0].getMetallicFactor(),.55);
globalThis.ProgressEvent??=class extends Event{constructor(type,props){super(type);Object.assign(this,props);}};
const loader=new GLTFLoader().setMeshoptDecoder(MeshoptDecoder),original=await loader.parseAsync(source.buffer,''),result=await loader.parseAsync(await optimized.arrayBuffer(),'');
const originalBounds=new T.Box3().setFromObject(original.scene),bounds=new T.Box3().setFromObject(result.scene);
assert.ok(bounds.min.distanceTo(originalBounds.min)<.002);assert.ok(bounds.max.distanceTo(originalBounds.max)<.002,'gallery decoder preserves model dimensions');
assert.equal(result.animations.length,1);assert.ok(progress.some(message=>message.includes('geometry')));
await assert.rejects(()=>optimizeUpload(new File(['bad'],'broken.glb'),'model'),/valid GLB/);
function glb(json){const text=new TextEncoder().encode(JSON.stringify(json)),size=Math.ceil(text.length/4)*4,bytes=new Uint8Array(20+size);bytes.fill(32,20);const view=new DataView(bytes.buffer);view.setUint32(0,0x46546c67,true);view.setUint32(4,2,true);view.setUint32(8,bytes.length,true);view.setUint32(12,size,true);view.setUint32(16,0x4e4f534a,true);bytes.set(text,20);return new File([bytes],'external.glb');}
await assert.rejects(()=>optimizeUpload(glb({asset:{version:'2.0'},buffers:[{uri:'https://external.invalid/file.bin'}]}),'model'),/Embed/);
await assert.rejects(()=>optimizeUpload(glb({asset:{version:'2.0'},extensionsUsed:['VENDOR_unknown']}),'model'),/unsupported/);
// A CPU image-codec adapter exercises the real image pipeline without a browser.
// Browser canvas encoding and the Web Worker integration still need browser QA.
globalThis.createImageBitmap=async blob=>{const data=Buffer.from(await blob.arrayBuffer()),info=await sharp(data).metadata();return {data,width:info.width,height:info.height,close(){}};};
globalThis.OffscreenCanvas=class {constructor(width,height){this.width=width;this.height=height;}getContext(){return {drawImage:bitmap=>{this.bitmap=bitmap;}};}async convertToBlob({type,quality}){const data=await sharp(this.bitmap.data).resize(this.width,this.height).toFormat(type==='image/webp'?'webp':'png',{quality:Math.round(quality*100)}).toBuffer();return new Blob([data],{type});}};
const width=3072,height=1536,pixels=Buffer.alloc(width*height*4);
for(let y=0;y<height;y++)for(let x=0;x<width;x++){const p=(y*width+x)*4;pixels[p]=x%256;pixels[p+1]=y%256;pixels[p+2]=125;pixels[p+3]=x<width/2?0:255;}
const png=await sharp(pixels,{raw:{width,height,channels:4}}).png().toBuffer();
const compact=await optimizeUpload(new File([png],'drawing.png',{type:'image/png'}),'image');
const imageInfo=await sharp(Buffer.from(await compact.arrayBuffer())).metadata();
assert.equal(imageInfo.width,2048);assert.equal(imageInfo.height,1024);assert.equal(imageInfo.hasAlpha,true);assert.equal(compact.type,'image/webp');assert.ok(compact.size<png.length);
const originalBitmap=globalThis.createImageBitmap;globalThis.createImageBitmap=async()=>({width:17000,height:1000,close(){}});
await assert.rejects(()=>optimizeUpload(new File([png],'huge.png'),'image'),/16,000/);globalThis.createImageBitmap=originalBitmap;
console.log(JSON.stringify({result:'PASS',model:{sourceBytes:source.byteLength,storedBytes:optimized.size,savedPercent:Math.round((1-optimized.size/source.byteLength)*100)},image:{sourceBytes:png.length,storedBytes:compact.size,width:imageInfo.width,height:imageInfo.height},checks:'real Meshopt compression, Three.js decoder, geometry bounds, materials, animation preservation, image size and transparency through a CPU canvas adapter, invalid files and external resources'}));
geo.dispose();
