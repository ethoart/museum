import {fileURLToPath} from 'node:url';
import {productionConfig} from './production-config.mjs';
import {createMuseumServer} from './production-server.mjs';

try {
  const {origin, port, proxyMode} = productionConfig();
  const {default:worker} = await import('../dist/node/worker.mjs');
  const server = await createMuseumServer({worker, origin, proxyMode, directory:fileURLToPath(new URL('../dist/client/', import.meta.url))});
  server.on('error', () => {console.error('Museum could not listen. Check PORT and the service configuration.'); process.exit(1);});
  server.listen(port, '127.0.0.1', () => console.log(`Museum ready behind HTTPS proxy: ${origin}`));
  for (const signal of ['SIGTERM','SIGINT']) process.once(signal, () => {
    server.close(() => process.exit(0));
    setTimeout(() => {server.closeAllConnections(); process.exit(0);}, 15000).unref();
  });
} catch (error) {
  console.error(error.message);
  process.exitCode = 1;
}
