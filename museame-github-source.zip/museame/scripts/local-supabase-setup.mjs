import {readFile,writeFile,rename,unlink} from 'node:fs/promises';
import path from 'node:path';
import {randomUUID} from 'node:crypto';

// Only the loopback preview supplies this binding. Never included in the browser
// or hosted Worker. The Worker checks the admin session and request origin first.
export function localSupabaseSetup(root=process.cwd(),request=fetch){
  let connecting=false;
  return {
    schema:()=>readFile(path.join(root,'supabase/schema.sql'),'utf8'),
    async connect(input){
      if(connecting)throw new Error('A connection check is already running. Please wait.');
      connecting=true;
      try{
        const address=typeof input.url==='string'?input.url.trim():'',key=typeof input.key==='string'?input.key.trim():'';
        let url;try{url=new URL(address);}catch{throw new Error('Paste the project URL from Supabase.');}
        if(url.protocol!=='https:'||!/^([a-z0-9]{20})\.supabase\.co$/.test(url.hostname)||url.port||url.username||url.password||url.search||url.hash||!['','/'].includes(url.pathname))throw new Error('Use your HTTPS Supabase project URL, such as https://your-project.supabase.co.');
        let legacy=false;
        if(!/^sb_secret_[A-Za-z0-9_-]{20,200}$/.test(key)){
          try{legacy=/^[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+$/.test(key)&&JSON.parse(Buffer.from(key.split('.')[1],'base64url').toString()).role==='service_role';}catch{}
          if(!legacy)throw new Error('Use a secret server key from Settings → API Keys. A publishable key cannot save museum content.');
        }
        const chosen=input.storedFileLimit??50;if(![50,100].includes(chosen))throw new Error('Choose the 50 MB or 100 MB project limit.');
        const headers={apikey:key,...(legacy?{Authorization:'Bearer '+key}:{})};
        const check=async(route,body)=>{
          let response;try{response=await request(url.origin+route,{headers:{...headers,...(body?{'Content-Type':'application/json'}:{})},method:body?'POST':'GET',body:body?JSON.stringify(body):undefined,redirect:'error',signal:AbortSignal.timeout(15000)});}catch{throw new Error('Cannot reach that Supabase project. Check that it is active and try again.');}
          if(!response.ok){await response.body?.cancel();if([401,403].includes(response.status))throw new Error('The project rejected this key. Check the project URL and secret server key.');throw new Error('The museum database is not ready. Run the setup SQL in this project, then connect again.');}
          return response.json();
        };
        const [bucket,settings]=await Promise.all([
          check('/storage/v1/bucket/museum-art'),
          check('/rest/v1/museum_settings?id=eq.birthday&select=value'),
          ...['museum_exhibits','museum_sessions','museum_uploads','museum_login_attempts'].map(table=>check('/rest/v1/'+table+'?select=*&limit=0')),
        ]);
        if(bucket.public!==false)throw new Error('The museum-art bucket must be private. Run the setup SQL again.');
        if(!Array.isArray(settings)||!settings[0]?.value?.greeting)throw new Error('Run the complete museum setup SQL to add the birthday settings.');
        if(await check('/rest/v1/rpc/museum_allow_login',{client_key:'setup-check:'+randomUUID()})!==true)throw new Error('The museum sign-in function is not ready. Run the setup SQL again.');
        const limits=Math.min(chosen*1024*1024,Number(bucket.file_size_limit)||100*1024*1024);
        const values={SUPABASE_URL:url.origin,SUPABASE_SECRET_KEY:key,SUPABASE_MAX_FILE_BYTES:String(limits)};
        const file=path.join(root,'.env.local');let previous='';
        try{previous=await readFile(file,'utf8');}catch(error){if(error.code!=='ENOENT')throw new Error('Cannot read the local museum settings.');}
        const untouched=previous.split(/\r?\n/).filter(line=>!/^\s*(?:export\s+)?(?:SUPABASE_URL|SUPABASE_SECRET_KEY|SUPABASE_MAX_FILE_BYTES)\s*=/.test(line)).join('\n').trimEnd();
        const next=untouched+'\n'+Object.entries(values).map(([name,value])=>name+'='+value).join('\n')+'\n';
        const temporary=path.join(root,'.env.connect-'+randomUUID());
        try{await writeFile(temporary,next,{mode:0o600,flag:'wx'});await rename(temporary,file);}catch{await unlink(temporary).catch(()=>{});throw new Error('Could not save the connection on this computer. Check that the museum folder is writable.');}
        return values;
      }finally{connecting=false;}
    },
  };
}
