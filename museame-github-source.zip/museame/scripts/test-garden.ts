// Geometry and walking-route checks without starting a browser or WebGL renderer.
import assert from 'node:assert/strict';
import * as T from 'three';
import { buildRomanticMuseum } from '../lib/romantic-architecture';
import { MuseumWorld } from '../lib/museum-world';
import { SEED, SLOTS, validateExhibit } from '../lib/exhibition';
const gradient={addColorStop(){}};
const context=new Proxy({createRadialGradient:()=>gradient},{get(target,key){return key in target?target[key as keyof typeof target]:()=>{};},set(){return true;}});
const motionPreference={matches:false};
Object.assign(globalThis,{document:{createElement:()=>({width:0,height:0,getContext:()=>context})},window:{matchMedia:()=>motionPreference}});
const world=Object.create(MuseumWorld.prototype) as MuseumWorld;
world.scene=new T.Scene();world.obstacles=[];
// Fill every plinth at its largest API-accepted size to check future circulation too.
world.exhibits=SLOTS.filter(s=>s.kind==='model').map(s=>({...SEED[5],id:s.id,slot:s.id,size:3.5}));
const update=buildRomanticMuseum(world,false);update(1000);world.scene.updateMatrixWorld(true);
const sky=world.scene.getObjectByName('painted-night-sky')!;
assert.ok(sky,'painted sky exists');
const firstAngle=sky.rotation.y;update(5000);
assert.ok(sky.rotation.y-firstAngle>.012&&sky.rotation.y-firstAngle<.04,'sky drift is visible within four seconds without spinning quickly');
assert.equal(sky.userData.animationClock.value,5,'sky and water share the animation clock');
motionPreference.matches=true;update(10000);
assert.equal(sky.userData.animationClock.value,5,'reduced motion stops decorative animation');
motionPreference.matches=false;
for(const x of[-18,18]){const direction=new T.Vector3(Math.sign(x),0,0);const hits=new T.Raycaster(new T.Vector3(x-Math.sign(x),5.4,0),direction,0,1.3).intersectObjects(world.scene.children,true);assert.ok(hits.length,'side-gallery wall has stone backing at 5.4 m');}
for(const x of[-12.5,12.5])for(const z of[-12,12]){const hits=new T.Raycaster(new T.Vector3(x,5.4,z-Math.sign(z)),new T.Vector3(0,0,Math.sign(z)),0,1.3).intersectObjects(world.scene.children,true);assert.ok(hits.length,'side-gallery end wall reaches 5.4 m');}
assert.ok(world.scene.getObjectByName('olive-leaves') instanceof T.InstancedMesh,'detailed leaves stay instanced');
let meshes=0,triangles=0;
world.scene.traverse(object=>{
  if(!(object instanceof T.Mesh))return;meshes++;
  const positions=object.geometry.attributes.position;
  for(const coordinate of positions.array)assert.ok(Number.isFinite(coordinate),'geometry contains non-finite coordinates');
  triangles+=(object.geometry.index?object.geometry.index.count:positions.count)/3*(object instanceof T.InstancedMesh?object.count:1);
});
assert.ok(meshes<100,'static garden details should be batched into fewer than 100 meshes');
assert.ok(world.valid(.7,9.5),'entrance is clear');
for(const x of[-7,7])for(const z of[-5,5]){
  assert.ok(world.valid(x,z),'archway is walkable');
  const direction=Math.sign(x),ray=new T.Raycaster(new T.Vector3(x-direction*1.2,1.72,z),new T.Vector3(direction,0,0));
  const hits=ray.intersectObjects(world.scene.children,true);
  assert.ok(!hits.length||hits[0].distance>1.4,'the arch is a real opening at eye height');
}
// Flood the floor from the entrance. Every room and artwork viewing position must remain reachable.
const step=.25,width=141,height=93,offsetX=-17.5,offsetZ=-11.5;
const coord=(x:number,z:number)=>[Math.round((x-offsetX)/step),Math.round((z-offsetZ)/step)];
const index=(x:number,z:number)=>z*width+x;
const [sx,sz]=coord(.7,9.5),queue=[[sx,sz]],seen=new Set([index(sx,sz)]);
for(let head=0;head<queue.length;head++){
  const [x,z]=queue[head];for(const [dx,dz]of[[0,1],[0,-1],[1,0],[-1,0]]){
    const nx=x+dx,nz=z+dz,key=index(nx,nz);if(nx<0||nz<0||nx>=width||nz>=height||seen.has(key))continue;
    if(world.valid(offsetX+nx*step,offsetZ+nz*step)){seen.add(key);queue.push([nx,nz]);}
  }
}
const frames:{id:string;bounds:T.Box3}[]=[];
for(const slot of SLOTS){
  const distance=slot.kind==='image'?4:4.3;
  const fx=slot.x+Math.sin(slot.yaw)*distance,fz=slot.z+Math.cos(slot.yaw)*distance;
  const [x,z]=coord(fx,fz);assert.ok(world.valid(fx,fz),'focus lands in obstacle: '+slot.id);assert.ok(seen.has(index(x,z)),'cannot reach '+slot.label);
  if(slot.kind!=='image')continue;
  const normal=new T.Vector3(Math.sin(slot.yaw),0,Math.cos(slot.yaw));
  const tangent=new T.Vector3(Math.cos(slot.yaw),0,-Math.sin(slot.yaw));
  const half=((slot.maxSize??3.5)+.22)/2;
  const matrix=new T.Matrix4().makeRotationY(slot.yaw).setPosition(slot.x,0,slot.z);
  frames.push({id:slot.id,bounds:new T.Box3(new T.Vector3(-half,2.4-half,-.01),new T.Vector3(half,2.4+half,.14)).applyMatrix4(matrix)});
  // Every maximum-sized square frame needs a real wall behind all four corners.
  for(const dx of[-half,0,half])for(const dy of[-half,-.75,0,.75,half]){
    const start=new T.Vector3(slot.x,2.4+dy,slot.z).addScaledVector(tangent,dx).addScaledVector(normal,.3);
    const hits=new T.Raycaster(start,normal.clone().negate(),0,.5).intersectObjects(world.scene.children,true);
    assert.ok(hits.length,'frame extends beyond wall: '+slot.id);
    assert.ok(hits[0].distance>=.175,`architecture protrudes in front of ${slot.id} at ${dx},${dy}; hit ${hits[0].distance.toFixed(3)} m away at ${hits[0].point.toArray()}`);
  }
  const ray=new T.Raycaster(new T.Vector3(fx,2.4,fz),normal.clone().negate(),0,4.3);
  const hits=ray.intersectObjects(world.scene.children,true);
  assert.ok(hits.length&&hits[0].distance>3.75,'art view is blocked: '+slot.id);
  if(slot.maxSize){
    assert.throws(()=>validateExhibit({...SEED[0],slot:slot.id,size:slot.maxSize+.1}));
    assert.equal(validateExhibit({...SEED[0],slot:slot.id,size:slot.maxSize}).size,slot.maxSize);
  }
}
for(let i=0;i<frames.length;i++)for(let j=i+1;j<frames.length;j++)assert.ok(!frames[i].bounds.intersectsBox(frames[j].bounds),'frames overlap: '+frames[i].id+' / '+frames[j].id);
assert.equal(SLOTS.filter(s=>s.kind==='image').length,36);
assert.equal(new Set(SLOTS.map(s=>s.id)).size,SLOTS.length,'display IDs must be unique');
for(const x of[-16.5,16.5])for(const z of[-10.5,10.5]){const [gx,gz]=coord(x,z);assert.ok(seen.has(index(gx,gz)),'gallery corner is inaccessible');}
assert.ok(!world.valid(-3.9,4.4),'bench collision is present');
assert.ok(!world.valid(5,8.7),'tree planter collision is present');
console.log(JSON.stringify({result:'PASS',artworkSpaces:36,sculpturePlinths:5,meshes,triangles:Math.round(triangles),reachableFloorCells:seen.size,checks:'taller side walls, visible sky drift, reduced motion, finite geometry, mesh batching, open arches, every display reachable with all plinths filled, wall backing and clear views for 36 maximum-sized frames, position size limits, all gallery corners, bench and planter collisions'}));
world.disposeGroup(world.scene);
