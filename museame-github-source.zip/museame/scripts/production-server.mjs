import {createServer} from 'node:http';
import {createReadStream} from 'node:fs';
import {realpath, stat} from 'node:fs/promises';
import {isIP} from 'node:net';
import path from 'node:path';
import {Readable, Transform} from 'node:stream';
import {pipeline} from 'node:stream/promises';

const types = {'.html':'text/html; charset=utf-8', '.js':'text/javascript; charset=utf-8', '.css':'text/css; charset=utf-8', '.svg':'image/svg+xml', '.jpg':'image/jpeg', '.jpeg':'image/jpeg', '.png':'image/png', '.webp':'image/webp', '.json':'application/json', '.glb':'model/gltf-binary', '.woff2':'font/woff2', '.ico':'image/x-icon', '.txt':'text/plain; charset=utf-8', '.wasm':'application/wasm'};
const bodyLimit = 32 * 1024 * 1024; // Large uploads go directly to Supabase using TUS.

export async function staticAssets(directory) {
  const base = await realpath(directory);
  return {async fetch(request) {
    if (!['GET','HEAD'].includes(request.method)) return new Response('Method not allowed', {status:405, headers:{Allow:'GET, HEAD'}});
    let pathname;
    try { pathname = decodeURIComponent(new URL(request.url).pathname); } catch { return new Response('Bad request', {status:400}); }
    if (pathname.includes('\\') || pathname.includes('\0') || pathname.split('/').some(part => part.startsWith('.'))) return new Response('Not found', {status:404});
    const candidate = path.resolve(base, '.' + pathname);
    if (!candidate.startsWith(base + path.sep)) return new Response('Not found', {status:404});
    try {
      const filename = await realpath(candidate);
      if (!filename.startsWith(base + path.sep)) return new Response('Not found', {status:404});
      const info = await stat(filename);
      if (!info.isFile()) return new Response('Not found', {status:404});
      const etag = `W/"${info.size.toString(16)}-${Math.trunc(info.mtimeMs).toString(16)}"`;
      // Entry filenames are stable across releases, so browsers must revalidate.
      const headers = {'Content-Type':types[path.extname(filename)] || 'application/octet-stream', 'Cache-Control':'public, max-age=0, must-revalidate', ETag:etag};
      if (request.headers.get('if-none-match') === etag) return new Response(null, {status:304, headers});
      headers['Content-Length'] = String(info.size);
      return new Response(request.method === 'HEAD' ? null : Readable.toWeb(createReadStream(filename)), {headers});
    } catch (error) {
      if (['ENOENT','ENOTDIR','EACCES'].includes(error.code)) return new Response('Not found', {status:404});
      throw error;
    }
  }};
}

export async function createMuseumServer({worker, origin, directory, proxyMode = 'caddy'}) {
  if (!['caddy', 'cloudflare'].includes(proxyMode)) throw new Error('Invalid proxy mode.');
  const assets = await staticAssets(directory), expectedHost = new URL(origin).host;
  return createServer({requestTimeout:60000, headersTimeout:15000, keepAliveTimeout:5000, maxHeaderSize:16384}, async (req, res) => {
    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.setHeader('X-Frame-Options', 'DENY');
    res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
    res.setHeader('Cache-Control', 'no-store');
    const reject = (status, message) => {
      // A rejected request may still have an unread body. Never reuse that socket.
      res.shouldKeepAlive = false;
      res.writeHead(status, {'Content-Type':'text/plain; charset=utf-8', Connection:'close'});
      res.end(message);
    };
    try {
      if (!['127.0.0.1','::1','::ffff:127.0.0.1'].includes(req.socket.remoteAddress) || req.headers.host !== expectedHost) return reject(403, 'Unrecognized host.');
      // Only a loopback proxy is accepted. Each deployment selects its trusted
      // proxy explicitly; client-supplied alternate forwarding headers are ignored.
      if (req.headers['x-forwarded-proto'] !== 'https') return reject(403, 'HTTPS is required.');
      const clientIP = req.headers[proxyMode === 'cloudflare' ? 'cf-connecting-ip' : 'x-museum-client-ip'];
      if (typeof clientIP !== 'string' || !isIP(clientIP)) return reject(403, 'Use the configured reverse proxy.');
      if (!req.url?.startsWith('/') || req.url.startsWith('//') || req.url.includes('\\')) return reject(400, 'Bad request.');
      if (Number(req.headers['content-length']) > bodyLimit) return reject(413, 'Use the resumable uploader for large files.');
      if (req.url === '/healthz' && ['GET','HEAD'].includes(req.method)) {
        res.writeHead(200, {'Content-Type':'application/json'});
        return res.end(req.method === 'HEAD' ? undefined : '{"ok":true}');
      }
      const headers = new Headers();
      for (const [name, value] of Object.entries(req.headers)) {
        if (value !== undefined && !['connection','transfer-encoding','cf-connecting-ip','x-forwarded-for','x-museum-client-ip','forwarded','x-forwarded-host','x-forwarded-proto'].includes(name)) headers.set(name, Array.isArray(value) ? value.join(', ') : value);
      }
      headers.set('cf-connecting-ip', clientIP); // The shared login limiter uses this name.
      const aborted = new AbortController();
      req.on('aborted', () => aborted.abort());
      res.on('close', () => {if (!res.writableFinished) aborted.abort();});
      const init = {method:req.method, headers, signal:aborted.signal};
      if (!['GET','HEAD'].includes(req.method)) {
        let bytes = 0;
        const limiter = new Transform({transform(chunk, encoding, done) {
          bytes += chunk.length;
          done(bytes > bodyLimit ? new Error('Request body exceeds limit.') : null, bytes > bodyLimit ? undefined : chunk);
        }});
        req.on('error', error => limiter.destroy(error));
        init.body = Readable.toWeb(req.pipe(limiter));
        init.duplex = 'half';
      }
      const request = new Request(origin + req.url, init);
      // No LOCAL_SETUP binding is supplied in production.
      const response = await worker.fetch(request, {ASSETS:assets});
      for (const [name, value] of response.headers) if (name !== 'set-cookie') res.setHeader(name, value);
      const cookies = response.headers.getSetCookie();
      if (cookies.length) res.setHeader('Set-Cookie', cookies);
      res.writeHead(response.status);
      if (response.body && req.method !== 'HEAD') await pipeline(Readable.fromWeb(response.body), res);
      else {await response.body?.cancel(); res.end();}
    } catch {
      // Error details may contain service URLs or credentials; keep responses/logs generic.
      if (!res.headersSent) reject(503, 'The museum is temporarily unavailable.');
      else res.destroy();
    }
  });
}
