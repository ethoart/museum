import { rolldown } from 'rolldown';
import { compile } from '@tailwindcss/node';
import { Scanner } from '@tailwindcss/oxide';
import { readFile,writeFile,mkdir,cp,rm } from 'node:fs/promises';
import path from 'node:path';
const root=process.cwd();
const output=path.join(root,'dist');
for(const name of ['client','server']){const target=path.resolve(output,name);if(!target.startsWith(path.resolve(root)+path.sep)||path.dirname(target)!==output)throw new Error('Invalid output directory');await rm(target,{recursive:true,force:true});}
await mkdir(path.join(output,'client/assets'),{recursive:true});await mkdir(path.join(output,'server'),{recursive:true});await mkdir(path.join(output,'.openai'),{recursive:true});
const client=await rolldown({input:{museum:'client/main.tsx',optimizer:'client/optimizer-worker.ts'},platform:'browser',external:['node:fs','node:path'],resolve:{alias:{'@':root}},transform:{jsx:'react-jsx',define:{'process.env.NODE_ENV':JSON.stringify('production')}},onwarn(warn,handler){if(warn.code!=='MODULE_LEVEL_DIRECTIVE')handler(warn);}});
await client.write({dir:'dist/client/assets',format:'es',entryFileNames:'[name].js',chunkFileNames:'[name]-[hash].js',minify:true});await client.close();
// NodeIO is unused and must be fully removed from the browser build.
for(const name of await (await import('node:fs/promises')).readdir('dist/client/assets')){if(name.endsWith('.js')&&/node:(?:fs|path)/.test(await readFile(path.join('dist/client/assets',name),'utf8')))throw new Error('Node-only code reached the browser: '+name);}
const css=await compile(await readFile('app/globals.css','utf8'),{base:path.join(root,'app'),onDependency(){}});
const scanner=new Scanner({sources:[{base:root,pattern:'components/**/*.tsx',negated:false}]});
await writeFile('dist/client/assets/museum.css',css.build(scanner.scan()));
await cp('public','dist/client',{recursive:true});
const appearanceBoot=await readFile('client/boot-appearance.js','utf8');
await writeFile('dist/client/index.html','<!doctype html><html lang="en" data-museum-palette="candlelight"><head><script>'+appearanceBoot+'</script><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1"><meta name="description" content="A birthday museum for Manika. Our drawings, our memories, our love."><title>Museum of Love · For Manika</title><link rel="icon" href="/favicon.svg"><meta name="color-scheme" content="light dark"><link rel="stylesheet" href="/assets/museum.css"></head><body><div id="root"></div><script type="module" src="/assets/museum.js"></script></body></html>');
const server=await rolldown({input:'worker/index.ts',platform:'neutral',resolve:{alias:{'@':root}},external:['cloudflare:workers']});
await server.write({file:'dist/server/index.js',format:'es',minify:true});await server.close();
const local=await rolldown({input:'worker/index.ts',platform:'node',resolve:{alias:{'@':root,'cloudflare:workers':path.join(root,'scripts/preview-env.mjs')}}});
await local.write({file:'dist/local/worker.mjs',format:'es'});await local.close();
const production=await rolldown({input:'worker/index.ts',platform:'node',resolve:{alias:{'@':root,'cloudflare:workers':path.join(root,'scripts/production-env.mjs')}}});
await production.write({file:'dist/node/worker.mjs',format:'es'});await production.close();
try{await cp('.openai/hosting.json','dist/.openai/hosting.json');}catch(error){if(error.code!=='ENOENT')throw error;}
await writeFile('dist/server/wrangler.json',JSON.stringify({name:'museum-of-love',main:'index.js',compatibility_date:'2026-05-15',compatibility_flags:['nodejs_compat'],assets:{directory:'../client',binding:'ASSETS'}},null,2));
console.log('Museum built: browser assets, Worker API, local preview, and production Node API.');
