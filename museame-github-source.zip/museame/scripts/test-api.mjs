// API integration tests against an in-memory Supabase protocol fixture.
// This verifies our server's behavior; it does not replace a live project check.
import assert from 'node:assert/strict';
import {pbkdf2Sync} from 'node:crypto';
import {readFile} from 'node:fs/promises';
import {SEED} from '../lib/exhibition.ts';
import {settingsDefaults} from '../lib/settings.ts';
const password='test-only-password',salt='0123456789abcdef0123456789abcdef';
process.env.ADMIN_USERNAME='sadun';
process.env.ADMIN_PASSWORD_HASH='pbkdf2-sha256:100000:'+salt+':'+pbkdf2Sync(password,Buffer.from(salt,'hex'),100000,32,'sha256').toString('hex');
process.env.SUPABASE_URL='https://museum-fixture.invalid';
process.env.SUPABASE_SECRET_KEY='sb_secret_test_only';
const rows=new Map(SEED.map(exhibit=>[exhibit.id,{id:exhibit.id,exhibit,deleted:false}]));
const objects=new Map(),sessions=new Map(),pending=new Map();let settings={...settingsDefaults},attempts=0,failNextWrite=false,bucketLimit=104857600;
const ranges=[];
globalThis.fetch=async(url,init={})=>{
  const u=new URL(url);assert.equal(u.origin,process.env.SUPABASE_URL);
  assert.equal(new Headers(init.headers).get('apikey'),'sb_secret_test_only');
  const json=()=>JSON.parse(init.body),ok=v=>Response.json(v),method=init.method||'GET';
  if(u.pathname==='/rest/v1/rpc/museum_allow_login')return ok(++attempts<=8);
  if(u.pathname==='/rest/v1/museum_sessions'){
    if(method==='POST'){const item=json();sessions.set(item.token_hash,item);return ok({});}
    const key=u.searchParams.get('token_hash')?.slice(3);
    if(method==='DELETE'){sessions.delete(key);return ok({});}
    return ok(sessions.has(key)&&new Date(sessions.get(key).expires_at)>new Date()?[sessions.get(key)]:[]);
  }
  if(u.pathname==='/rest/v1/museum_exhibits'){
    if(method==='POST'){
      if(failNextWrite){failNextWrite=false;return Response.json({code:'test_failure'},{status:500});}
      const item=json();if(!item.deleted&&[...rows.values()].some(r=>r.id!==item.id&&!r.deleted&&r.exhibit.slot===item.exhibit.slot))return Response.json({code:'23505'},{status:409});
      rows.set(item.id,item);return ok({});
    }
    return ok([...rows.values()].filter(r=>!r.deleted));
  }
  if(u.pathname==='/rest/v1/museum_settings'){if(method==='POST'){settings=json().value;return ok({});}return ok([{value:settings}]);}
  if(u.pathname==='/rest/v1/museum_uploads'){
    if(method==='POST'){const row=json();pending.set(row.id,row);return ok({});}
    const id=u.searchParams.get('id')?.slice(3);
    if(method==='DELETE'){pending.delete(id);return ok({});}
    const before=u.searchParams.get('expires_at')?.slice(3);
    return ok([...pending.values()].filter(row=>id?row.id===id:before?Date.parse(row.expires_at)<Date.parse(before):true));
  }
  if(u.pathname==='/storage/v1/bucket/museum-art')return ok({file_size_limit:bucketLimit});
  if(u.pathname.startsWith('/storage/v1/object/upload/sign/museum-art/'))return ok({url:u.pathname+'?token=test-signed-token'});
  if(u.pathname==='/storage/v1/object/museum-art'&&method==='DELETE'){for(const id of json().prefixes)objects.delete(id);return ok({});}
  if(u.pathname.startsWith('/storage/v1/object/museum-art/')&&method==='POST'){objects.set(u.pathname.split('/').pop(),{body:init.body,mime:new Headers(init.headers).get('content-type')});return ok({});}
  if(u.pathname.startsWith('/storage/v1/object/authenticated/museum-art/')){
    const obj=objects.get(u.pathname.split('/').pop());if(!obj)return new Response('',{status:404});
    const bytes=new Uint8Array(obj.body),total=obj.size??bytes.byteLength,range=new Headers(init.headers).get('range');
    if(range){const length=Number(range.split('-')[1])+1;ranges.push(length);const part=bytes.subarray(0,length);return new Response(part,{status:206,headers:{'content-type':obj.mime,'content-range':`bytes 0-${part.length-1}/${total}`,'content-length':String(part.length)}});}
    return new Response(bytes,{headers:{'content-type':obj.mime,'content-length':String(total)}});
  }
  throw new Error('Unexpected fixture call: '+u.pathname);
};
const {default:worker}=await import('../dist/local/worker.mjs');
const assets={fetch:async req=>new Response(new URL(req.url).pathname)};
let cookie='';
async function call(path,method='GET',body,options={}){
  const headers=new Headers({Origin:'https://museum.test'});if(cookie)headers.set('Cookie',cookie);
  if(body&&!(body instanceof FormData)){headers.set('Content-Type','application/json');body=JSON.stringify(body);}
  for(const [key,value] of Object.entries(options))headers.set(key,value);
  return worker.fetch(new Request('https://museum.test'+path,{method,headers,body}),{ASSETS:assets});
}
const metadata={title:'Our test drawing',artist:'Us',year:'2026',kind:'image',slot:'main-nw',size:2.5,rotation:0,frame:'oak',description:'A test memory.'};
function form(data,file){const f=new FormData();for(const [key,value] of Object.entries(data))f.set(key,String(value));if(file)f.set('file',file);return f;}
const image=new File([await readFile('public/art/met-436535.jpg')],'drawing.jpg',{type:'image/jpeg'});
assert.equal((await call('/admin')).status,200);
assert.equal(await(await call('/admin')).text(),'/index.html');
assert.equal((await call('/api/exhibits','POST')).status,401);
assert.equal((await call('/api/exhibits/irises','PATCH',metadata)).status,401);
assert.equal((await call('/api/exhibits/irises','DELETE')).status,401);
assert.equal((await call('/api/settings','PATCH',settings)).status,401);
assert.equal((await call('/api/setup/supabase','POST',{})).status,401);
assert.equal((await call('/api/setup/supabase')).status,401);
assert.equal((await call('/api/uploads','POST',metadata)).status,401);
assert.equal((await call('/api/uploads/00000000-0000-0000-0000-000000000000','POST')).status,401);
assert.equal((await call('/api/uploads/00000000-0000-0000-0000-000000000000','DELETE')).status,401);
assert.equal((await call('/api/auth/login','POST',{username:'sadun',password:'wrong'})).status,401);
const signIn=await call('/api/auth/login','POST',{username:'sadun',password});assert.equal(signIn.status,200);
const rawCookie=signIn.headers.get('set-cookie');assert.match(rawCookie,/HttpOnly/);assert.match(rawCookie,/Secure/);assert.match(rawCookie,/SameSite=Strict/);assert.match(rawCookie,/__Host-museum_admin/);cookie=rawCookie.split(';')[0];
assert.equal((await(await call('/api/auth/session')).json()).authenticated,true);
assert.equal((await call('/api/exhibits/irises','DELETE',undefined,{Origin:'https://attacker.invalid'})).status,403);
assert.equal((await call('/api/exhibits','POST',form(metadata,new File(['bad'],'bad.glb')))).status,400);
const uploaded=await call('/api/exhibits','POST',form(metadata,image));assert.equal(uploaded.status,201);
const item=(await uploaded.json()).exhibit;assert.equal(objects.size,1);
assert.equal((await call(item.url)).status,200);
assert.equal((await call('/api/exhibits','POST',form(metadata,image))).status,409);
assert.equal((await call('/api/exhibits/'+item.id,'PATCH',{...metadata,title:'A new title',slot:'main-ne'})).status,200);
const replacement=await call('/api/exhibits/'+item.id,'PATCH',form({...metadata,slot:'main-ne'},image));assert.equal(replacement.status,200);
const changed=(await replacement.json()).exhibit;assert.notEqual(changed.url,item.url);assert.equal(objects.size,1);assert.equal((await call(item.url)).status,404);
failNextWrite=true;const failed=await call('/api/exhibits','POST',form({...metadata,slot:'main-nw'},image));assert.equal(failed.status,503);assert.equal(objects.size,1,'failed metadata save rolls back new blob');
assert.equal((await call('/api/settings','PATCH',{...settings,greeting:'Happy birthday, Manika!'})).status,200);
assert.equal((await(await call('/api/settings')).json()).settings.greeting,'Happy birthday, Manika!');
assert.equal((await call('/api/setup/supabase','POST',{})).status,403,'configuration endpoint is unavailable without the local binding');
assert.equal((await call('/api/setup/supabase','POST',{}, {Origin:'https://attacker.invalid'})).status,403);
assert.equal((await call('/api/settings','PATCH',{palette:'olive'})).status,200);
const themed=(await(await call('/api/settings')).json()).settings;assert.equal(themed.palette,'olive');assert.equal(themed.greeting,'Happy birthday, Manika!','changing the palette preserves the birthday message');
assert.equal((await call('/api/settings','PATCH',{palette:'invalid'})).status,400);
const gltf=Buffer.from(JSON.stringify({asset:{version:'2.0'},scene:0,scenes:[{nodes:[]}]}));
const padded=Buffer.alloc(Math.ceil(gltf.length/4)*4,32);gltf.copy(padded);const glb=Buffer.alloc(20+padded.length);glb.writeUInt32LE(0x46546c67,0);glb.writeUInt32LE(2,4);glb.writeUInt32LE(glb.length,8);glb.writeUInt32LE(padded.length,12);glb.writeUInt32LE(0x4e4f534a,16);padded.copy(glb,20);
const model=await call('/api/exhibits','POST',form({...metadata,title:'Test sculpture',kind:'model',slot:'plinth-west'},new File([glb],'model.glb',{type:'model/gltf-binary'})));assert.equal(model.status,201);
assert.equal((await call('/api/exhibits/'+item.id,'DELETE')).status,200);assert.equal((await call(changed.url)).status,404);
assert.equal((await call('/api/exhibits/irises','DELETE')).status,200);assert.equal(rows.get('irises').deleted,true);
// Direct, resumable upload lifecycle: original-size limit, server verification,
// retries, cancellation, replacement, plan limits, and bounded reads.
const MiB=1024*1024,uploadMeta={...metadata,bytes:image.size,originalBytes:100*MiB,mime:'image/jpeg'};
assert.equal((await call('/api/uploads','POST',uploadMeta,{Origin:'https://attacker.invalid'})).status,403);
assert.equal((await call('/api/uploads','POST',{...uploadMeta,originalBytes:100*MiB+1})).status,400);
assert.equal((await call('/api/uploads','POST',{...uploadMeta,bytes:100*MiB+1})).status,400);
async function prepare(data=uploadMeta){const response=await call('/api/uploads','POST',data);assert.equal(response.status,200,await response.clone().text());return response.json();}
const ticket=await prepare();assert.equal(ticket.token,'test-signed-token');assert.match(ticket.endpoint,/\/storage\/v1\/upload\/resumable$/);
assert.equal((await call('/api/assets/'+ticket.uploadId)).status,404,'pending files are not public exhibits');
objects.set(ticket.uploadId,{body:await image.arrayBuffer(),mime:'image/jpeg'});
const finish=await call('/api/uploads/'+ticket.uploadId,'POST');assert.equal(finish.status,201);const direct=(await finish.json()).exhibit;
assert.equal(direct.originalBytes,100*MiB);assert.equal(direct.storedBytes,image.size);assert.equal(pending.has(ticket.uploadId),false);
assert.equal((await call('/api/uploads/'+ticket.uploadId,'POST')).status,200,'completion is idempotent');
assert.equal((await call('/api/uploads/'+ticket.uploadId,'DELETE')).status,200);assert.ok(objects.has(ticket.uploadId),'cancel cannot delete a published file');
const replace=await prepare({...uploadMeta,replaceId:direct.id});objects.set(replace.uploadId,{body:await image.arrayBuffer(),mime:'image/jpeg'});
assert.equal((await call('/api/uploads/'+replace.uploadId,'POST')).status,200);assert.equal(objects.has(ticket.uploadId),false,'replacement removes previous blob');
const partial=await prepare({...uploadMeta,slot:'main-ne'});objects.set(partial.uploadId,{body:await image.slice(0,32).arrayBuffer(),mime:'image/jpeg'});
assert.equal((await call('/api/uploads/'+partial.uploadId,'POST')).status,400,'incomplete uploads cannot be published');
assert.equal((await call('/api/uploads/'+partial.uploadId,'DELETE')).status,200);assert.equal(objects.has(partial.uploadId),false);
const wrong=await prepare({...uploadMeta,slot:'main-ne'});objects.set(wrong.uploadId,{body:Buffer.alloc(image.size),mime:'image/jpeg'});
assert.equal((await call('/api/uploads/'+wrong.uploadId,'POST')).status,400,'forged content type rejected');await call('/api/uploads/'+wrong.uploadId,'DELETE');
bucketLimit=50*MiB;assert.equal((await call('/api/uploads','POST',{...uploadMeta,slot:'main-ne',bytes:60*MiB})).status,413);bucketLimit=100*MiB;
const large=await prepare({...metadata,slot:'plinth-west2',kind:'model',mime:'model/gltf-binary',bytes:100*MiB,originalBytes:100*MiB});
const largeHeader=Buffer.from(glb);largeHeader.writeUInt32LE(100*MiB,8);
objects.set(large.uploadId,{body:largeHeader,mime:'model/gltf-binary',size:100*MiB});
const largeFinish=await call('/api/uploads/'+large.uploadId,'POST');assert.equal(largeFinish.status,201,await largeFinish.clone().text());
assert.ok(Math.max(...ranges)<=20+4*MiB,'verification only requests bounded file headers, never a 100 MB body');
const stale=await prepare({...uploadMeta,slot:'main-ne'});pending.get(stale.uploadId).expires_at=new Date(Date.now()-4*3600000).toISOString();objects.set(stale.uploadId,{body:await image.arrayBuffer(),mime:'image/jpeg'});
const next=await prepare({...uploadMeta,slot:'main-ne'});assert.equal(pending.has(stale.uploadId),false);assert.equal(objects.has(stale.uploadId),false);await call('/api/uploads/'+next.uploadId,'DELETE');
assert.equal((await call('/api/auth/logout','POST')).status,200);
assert.equal((await(await call('/api/auth/session')).json()).authenticated,false,'replaying a signed-out session fails');
assert.equal((await call('/api/exhibits','POST')).status,401);
cookie='museum_admin=forged';assert.equal((await(await call('/api/auth/session')).json()).authenticated,false);
cookie='';for(let i=0;i<7;i++)await call('/api/auth/login','POST',{username:'sadun',password:'wrong'});
assert.equal((await call('/api/auth/login','POST',{username:'sadun',password})).status,429);
const oversized=new Request('https://museum.test/api/auth/login',{method:'POST',headers:{Origin:'https://museum.test'},body:'x'.repeat(5000)});
// A blocked IP may be rejected before body parsing, which is also safe.
assert.ok([413,429].includes((await worker.fetch(oversized,{ASSETS:assets})).status));
console.log('PASS: auth, cookies, CSRF, upload/replace/delete, rollback, 100 MB resumable lifecycle, bounded verification, cancellation, plan limits, orphan cleanup, settings, GLB, logout, and throttling. Supabase transport is mocked.');
