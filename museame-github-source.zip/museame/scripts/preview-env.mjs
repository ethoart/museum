import {loadEnvFile} from 'node:process';
try{loadEnvFile('.env.local');}catch(e){if(e.code!=='ENOENT')throw e;}
export const env={...process.env,LOCAL_PREVIEW:'true'};
