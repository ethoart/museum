"""Build a dependency-free deployment ZIP from the tested production output."""
from hashlib import sha256
import argparse
from pathlib import Path
import shutil
import zipfile

root = Path(__file__).resolve().parents[1]
parser = argparse.ArgumentParser()
parser.add_argument('--output', type=Path, default=root / 'release')
output = parser.parse_args().output.resolve()
output.mkdir(parents=True, exist_ok=True)
archive = output / 'museum-of-love-aws.zip'
files = [
    *sorted((root / 'dist/client').rglob('*')),
    root / 'dist/node/worker.mjs',
    *sorted((root / 'deploy/aws').rglob('*')),
    *[root / 'scripts' / name for name in ['serve-production.mjs', 'production-server.mjs', 'production-config.mjs', 'check-production.mjs', 'start-pm2.mjs']],
    root / 'ecosystem.config.cjs',
    root / 'supabase/schema.sql',
    root / 'AWS-HOSTING.md',
    root / 'GITHUB-PM2-CLOUDFLARE.md',
]
assert (root / 'dist/client/index.html').is_file(), 'Run npm run build first.'
assert (root / 'dist/node/worker.mjs').is_file(), 'Production API bundle is missing.'
files = [file for file in files if file.is_file() and '__pycache__' not in file.parts]
with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED, strict_timestamps=False) as bundle:
    for file in files:
        assert not file.name.startswith('.env') or file.name == '.env.example'
        assert file.suffix not in {'.pem', '.log', '.pyc'}
        bundle.write(file, Path('museum-of-love') / file.relative_to(root))
with zipfile.ZipFile(archive) as bundle:
    assert bundle.testzip() is None
    assert not any('node_modules/' in name or '/dist/local/' in name or '/.openai/' in name for name in bundle.namelist())
shutil.copy2(root / 'AWS-HOSTING.md', output / 'Museum-of-Love-AWS-Hosting.md')
(output / 'museum-of-love-aws.zip.sha256').write_text(sha256(archive.read_bytes()).hexdigest() + '  ' + archive.name + '\n', encoding='ascii')
print(f'AWS release: {len(files)} files; {archive.stat().st_size:,} bytes. ZIP integrity and exclusions verified.')
