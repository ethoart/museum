import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Museum of Love · For Manika",
  description: "A birthday museum for Manika. Our drawings, our memories, our love.",
  icons: {
    icon: "/favicon.svg",
    shortcut: "/favicon.svg",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body className="antialiased">{children}</body>
    </html>
  );
}
