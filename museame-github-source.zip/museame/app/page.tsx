import Museum from '@/components/museum';
export default function Home() { return <Museum />; }
