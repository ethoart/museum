import { getExhibits, supabase } from '@/lib/storage';
export async function GET(_:Request,{params}:{params:Promise<{id:string}>}) {
  const {id}=await params;if(!/^[a-z0-9-]{1,80}$/.test(id))return new Response('Not found',{status:404});
  try{if(!(await getExhibits()).some(e=>e.url==='/api/assets/'+id))return new Response('Not found',{status:404});
    const obj=await supabase('/storage/v1/object/authenticated/museum-art/'+id);
    return new Response(obj.body,{headers:{'Content-Type':obj.headers.get('content-type')||'application/octet-stream','Cache-Control':'private, max-age=86400, immutable','X-Content-Type-Options':'nosniff'}});
  }catch{return new Response('Artwork unavailable',{status:503});}
}
