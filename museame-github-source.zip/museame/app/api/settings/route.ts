import { readJson } from '@/lib/request-body';
import { failure, getSettings, supabase } from '@/lib/storage';
import { validateSettingsPatch } from '@/lib/settings';
import { requireAdmin } from '@/lib/auth';
export async function GET(){try{return Response.json({settings:await getSettings()},{headers:{'Cache-Control':'no-store'}});}catch(e){return failure(e);}}
export async function PATCH(req:Request){
  const denied=await requireAdmin(req);if(denied)return denied;
  try{if(Number(req.headers.get('content-length'))>10000)throw new Error('The message is too long.');
    const value=validateSettingsPatch(await readJson(req),await getSettings());
    await supabase('/rest/v1/museum_settings?on_conflict=id',{method:'POST',headers:{'Content-Type':'application/json',Prefer:'resolution=merge-duplicates'},body:JSON.stringify({id:'birthday',value})});
    return Response.json({settings:value});
  }catch(e){return failure(e);}
}
