import { readForm, readJson } from '@/lib/request-body';
import { getExhibits, failure, saveExhibit, uploadAsset, deleteAsset } from '@/lib/storage';
import { validateExhibit } from '@/lib/exhibition';
import { requireAdmin } from '@/lib/auth';
import { readUpload } from '@/lib/upload';
export async function GET() { try{return Response.json({exhibits:await getExhibits()},{headers:{'Cache-Control':'no-store'}});}catch(e){return failure(e,503);} }
export async function POST(req:Request) {
  const denied=await requireAdmin(req);if(denied)return denied;
  try {
    if(Number(req.headers.get('content-length'))>34*1024*1024) return failure(new Error('Choose a file smaller than 30 MB.'),413);
    const form=await readForm(req), file=form.get('file');
    if(!(file instanceof File))throw new Error('Choose a file to exhibit.');
    const data=validateExhibit(Object.fromEntries(form.entries()));
    if((await getExhibits()).some(e=>e.slot===data.slot))return failure(new Error('That position is occupied. Choose another display position.'),409);
    const {bytes,mime}=await readUpload(file,data.kind),id=crypto.randomUUID();
    await uploadAsset(id,bytes,mime);
    const exhibit={...data,id,url:'/api/assets/'+id};
    try{await saveExhibit(exhibit);}catch(e){await deleteAsset(id).catch(()=>console.error('Could not clean up an unsaved upload'));throw e;}
    return Response.json({exhibit},{status:201});
  }catch(e){return failure(e);}
}
