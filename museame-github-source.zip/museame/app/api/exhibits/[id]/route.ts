import { readForm, readJson } from '@/lib/request-body';
import { getExhibits, failure, saveExhibit, uploadAsset, deleteAsset, assetId } from '@/lib/storage';
import { validateExhibit } from '@/lib/exhibition';
import { requireAdmin } from '@/lib/auth';
import { readUpload } from '@/lib/upload';
async function target(params:Promise<{id:string}>) { const {id}=await params;if(!/^[a-z0-9-]{1,80}$/.test(id)) throw new Error('Invalid exhibit.');return id; }
export async function PATCH(req:Request,{params}:{params:Promise<{id:string}>}) {
  const denied=await requireAdmin(req);if(denied)return denied;
  try{const id=await target(params),all=await getExhibits(),item=all.find(e=>e.id===id);if(!item)return failure(new Error('Exhibit not found.'),404);
    if(Number(req.headers.get('content-length'))>34*1024*1024)return failure(new Error('Choose a file smaller than 30 MB.'),413);
    let input:Record<string,unknown>,file:File|null=null;
    if(req.headers.get('content-type')?.startsWith('multipart/form-data')){const form=await readForm(req);input=Object.fromEntries(form.entries());const entry=form.get('file');if(entry instanceof File&&entry.size)file=entry;}
    else input=await readJson(req);
    const data=validateExhibit({...item,...input,kind:item.kind});
    if(all.some(e=>e.id!==id&&e.slot===data.slot)) return failure(new Error('That position is occupied.'),409);
    const exhibit={...item,...data};let newAsset='';
    if(file){const {bytes,mime}=await readUpload(file,item.kind);newAsset=crypto.randomUUID();await uploadAsset(newAsset,bytes,mime);exhibit.url='/api/assets/'+newAsset;delete exhibit.builtin;delete exhibit.source;}
    try{await saveExhibit(exhibit);}catch(e){if(newAsset)await deleteAsset(newAsset).catch(()=>console.error('Could not clean up an unsaved replacement'));throw e;}
    const oldAsset=assetId(item);if(newAsset&&oldAsset)await deleteAsset(oldAsset).catch(()=>console.error('Old replacement asset needs cleanup'));
    return Response.json({exhibit});
  }catch(e){return failure(e);}
}
export async function DELETE(req:Request,{params}:{params:Promise<{id:string}>}) {
  const denied=await requireAdmin(req);if(denied)return denied;
  try{const id=await target(params),item=(await getExhibits()).find(e=>e.id===id);if(!item)return failure(new Error('Exhibit not found.'),404);
    await saveExhibit(item,true);const oldAsset=assetId(item);if(oldAsset)await deleteAsset(oldAsset).catch(()=>console.error('Removed asset needs cleanup'));
    return Response.json({ok:true});
  }catch(e){return failure(e);}
}
