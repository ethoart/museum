# Museum of Love: GitHub → Ubuntu → npm → PM2 → Cloudflare Tunnel

Repository target: **ethoart/museame** (private recommended). The files are prepared for this workflow. The domain is entered during setup. Never put the Cloudflare token, Supabase key or admin password in GitHub.

```text
Your domain, HTTPS → Cloudflare → encrypted tunnel → cloudflared on Ubuntu
                                                      ↓
                                        127.0.0.1:3000, museum under PM2
                                                      ↓
                                                   Supabase
```

This guide uses Ubuntu 24.04 x86_64 on your AWS t3.small. It replaces the Caddy/systemd-app setup in AWS-HOSTING.md. PM2 manages the museum; a separate systemd service keeps the Cloudflare connector running. Automated app tests cover both proxy modes. Live GitHub publishing, Linux installation and the tunnel still need verification on your accounts.

## 1. Put the source on GitHub

Create a **private repository** named `museame` under `ethoart`. For the assistant to upload through the GitHub connector, enable **Add a README** so the repository has an initial branch. If you will publish manually using the commands below instead, start with an empty repository without a README. Preserve existing files when integrating this project; do not force-push over another project.

Once GitHub access is connected in chat, the assistant can finish publishing the prepared source. To publish it yourself, extract the latest source ZIP, open a terminal in its `museum-of-love` folder and run:

```bash
git init -b main
git add .
git diff --cached --stat
git commit -m "Add Museum of Love with PM2 and Cloudflare deployment"
git remote add origin git@github.com:ethoart/museame.git
git push -u origin main
```

Configure Git's author name/email if it asks. Authenticate using your GitHub SSH key or GitHub Desktop. Do not put access tokens in Git URLs. The supplied `.gitignore` excludes private environment files, tokens, keys, generated builds and dependencies. Commit `package-lock.json`: the server uses `npm ci` for the locked dependencies.

## 2. Prepare the Ubuntu server

Launch **Ubuntu 24.04 LTS, x86_64, t3.small**, with at least 20 GiB disk space. Keep SSH port 22 open only to your IP. This tunnel setup does not require inbound ports 80, 443, 3000 or 5173. The server still needs outbound internet access; Cloudflare Tunnel uses TCP/UDP 7844, and installation/Supabase use HTTPS. [Cloudflare tunnel firewall requirements](https://developers.cloudflare.com/cloudflare-one/networks/connectors/cloudflare-tunnel/configure-tunnels/tunnel-with-firewall/).

Connect from your computer:

```powershell
ssh -i "C:\path\museum-key.pem" ubuntu@YOUR_SERVER_IP
```

The commands below run in that SSH terminal as **ubuntu**, unless prefixed with `sudo`.

```bash
sudo apt-get update
sudo apt-get install -y git curl ca-certificates
ssh-keygen -t ed25519 -f ~/.ssh/museum_github -C museum-server
cat ~/.ssh/museum_github.pub
```

Copy the **public** key into GitHub → `ethoart/museame` → Settings → Deploy keys → Add deploy key. Leave write access disabled. Keep the private key on the VPS. [GitHub deploy keys](https://docs.github.com/en/authentication/connecting-to-github-with-ssh/managing-deploy-keys).

Clone the repository, accepting GitHub's host key only after checking its published fingerprint:

```bash
GIT_SSH_COMMAND='ssh -i /home/ubuntu/.ssh/museum_github -o IdentitiesOnly=yes' git clone git@github.com:ethoart/museame.git ~/museame
cd ~/museame
git config core.sshCommand 'ssh -i /home/ubuntu/.ssh/museum_github -o IdentitiesOnly=yes'
sudo bash deploy/aws/install-runtime.sh tunnel
```

The helper installs current Node 24 LTS, npm, PM2 and cloudflared. It verifies the Node archive checksum and uses Cloudflare's official apt repository. [Node releases](https://nodejs.org/en/about/previous-releases), [PM2 installation](https://pm2.keymetrics.io/docs/usage/quick-start/), [Cloudflare packages](https://pkg.cloudflare.com/).

### Build memory on t3.small

It has 2 GiB RAM. A 2 GiB swap file provides extra room during npm installation and builds. Check `swapon --show` first. On a fresh server with no swap and no existing `/swapfile`, run:

```bash
sudo fallocate -l 2G /swapfile
sudo chmod 600 /swapfile
sudo mkswap /swapfile
sudo swapon /swapfile
printf '%s\n' '/swapfile none swap sw 0 0' | sudo tee -a /etc/fstab
```

Do not repeat these commands over an existing swap file. Swap helps avoid memory exhaustion; it does not make the server faster.

## 3. Install and build with npm

```bash
cd ~/museame
npm ci --include=dev
npm run typecheck
NODE_OPTIONS=--max-old-space-size=1024 npm run build
npm run test:production
```

Use `npm ci` for repeatable installs. `npm install` also works, but can update the dependency lock. Build tools are dev dependencies, so do not omit them before building. Run npm as `ubuntu`, not with sudo.

## 4. Configure Supabase and the admin account

In your Supabase museum project, run **supabase/schema.sql** in SQL Editor. This creates the private bucket, tables, login function and birthday settings. Keep your project URL and secret server key ready. The chat account connection alone does not configure this website.

```bash
cd ~/museame
sudo python3 deploy/aws/configure.py --pm2-user ubuntu --proxy cloudflare
/usr/local/bin/node --env-file=/etc/museum/museum.env scripts/check-production.mjs
```

Enter your full museum hostname, without `https://`—for example, `museum.yourdomain.com`. Enter the Supabase URL/key, choose the file limit, use admin username **sadun**, and set your admin password. Hidden prompts prevent the key and password from appearing in shell history.

The helper saves `/etc/museum/museum.env` as root-owned, readable by ubuntu's group. PM2 loads it inside the museum process; it is not stored in the repository or ecosystem config. `PROXY_MODE=cloudflare` selects the tunnel headers. The original Caddy setup remains available with `--proxy caddy`.

Original uploads can be up to 100 MiB and are optimized before storage. Supabase Free limits the stored file to 50 MB. Choose **50** unless your plan and global storage limit support **100**. Keep backups of original artwork. [Supabase file limits](https://supabase.com/docs/guides/storage/uploads/file-limits).

## 5. Start with PM2

If you previously installed the old museum systemd service, stop it first so it does not compete for port 3000:

```bash
sudo systemctl disable --now museum
```

Skip that command on a fresh server. Then:

```bash
cd ~/museame
npm run pm2:start
pm2 save
pm2 startup
```

PM2 prints a `sudo ...` startup command. Run that exact command, then run `pm2 save` again. Always manage the museum with PM2 as **ubuntu**; using `sudo pm2` creates a separate root process list. This setup runs one museum process and restarts it if it crashes. [PM2 startup and recovery](https://pm2.keymetrics.io/docs/usage/startup/).

```bash
pm2 status
npm run pm2:logs
```

Press Ctrl+C to leave the log view; the museum keeps running. The museum is listening only on `127.0.0.1:3000` until the tunnel connects.

## 6. Create the tunnel for your domain

Your domain must be active in your Cloudflare account. In Cloudflare's tunnel dashboard (available through Zero Trust / Networks / Connectors or the Tunnels page):

1. Create a **Cloudflared**, remotely managed tunnel named **museum-of-love**.
2. Choose Linux/Debian, 64-bit for the connector instructions.
3. Copy only the tunnel token from the installation command. Do not post it in chat or GitHub. This is a **tunnel token**, not a general Cloudflare API token.
4. On your VPS, save it using the private prompt:

```bash
cd ~/museame
sudo python3 deploy/aws/set-tunnel-token.py
sudo cp deploy/aws/cloudflared-museum.service /etc/systemd/system/cloudflared-museum.service
sudo systemctl daemon-reload
sudo systemctl enable --now cloudflared-museum
sudo systemctl status cloudflared-museum --no-pager
```

This uses cloudflared's `--token-file` option, supported from version 2025.4.0. The token is stored in `/etc/museum/cloudflare.token`, readable only by root. You do not also need to run the dashboard's `service install TOKEN` command. [Tunnel token-file option](https://developers.cloudflare.com/tunnel/reference/run-parameters/#token-file).

5. Wait for the connector to show **Healthy** in Cloudflare.
6. Add a **published application route / public hostname**:

| Field | Value |
|---|---|
| Hostname | The exact domain entered in step 4 |
| Service type | HTTP |
| Service URL | `127.0.0.1:3000` |
| HTTP Host Header, under additional settings | Your museum hostname, without protocol |

Save it. Cloudflare creates the tunnel DNS route. If an old A/AAAA/CNAME record already occupies that museum hostname, resolve that specific conflict in DNS first; keep unrelated domain records.

7. In your domain's **SSL/TLS → Edge Certificates**, enable **Always Use HTTPS**. The app requires the visitor to use HTTPS. The local hop from cloudflared to the museum is HTTP on loopback; do not set the tunnel service to HTTPS on port 3000.
8. Keep Cloudflare's visitor IP headers enabled; the museum uses `CF-Connecting-IP` for login throttling. Avoid custom Workers or header-transform rules on this hostname unless you account for their effects. [Cloudflare request headers](https://developers.cloudflare.com/fundamentals/reference/http-headers/).
9. If you use custom cache rules, bypass cache for `/api/*` and `/admin*` and respect the app's cache headers. Do not apply “Cache Everything” to admin/API responses.

Cloudflare supplies the public HTTPS connection and the tunnel; the museum's `/admin` sign-in controls editing. You do not need to create a Cloudflare Access login policy for the public birthday museum. [Cloudflare tunnel setup](https://developers.cloudflare.com/tunnel/get-started/).

## 7. Verify and share

Visit `https://YOUR_DOMAIN/` and `https://YOUR_DOMAIN/admin`. Sign in as **sadun** with the password from step 4. Upload a small test drawing, reload, edit, replace and remove it. Check a GLB model and the birthday message before sharing the link.

```bash
curl --fail https://YOUR_DOMAIN/healthz
curl --fail https://YOUR_DOMAIN/api/settings
```

The first checks the app process; the second checks a Supabase read. Confirm recovery after a planned server reboot by checking both `pm2 status` and `sudo systemctl status cloudflared-museum`.

## Updates from GitHub

Commit and push source changes from your computer. On Ubuntu, record the current commit so you can return to it if needed:

```bash
cd ~/museame
git rev-parse HEAD
git pull --ff-only
npm ci --include=dev
npm run typecheck
pm2 stop museum-of-love
NODE_OPTIONS=--max-old-space-size=1024 npm run build
npm run test:production
npm run pm2:restart
pm2 save
```

The website has brief downtime during the build/restart. If the build or tests fail, keep the app stopped while repairing or restoring the previous source and rebuilding; don't restart with a partially written build. Private server settings, the tunnel and Supabase content stay separate from Git.

For only a password/key/domain change, rerun the configuration helper, run the connection check, and use `npm run pm2:restart`. If the domain changes, also update the Cloudflare hostname/Host Header. Rotating the admin password does not revoke existing sessions; run `delete from public.museum_sessions;` in Supabase to sign out all admins when needed.

Rotate a tunnel token in Cloudflare, rerun `set-tunnel-token.py`, then `sudo systemctl restart cloudflared-museum`.

## Troubleshooting

| Problem | Check |
|---|---|
| Repository not found | `ethoart/museame` has been created/pushed, and the VPS public deploy key is attached to it. |
| npm build killed | Swap enabled, sufficient free disk/memory, Node 24 in use, dev dependencies installed. |
| Tunnel unhealthy / error 1033 | Token, connector service, outbound TCP/UDP 7844 and DNS. |
| Cloudflare 502 | PM2 app running on 127.0.0.1:3000; tunnel service uses HTTP. |
| `Unrecognized host` | Tunnel HTTP Host Header and PUBLIC_ORIGIN use the same hostname. |
| `HTTPS is required` | Visit the HTTPS URL and enable Always Use HTTPS. |
| `Use the configured reverse proxy` | `PROXY_MODE=cloudflare`, visitor IP headers enabled, and request arrives through the tunnel. |
| Cannot read museum.env | Run configure.py with `--pm2-user ubuntu`; run PM2 as ubuntu. |
| Supabase error | Active project, correct secret server key, full schema SQL applied, then run check-production.mjs. |

Logs:

```bash
pm2 logs museum-of-love --lines 60
sudo journalctl -u cloudflared-museum -n 60 --no-pager
```

Keep encrypted backups of server settings, originals, database and Storage objects. Rotate/limit PM2 logs as usage grows, and keep Node, PM2 and cloudflared updated. AWS, domain registration and Supabase costs still apply according to your plans.
