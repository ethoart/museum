# Museum of Love — host on AWS EC2

This guide installs your museum on a **new Ubuntu 24.04 LTS, x86_64, t3.small** server. It includes the visitor museum, `/admin`, HTTPS, automatic restarts, and Supabase storage.

Use **museum-of-love-aws.zip** for hosting. It is already built and needs no npm installation on the server. Keep **museum-of-love-source.zip** for editing the website. The AWS ZIP includes this guide and all the server setup files.

The release has passed local build and automated server tests. It has not been deployed or tested on a live EC2 instance. You still need an AWS account, a domain, and an active Supabase project. No passwords, Supabase keys, or AWS credentials are included.

## How it works

```text
Visitor → your domain over HTTPS → Caddy → museum server on 127.0.0.1:3000
                                             ↓
                                        Supabase
                                artwork files + museum database
```

The 3D scene runs on the visitor's device. AWS serves the website and protected API. Large uploads go from the admin browser directly to Supabase with a temporary upload token; the private server key stays on EC2.

A t3.small has 2 vCPUs and 2 GiB of memory and uses burstable CPU credits. This is a reasonable starting point for a small personal museum, but no concurrent-visitor capacity has been measured. This guide avoids building the source on that small server. [AWS instance specifications](https://docs.aws.amazon.com/ec2/latest/instancetypes/gp.html).

## 1. Prepare Supabase

Do this on your computer before starting the server:

1. Open the [Supabase dashboard](https://supabase.com/dashboard). Create a dedicated **Museum of Love** project, or choose the museum project if you have already created it. Review the plan and any charges in Supabase.
2. Extract either museum ZIP. Open **supabase/schema.sql** in a text editor.
3. In the project's **SQL Editor**, create a query, paste the whole file, and run it. Use the complete script: it creates the private `museum-art` bucket, museum tables, login function, starter artworks, and birthday message. Re-running it preserves existing museum edits.
4. Copy the project's HTTPS URL, such as `https://abcdefghijklmnopqrst.supabase.co`.
5. Under **Settings → API Keys**, find a **secret server key** beginning `sb_secret_`. A legacy `service_role` key also works. The database password and publishable/anon key are different credentials.
6. Keep the URL and secret available for step 6. The setup helper asks for them privately.

The chat's Supabase connection does not configure the website. Each hosted museum needs its own server settings. Supabase secret keys belong only on the server. [API key documentation](https://supabase.com/docs/guides/api/api-keys).

### Your 100 MB uploads

The admin accepts original images and GLB models up to **100 MiB**, then optimizes them in the browser. Keep your original drawings and models separately; the stored copy may be compressed.

On Supabase Free, each **stored** file must fit within its 50 MB limit. Choose **50** during server setup. A 100 MB original works if optimization reduces it enough.

For stored files above 50 MB, use a qualifying plan, increase the project's global Storage file-size limit to at least 100 MB, and choose **100** during server setup. The included SQL sets the bucket ceiling to 100 MiB; the global project limit still applies. [Supabase file limits](https://supabase.com/docs/guides/storage/uploads/file-limits).

## 2. Create the EC2 server

In AWS Console → **EC2 → Launch instance**, choose:

| Setting | Value |
|---|---|
| Name | Museum of Love |
| Region | Near your visitors, such as Singapore or Mumbai |
| Operating system | Ubuntu Server 24.04 LTS |
| Architecture | 64-bit x86 / x86_64 |
| Instance type | t3.small |
| Storage | 20 GiB gp3 is a reasonable starting size |
| Key pair | Create/download a `.pem` key and keep it private |
| Network | A public subnet with internet access and a public IPv4 address |

Create a security group with these inbound rules:

| Type | Protocol / port | Source |
|---|---|---|
| SSH | TCP 22 | **My IP** only |
| HTTP | TCP 80 | `0.0.0.0/0` |
| HTTPS | TCP 443 | `0.0.0.0/0` |

Leave outbound internet access enabled so the server can reach Supabase, package repositories, DNS and certificate services. Keep ports **3000** and **5173** closed to the internet. If you deliberately enable IPv6, add equivalent web rules and configure IPv6 routing. [AWS security-group examples](https://docs.aws.amazon.com/AWSEC2/latest/UserGuide/security-group-rules-reference.html).

Launch the instance and wait for its status checks to pass.

AWS charges can include the instance, EBS disk, public IPv4 address, data transfer and surplus CPU credits in Unlimited mode. Supabase and domain registration have separate plans. Review costs in your selected region; this setup is not a promise of free hosting. [AWS burstable CPU billing](https://docs.aws.amazon.com/AWSEC2/latest/UserGuide/burstable-performance-instances-unlimited-mode.html).

## 3. Point your domain to the server

1. In EC2 → **Elastic IP addresses**, allocate an Elastic IP and associate it with this instance. It provides a stable public address across stops and starts. AWS charges for public IPv4 addresses, including Elastic IPs. [AWS Elastic IP documentation](https://docs.aws.amazon.com/AWSEC2/latest/UserGuide/elastic-ip-addresses-eip.html).
2. At your domain's DNS provider, add an **A record**, for example:

   - Name: `museum`
   - Value: your Elastic IP
   - Result: `museum.yourdomain.com`

3. Use **DNS only** if your DNS provider offers an optional proxy. The supplied IP-based login protection assumes visitors connect directly to Caddy.
4. Remove a conflicting AAAA record unless this EC2 server also has working public IPv6.
5. Wait until the name resolves to the Elastic IP. In Windows PowerShell, run:

```powershell
nslookup museum.yourdomain.com
```

Throughout this guide, replace **museum.yourdomain.com**, **YOUR_ELASTIC_IP**, and the key-file path with your real values. The public site needs HTTPS: opening its raw IP is not the final setup.

## 4. Upload the ready-to-run ZIP

Run these commands in **PowerShell on your computer**, in the folder containing the downloaded AWS ZIP and checksum:

```powershell
scp -i "C:\path\museum-key.pem" museum-of-love-aws.zip museum-of-love-aws.zip.sha256 ubuntu@YOUR_ELASTIC_IP:~
ssh -i "C:\path\museum-key.pem" ubuntu@YOUR_ELASTIC_IP
```

The Ubuntu image uses the username **ubuntu**. Your SSH key stays on your computer.

You are now inside the EC2 server. Run the remaining Linux commands there, unless a step says otherwise.

```bash
sudo apt-get update
sudo apt-get install -y unzip
cd ~
sha256sum --check museum-of-love-aws.zip.sha256
unzip museum-of-love-aws.zip
cd ~/museum-of-love
sudo bash deploy/aws/install-runtime.sh
```

The checksum should say `OK`. The installer adds the latest patched **Node.js 24 LTS** from the official download server, verifies its published SHA-256 checksum, and installs **Caddy** from its official stable package repository. It is intended for this fresh Ubuntu server. [Node releases](https://nodejs.org/en/about/previous-releases), [Caddy installation](https://caddyserver.com/docs/install#debian-ubuntu-raspbian).

No `npm install` is needed for this ready-to-run ZIP.

## 5. Install the museum files

Still in the EC2 SSH terminal:

```bash
sudo useradd --system --user-group --home-dir /opt/museum --shell /usr/sbin/nologin museum
sudo mkdir -p /opt/museum/releases/release-1
sudo cp -a ~/museum-of-love/. /opt/museum/releases/release-1/
sudo chown -R root:root /opt/museum/releases/release-1
sudo chmod -R u=rwX,go=rX /opt/museum/releases/release-1
sudo ln -s /opt/museum/releases/release-1 /opt/museum/current
```

These are first-install commands. If `museum` or `current` already exists, use the update section below instead of repeating this step.

## 6. Enter your private settings

```bash
cd /opt/museum/current
sudo python3 deploy/aws/configure.py
```

The helper asks for:

- Your domain, such as `museum.yourdomain.com`, without `https://`.
- The Supabase project URL.
- The secret server key; it is hidden while you type or paste.
- Stored-file limit: **50** for Free, or **100** when enabled in Supabase.
- Admin username: press Enter to use **sadun**.
- Your admin password, entered twice. You can enter the password you chose for the local museum.

It saves `/etc/museum/museum.env`, readable only by root. The admin password is stored as a salted hash. Systemd reads these settings for the museum service. They are outside the website and release folder.

Check the connection before starting:

```bash
sudo /usr/local/bin/node --env-file=/etc/museum/museum.env scripts/check-production.mjs
```

Proceed when it confirms the private bucket, tables, birthday settings and sign-in function. If it fails, resolve the error using the troubleshooting section. The check uses the server key and creates one temporary login-limit test record; it does not upload or replace artwork.

The **Connect Supabase** button in the local `/admin` page is for the local computer. On AWS, use this helper and environment file to configure the connection.

## 7. Start the museum automatically

```bash
sudo cp /opt/museum/current/deploy/aws/museum.service /etc/systemd/system/museum.service
sudo systemctl daemon-reload
sudo systemctl enable --now museum
sudo systemctl status museum --no-pager
```

The status should be **active (running)**. The service runs as the dedicated `museum` account and restarts after a crash or server reboot. Its Node memory setting leaves room for Ubuntu and Caddy.

## 8. Enable your domain and HTTPS

```bash
sudo cp /opt/museum/current/deploy/aws/Caddyfile /etc/caddy/Caddyfile
sudo nano /etc/caddy/Caddyfile
```

Change **museum.example.com** on the site-address line to your domain, for example **museum.yourdomain.com**. It must match the domain entered in step 6. Keep the other settings. In nano, save with **Ctrl+O**, Enter, then exit with **Ctrl+X**.

```bash
sudo caddy validate --config /etc/caddy/Caddyfile --adapter caddyfile
sudo systemctl enable --now caddy
sudo systemctl reload caddy
sudo systemctl status caddy --no-pager
```

Caddy obtains and renews the certificate and redirects HTTP to HTTPS. Your DNS must already point to the server, and ports 80 and 443 must be reachable. A separate certificate installation command is unnecessary. [Caddy automatic HTTPS](https://caddyserver.com/docs/automatic-https).

## 9. Check your live museum

Open these addresses in your browser, using your actual domain:

- **Museum:** `https://museum.yourdomain.com/`
- **Admin:** `https://museum.yourdomain.com/admin`

Sign in as **sadun** with the password entered in step 6. Try these checks before sharing the birthday gift:

1. Walk through the main, east and west galleries and inspect a painting.
2. Confirm the birthday letter says **Manika**.
3. In admin, upload a small drawing into a free display position. Reload the museum and confirm it remains.
4. Edit its title, replace its image, then remove that test exhibit.
5. Try a small GLB model and the Appearance palette controls.
6. Sign out and confirm that editing requires signing in again.
7. Test the site on your phone. Graphics performance depends on the visitor's device.

Optional server checks:

```bash
curl --fail https://museum.yourdomain.com/healthz
curl --fail https://museum.yourdomain.com/api/settings
```

`healthz` checks that the web server is responding; it does not check Supabase. The settings response confirms a database read. The connection checker from step 6 is more thorough.

## Troubleshooting

| What you see | What to check |
|---|---|
| SSH times out | Instance running, correct Elastic IP, public subnet, TCP 22 allowed from your current IP. |
| `Permission denied (publickey)` | Use username `ubuntu` and the private key matching the instance's key pair. |
| Browser timeout or certificate error | DNS A record, conflicting AAAA record, ports 80/443, and Caddy logs. |
| Caddy default welcome page | Replace its default config with the supplied Caddyfile, change the domain and reload Caddy. |
| `502 Bad Gateway` | Museum service status and logs; the app must listen on 127.0.0.1:3000. |
| `Unrecognized host` / `HTTPS is required` | Domain mismatch or changed proxy headers. Keep the supplied Caddy forwarding configuration. |
| Supabase connection check returns 401/403 | Wrong key or key from another project. Use a secret server key matching that project URL. |
| Supabase connection check returns 404/other database error | Project active, complete schema SQL run, Data API enabled with public schema exposed. Keep the included SQL permissions; do not make the bucket public. |
| Cannot sign in | Complete setup SQL, correct username/password, correct domain, and working HTTPS. After too many failed attempts, wait 15 minutes. |
| `413` or file exceeds limit | Confirm the optimized size and both the project-wide and bucket limits in Supabase. Use the admin resumable uploader. |
| Changes appear lost after restart | Confirm the hosted app uses your museum Supabase project and uploads completed successfully. |

Useful logs, run on EC2:

```bash
sudo journalctl -u museum -n 80 --no-pager
sudo journalctl -u caddy -n 80 --no-pager
```

After changing the private settings with `configure.py`, run the connection check again and then:

```bash
sudo systemctl restart museum
```

Changing the admin password does not revoke already signed-in sessions. To revoke every session, run `delete from public.museum_sessions;` in the museum project's SQL Editor. This signs out all admins and keeps the art.

## Update the website later

Build a new AWS ZIP on your development computer, then upload it using SCP as in step 4. On EC2, extract it into a new directory and keep the previous release for rollback:

```bash
sudo mkdir -p /opt/museum/releases/release-2
sudo unzip ~/museum-of-love-aws.zip -d /opt/museum/releases/release-2
sudo chown -R root:root /opt/museum/releases/release-2
sudo chmod -R u=rwX,go=rX /opt/museum/releases/release-2
sudo ln -sfn /opt/museum/releases/release-2/museum-of-love /opt/museum/current
sudo systemctl restart museum
sudo systemctl status museum --no-pager
```

Use a fresh release number each time. These commands retain the private settings and Supabase content. Apply database changes only when a new release explicitly includes them. Verify the new checksum before extracting and check the live museum after updating.

To return to the first release:

```bash
sudo ln -sfn /opt/museum/releases/release-1 /opt/museum/current
sudo systemctl restart museum
```

Keep separate backups of your original artwork, Supabase database, Storage objects, and private server configuration. An EC2 disk snapshot does not include files stored in Supabase. Keep Ubuntu, Caddy and Node updated, and check AWS CPU credits, memory and transfer usage as visits grow.

## Edit and rebuild from the source

On your development computer, extract **museum-of-love-source.zip**, open the `museum-of-love` folder, and install Node.js 24 LTS and Python 3.

```bash
npm ci
npm run typecheck
npm run build
npm run test:production
```

Then package the release:

```bash
python3 scripts/package-aws.py
```

On Windows, use `python scripts/package-aws.py` if Python is named `python`. The ZIP, checksum and hosting guide are written into the source folder's `release` directory. Upload that ZIP using the steps above. Browser code and the production API are already bundled; no Windows native dependencies are included in the release.

For local preview, copy `.env.example` to `.env.local`, set the local values, and run `npm run dev`. The default `npm start` command is also a loopback-only preview. The AWS service uses **scripts/serve-production.mjs**, which reads its settings at runtime and requires HTTPS behind Caddy.

## Included files

| File | Purpose |
|---|---|
| `dist/client/` | Built 3D museum and browser assets |
| `dist/node/worker.mjs` | Built production API |
| `scripts/serve-production.mjs` | Production entry point |
| `scripts/production-server.mjs` | Streaming server and trusted proxy handling |
| `scripts/check-production.mjs` | Supabase deployment check |
| `deploy/aws/install-runtime.sh` | Node and Caddy installation for fresh Ubuntu |
| `deploy/aws/configure.py` | Private setup prompts and password hashing |
| `deploy/aws/museum.service` | Automatic startup and restart |
| `deploy/aws/Caddyfile` | Domain, HTTPS and reverse proxy settings |
| `supabase/schema.sql` | Museum database and private storage setup |

Prepared 5 October 2026. This guide uses your requested AWS host; the source's older Sites registration is not needed for this installation.
