#!/usr/bin/env python3
"""Interactive Linux setup; secrets never appear in commands or terminal output."""
import base64
import argparse
import getpass
import hashlib
import json
import os
from pathlib import Path
import re
import secrets
import tempfile
from urllib.parse import urlsplit


def collect_settings():
    domain = input('Museum domain (for example museum.yourdomain.com): ').strip().lower()
    if not re.fullmatch(r'(?=.{1,253}$)(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,63}', domain):
        raise ValueError('Enter a domain without https:// or a path.')
    address = input('Supabase project URL: ').strip().rstrip('/')
    parsed = urlsplit(address)
    if not re.fullmatch(r'https://[a-z0-9]{20}\.supabase\.co', address) or parsed.username:
        raise ValueError('Use the HTTPS project URL from Supabase, ending in .supabase.co.')
    key = getpass.getpass('Supabase secret server key (hidden): ').strip()
    legacy = False
    if re.fullmatch(r'[\w-]+\.[\w-]+\.[\w-]+', key, flags=re.ASCII):
        try:
            payload = key.split('.')[1]
            legacy = json.loads(base64.urlsafe_b64decode(payload + '=' * (-len(payload) % 4))).get('role') == 'service_role'
        except (ValueError, KeyError, TypeError, AttributeError):
            pass
    if not re.fullmatch(r'sb_secret_[A-Za-z0-9_-]{20,200}', key) and not legacy:
        raise ValueError('Use a secret server key, not a publishable or anon key.')
    limit = input('Stored-file limit in MB [50; enter 100 only if enabled in Supabase]: ').strip() or '50'
    if limit not in ('50', '100'):
        raise ValueError('Choose 50 or 100.')
    username = input('Admin username [sadun]: ').strip() or 'sadun'
    if not re.fullmatch(r'[A-Za-z0-9_-]{1,64}', username):
        raise ValueError('Use letters, numbers, dashes or underscores for the username.')
    password = getpass.getpass('Admin password (hidden; at least 8 characters): ')
    if not 8 <= len(password) <= 256:
        raise ValueError('Use an admin password between 8 and 256 characters.')
    if password != getpass.getpass('Repeat admin password: '):
        raise ValueError('The passwords do not match.')
    salt = secrets.token_bytes(16)
    iterations = 600000
    digest = hashlib.pbkdf2_hmac('sha256', password.encode('utf-8'), salt, iterations).hex()
    return {
        'PUBLIC_ORIGIN': 'https://' + domain,
        'PORT': '3000',
        'SUPABASE_URL': address,
        'SUPABASE_SECRET_KEY': key,
        'SUPABASE_MAX_FILE_BYTES': str(int(limit) * 1024 * 1024),
        'ADMIN_USERNAME': username,
        'ADMIN_PASSWORD_HASH': f'pbkdf2-sha256:{iterations}:{salt.hex()}:{digest}',
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--pm2-user', help='Linux account that runs PM2, such as ubuntu')
    parser.add_argument('--proxy', choices=['caddy', 'cloudflare'], default='caddy')
    args = parser.parse_args()
    if not hasattr(os, 'geteuid') or os.geteuid() != 0:
        raise ValueError('Run this helper on Ubuntu with sudo python3 deploy/aws/configure.py.')
    if not os.isatty(0):
        raise ValueError('Run this helper in an interactive SSH terminal.')
    group_id = 0
    if args.pm2_user:
        import pwd
        try:
            account = pwd.getpwnam(args.pm2_user)
        except KeyError:
            raise ValueError('The PM2 Linux user does not exist.') from None
        if account.pw_uid == 0:
            raise ValueError('Use a regular Linux account for PM2, not root.')
        group_id = account.pw_gid
    directory = Path('/etc/museum')
    target = directory / 'museum.env'
    if target.exists() and input('Replace the existing museum server settings? Type yes: ').strip() != 'yes':
        print('Existing settings kept.')
        return
    values = collect_settings()
    values['PROXY_MODE'] = args.proxy
    directory.mkdir(mode=0o700, parents=True, exist_ok=True)
    os.chown(directory, 0, group_id)
    os.chmod(directory, 0o750 if args.pm2_user else 0o700)
    descriptor, temporary = tempfile.mkstemp(prefix='.museum-', dir=directory)
    try:
        with os.fdopen(descriptor, 'w', encoding='utf-8', newline='\n') as stream:
            for name, value in values.items():
                stream.write(f'{name}={value}\n')
        os.chown(temporary, 0, group_id)
        os.chmod(temporary, 0o640 if args.pm2_user else 0o600)
        os.replace(temporary, target)
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)
    print('Saved private server settings to /etc/museum/museum.env.')
    print('The password is stored as a salted hash. Run the connection check next.')


if __name__ == '__main__':
    try:
        main()
    except (ValueError, OSError, KeyboardInterrupt, EOFError) as error:
        print(str(error) if isinstance(error, ValueError) else 'Setup stopped; server settings were not changed.')
        raise SystemExit(1)
