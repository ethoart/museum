#!/usr/bin/env bash
# For a fresh Ubuntu 24.04 x86_64 EC2 instance. Run with sudo bash.
set -euo pipefail
museum_mode=${1:-caddy}
if [[ "$museum_mode" != caddy && "$museum_mode" != tunnel ]]; then
  echo 'Choose caddy or tunnel.' >&2
  exit 1
fi
if [[ ${EUID} -ne 0 || $(uname -m) != x86_64 ]]; then
  echo 'Run with sudo on the x86_64 Ubuntu instance.' >&2
  exit 1
fi
. /etc/os-release
if [[ ${ID} != ubuntu || ${VERSION_ID} != 24.04 ]]; then
  echo 'These setup instructions target Ubuntu 24.04 LTS.' >&2
  exit 1
fi
apt-get update
apt-get install -y ca-certificates curl xz-utils unzip python3 git gnupg debian-keyring debian-archive-keyring apt-transport-https

# Download the latest patched Node 24 LTS binary from nodejs.org and verify it.
museum_tmp=$(mktemp -d)
cd "$museum_tmp"
curl --proto '=https' --tlsv1.2 -fsSL https://nodejs.org/dist/latest-v24.x/SHASUMS256.txt -o SHASUMS256.txt
museum_archive=$(awk '$2 ~ /^node-v24\.[0-9]+\.[0-9]+-linux-x64\.tar\.xz$/ {print $2}' SHASUMS256.txt)
if [[ ! "$museum_archive" =~ ^node-v24\.[0-9]+\.[0-9]+-linux-x64\.tar\.xz$ ]]; then
  echo 'Could not identify the official Node 24 binary.' >&2
  exit 1
fi
curl --proto '=https' --tlsv1.2 -fsSL "https://nodejs.org/dist/latest-v24.x/$museum_archive" -o "$museum_archive"
awk -v file="$museum_archive" '$2 == file' SHASUMS256.txt | sha256sum --check --strict
tar -xJf "$museum_archive" -C /opt --no-same-owner
museum_node="/opt/${museum_archive%.tar.xz}"
ln -sfn "$museum_node/bin/node" /usr/local/bin/node
ln -sfn "$museum_node/bin/npm" /usr/local/bin/npm
ln -sfn "$museum_node/bin/npx" /usr/local/bin/npx

if [[ "$museum_mode" == tunnel ]]; then
  curl --proto '=https' --tlsv1.2 -fsSL https://pkg.cloudflare.com/cloudflare-main.gpg -o /usr/share/keyrings/cloudflare-main.gpg
  printf '%s\n' 'deb [signed-by=/usr/share/keyrings/cloudflare-main.gpg] https://pkg.cloudflare.com/cloudflared any main' > /etc/apt/sources.list.d/cloudflared.list
  chmod 644 /usr/share/keyrings/cloudflare-main.gpg /etc/apt/sources.list.d/cloudflared.list
  apt-get update
  apt-get install -y cloudflared
  /usr/local/bin/npm install --global --prefix /usr/local pm2@latest
  /usr/local/bin/node --version
  /usr/bin/cloudflared --version
  echo 'Node, npm, PM2 and cloudflared installed. Continue with GITHUB-PM2-CLOUDFLARE.md.'
  exit 0
fi

# Caddy's official stable package repository for Ubuntu/Debian.
curl --proto '=https' --tlsv1.2 -fsSL https://dl.cloudsmith.io/public/caddy/stable/gpg.key -o caddy.key
gpg --batch --yes --dearmor --output /usr/share/keyrings/caddy-stable-archive-keyring.gpg caddy.key
curl --proto '=https' --tlsv1.2 -fsSL https://dl.cloudsmith.io/public/caddy/stable/debian.deb.txt -o /etc/apt/sources.list.d/caddy-stable.list
chmod 644 /usr/share/keyrings/caddy-stable-archive-keyring.gpg /etc/apt/sources.list.d/caddy-stable.list
apt-get update
apt-get install -y caddy
/usr/local/bin/node --version
caddy version
echo 'Node and Caddy installed. Continue with the AWS guide.'
