#!/usr/bin/env python3
"""Save a tunnel token without putting it in shell history or process arguments."""
import getpass
import os
from pathlib import Path
import re
import tempfile

def main():
    if not hasattr(os, 'geteuid') or os.geteuid() != 0 or not os.isatty(0):
        raise ValueError('Run this helper with sudo python3 in the SSH terminal.')
    folder = Path('/etc/museum')
    folder.mkdir(mode=0o700, parents=True, exist_ok=True)
    target = folder / 'cloudflare.token'
    if target.exists() and input('Replace the existing tunnel token? Type yes: ').strip() != 'yes':
        return
    token = getpass.getpass('Cloudflare tunnel token (hidden): ').strip()
    if not re.fullmatch(r'[A-Za-z0-9_+/=-]{40,8192}', token):
        raise ValueError('Paste only the token, not the full Cloudflare installation command.')
    fd, temporary = tempfile.mkstemp(prefix='.tunnel-', dir=folder)
    try:
        with os.fdopen(fd, 'w', encoding='ascii') as stream:
            stream.write(token + '\n')
        os.chmod(temporary, 0o600)
        os.replace(temporary, target)
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)
    print('Saved the private token. Start or restart cloudflared-museum next.')

if __name__ == '__main__':
    try:
        main()
    except (ValueError, OSError, EOFError, KeyboardInterrupt) as error:
        print(str(error) if isinstance(error, ValueError) else 'Could not save the token.')
        raise SystemExit(1)
