// Apply the browser preference before the stylesheet paints the page.
try {
  const mode=localStorage.getItem('museum-colour-mode');
  const dark=mode==='dark'||(!['light','dark'].includes(mode)&&matchMedia('(prefers-color-scheme: dark)').matches);
  document.documentElement.classList.toggle('dark',dark);
  document.documentElement.style.colorScheme=dark?'dark':'light';
  const palette=localStorage.getItem('museum-palette-preview');
  if(['candlelight','olive','moonlight','rose'].includes(palette))document.documentElement.dataset.museumPalette=palette;
} catch {
  document.documentElement.classList.toggle('dark',matchMedia('(prefers-color-scheme: dark)').matches);
}
