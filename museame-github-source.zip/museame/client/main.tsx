import { createRoot } from 'react-dom/client';
import Museum from '../components/museum';
import { lazy, Suspense } from 'react';
import { ThemeProvider } from 'next-themes';
const Admin=lazy(()=>import('../components/admin'));
const admin=/^\/admin\/?$/.test(window.location.pathname);
createRoot(document.getElementById('root')!).render(<ThemeProvider attribute="class" defaultTheme="system" enableSystem storageKey="museum-colour-mode" disableTransitionOnChange>{admin?<Suspense fallback={<p>Opening the curator’s room…</p>}><Admin/></Suspense>:<Museum />}</ThemeProvider>);
