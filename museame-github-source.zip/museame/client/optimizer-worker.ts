import { optimizeUpload } from '../lib/optimize-upload';
self.onmessage=async(event:MessageEvent<{file:File;kind:'image'|'model'}>)=>{
  try{const file=await optimizeUpload(event.data.file,event.data.kind,message=>self.postMessage({message}));self.postMessage({file});}
  catch(error){self.postMessage({error:error instanceof Error?error.message:'This file could not be optimized.'});}
};
