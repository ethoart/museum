'use client';
import {useState,type FormEvent} from 'react';
import {Cloud,ArrowUpRight,Download,LoaderCircle,LockKeyhole} from 'lucide-react';
import {Dialog,DialogContent,DialogTitle,DialogDescription} from '@/components/ui/dialog';

export function ConnectSupabase({onConnected}:{onConnected:()=>void}){
  const [open,setOpen]=useState(false),[url,setUrl]=useState(''),[key,setKey]=useState(''),[limit,setLimit]=useState(50),[busy,setBusy]=useState(false),[error,setError]=useState('');
  const local=['localhost','127.0.0.1'].includes(window.location.hostname),ref=url.trim().match(/^https:\/\/([a-z0-9]{20})\.supabase\.co\/?$/)?.[1];
  const dashboard=ref?'https://supabase.com/dashboard/project/'+ref:'https://supabase.com/dashboard';
  function changeOpen(value:boolean){if(busy)return;setOpen(value);setKey('');setError('');}
  async function connect(event:FormEvent){
    event.preventDefault();setBusy(true);setError('');
    try{const response=await fetch('/api/setup/supabase',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({url,key,storedFileLimit:limit})});const data=await response.json() as {error?:string;connected?:boolean};if(!response.ok||!data.connected)throw new Error(data.error||'The connection could not be saved.');setKey('');setOpen(false);onConnected();}
    catch(error){setError((error as Error).message);}finally{setBusy(false);}
  }
  return <><button type="button" className="primary-button" onClick={()=>changeOpen(true)}><Cloud size={16}/> Connect Supabase</button><Dialog open={open} onOpenChange={changeOpen}><DialogContent className="connect-dialog"><DialogTitle>A home for your memories.</DialogTitle><DialogDescription>Connect this museum to your Supabase project. Connecting your account in chat gives the assistant access; the website needs its own storage connection.</DialogDescription>
    {local?<form className="connect-form exhibit-form" onSubmit={connect}>
      <section><h3><span>1</span> Choose your project</h3><p>Open Supabase and create or choose the project for Museum of Love.</p><a href={dashboard} target="_blank" rel="noreferrer" className="source-link">Open Supabase <ArrowUpRight size={13}/></a><label>Project URL<input type="url" required value={url} onChange={event=>setUrl(event.target.value)} placeholder="https://your-project.supabase.co" autoComplete="off" spellCheck={false} disabled={busy}/></label></section>
      <section><h3><span>2</span> Prepare the museum</h3><p>Download the setup file. Paste its contents into your project’s SQL Editor and select Run. It creates the private storage and museum tables.</p><div className="setup-links"><a href="/api/setup/supabase" download="museum-of-love-setup.sql" className="secondary-button"><Download size={15}/> Download setup SQL</a><a href={ref?dashboard+'/sql':dashboard} target="_blank" rel="noreferrer" className="source-link">Open SQL Editor <ArrowUpRight size={13}/></a></div></section>
      <section><h3><span>3</span> Connect securely</h3><p>In Supabase, open Settings → API Keys and copy a secret server key.</p><a href={ref?dashboard+'/settings/api-keys':dashboard} target="_blank" rel="noreferrer" className="source-link">Find your API keys <ArrowUpRight size={13}/></a><label>Secret server key<input type="password" required autoComplete="off" spellCheck={false} value={key} onChange={event=>setKey(event.target.value)} placeholder="sb_secret_…" disabled={busy}/></label><label>Stored-file limit<select value={limit} onChange={event=>setLimit(Number(event.target.value))} disabled={busy}><option value={50}>50 MB — Supabase Free</option><option value={100}>100 MB — paid project with limit increased</option></select></label><p className="setup-private"><LockKeyhole size={14}/> Saved privately on this computer. It is never included in the visitor website.</p><p>Original uploads can be up to 100 MB. After compression, they must fit this stored-file limit.</p></section>
      {error&&<p role="alert" className="form-error">{error}</p>}<div className="form-footer"><button type="button" className="secondary-button" disabled={busy} onClick={()=>changeOpen(false)}>Cancel</button><button type="submit" className="primary-button" disabled={busy}>{busy?<><LoaderCircle size={16} className="spin"/> Checking connection…</>:<><Cloud size={16}/> Connect museum</>}</button></div>
    </form>:<div className="hosted-setup"><p>Connect the published museum through its hosting settings. Add the Supabase project URL and secret server key as private server settings, then publish again.</p><a className="secondary-button" href="https://supabase.com/dashboard" target="_blank" rel="noreferrer">Open Supabase <ArrowUpRight size={15}/></a></div>}
  </DialogContent></Dialog></>;
}
