'use client';
import { useEffect, useRef, useState } from 'react';
import { Landmark, Plus, Box, Image as ImageIcon, Grid2X2, Footprints, Maximize, Minimize, HelpCircle, MoveUp, MoveDown, MoveLeft, MoveRight, Pencil, Trash2, X, Upload, Check, LoaderCircle, MapPin, Eye, MousePointer2 } from 'lucide-react';
import { Dialog, DialogContent, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { Sheet, SheetContent, SheetTitle, SheetDescription } from '@/components/ui/sheet';
import { Toaster } from '@/components/ui/sonner';
import { toast } from 'sonner';
import { settingsDefaults, type MuseumSettings } from '@/lib/settings';
import { Heart, Mail } from 'lucide-react';
import { ROOMS, SLOTS, type Exhibit } from '@/lib/exhibition';
import { ColourMode,useMuseumAppearance } from '@/components/appearance';
import type { MuseumWorld } from '@/lib/museum-world';

export default function Museum(){
  const canvasHost=useRef<HTMLDivElement>(null),world=useRef<MuseumWorld|null>(null),itemsRef=useRef<Exhibit[]>([]);
  const [items,setItems]=useState<Exhibit[]>([]),[loaded,setLoaded]=useState(false),[sceneReady,setSceneReady]=useState(false),[artReady,setArtReady]=useState(false),[sceneError,setSceneError]=useState(''),[loadError,setLoadError]=useState('');
  const [position,setPosition]=useState({x:.7,z:9.5,yaw:0}),[locked,setLocked]=useState(false),[collection,setCollection]=useState(false),[help,setHelp]=useState(false),[full,setFull]=useState(false);
  const [selected,setSelected]=useState<Exhibit|null>(null),[letter,setLetter]=useState(false),[settings,setSettings]=useState<MuseumSettings>(settingsDefaults);
  const colourMode=useMuseumAppearance(settings.palette);
  const room=position.x < -7?'West gallery':position.x>7?'East gallery':'Main hall';
  const updateItems=(next:Exhibit[])=>{itemsRef.current=next;setItems(next);};
  async function load(){setLoadError('');try{const res=await fetch('/api/exhibits',{cache:'no-store'});const data=await res.json() as {error?:string;exhibits:Exhibit[]};if(!res.ok)throw new Error(data.error||'Could not load the collection.');updateItems(data.exhibits);setLoaded(true);}catch(e){setLoadError((e as Error).message);}}
  useEffect(()=>{void load();void fetch('/api/settings').then(async r=>{if(r.ok)setSettings((await r.json() as {settings:MuseumSettings}).settings);}).catch(()=>{});let cancelled=false;
    import('@/lib/museum-world').then(({MuseumWorld})=>{
      if(cancelled||!canvasHost.current)return;
      try{world.current=new MuseumWorld(canvasHost.current,{onPosition:(x,z,yaw)=>setPosition({x,z,yaw}),onSelect:id=>{const item=itemsRef.current.find(e=>e.id===id);if(item)setSelected(item);},onLock:setLocked,onError:message=>toast.error(message)});setSceneReady(true);}catch{setSceneError('This browser could not start the 3D view. Enable hardware acceleration or use a browser with WebGL 2. You can still view the collection.');}
    });
    const onFull=()=>setFull(!!document.fullscreenElement);document.addEventListener('fullscreenchange',onFull);
    return()=>{cancelled=true;world.current?.dispose();world.current=null;document.removeEventListener('fullscreenchange',onFull);};
  },[]);
  useEffect(()=>{if(!sceneReady||!loaded)return;let current=true;setArtReady(false);void world.current?.setExhibits(items).then(()=>{if(current)setArtReady(true);});return()=>{current=false;};},[items,sceneReady,loaded]);
  useEffect(()=>{world.current?.setBlocked(collection||help||letter||!!selected);},[collection,help,letter,selected,sceneReady]);
  function visit(name:string){world.current?.go(name);setCollection(false);setSelected(null);}
  function visitItem(item:Exhibit){world.current?.focus(item);setCollection(false);setSelected(null);}
  function movement(code:string,on:boolean){if(on)world.current?.keys.add(code);else world.current?.keys.delete(code);}
  async function fullscreen(){try{if(document.fullscreenElement)await document.exitFullscreen();else await document.documentElement.requestFullscreen();}catch{toast.info('Full screen is unavailable in this browser.');}}
  useEffect(()=>{
    const context=(document as unknown as {modelContext?:{registerTool:(tool:unknown,options:unknown)=>unknown}}).modelContext;if(!context?.registerTool)return;const lifecycle=new AbortController();
    const register=(tool:unknown)=>Promise.resolve(context.registerTool(tool,{signal:lifecycle.signal})).catch(()=>{});
    void register({name:'list_exhibits',description:'Read the current museum collection.',inputSchema:{type:'object',properties:{},additionalProperties:false},annotations:{readOnlyHint:true,untrustedContentHint:true},execute:()=>({exhibits:itemsRef.current.map(({id,title,artist,kind,slot})=>({id,title,artist,kind,slot}))})});
    void register({name:'visit_gallery',description:'Move the visitor to a museum gallery.',inputSchema:{type:'object',properties:{room:{type:'string',enum:[...ROOMS]}},required:['room'],additionalProperties:false},annotations:{readOnlyHint:false},execute:(input:{room:string})=>{if(!ROOMS.includes(input.room as typeof ROOMS[number]))throw new Error('Unknown gallery.');visit(input.room);return{room:input.room};}});
    return()=>lifecycle.abort();
  },[]);
  return <main className="museum-app">
    <div className="museum-canvas" ref={canvasHost}/>
    <div className="top-shade"/>
    <header className="museum-header">
      <a href="/" className="brand love-brand" aria-label="Museum of Love home"><Heart size={29} strokeWidth={1.2}/><span>Museum <em>of Love</em></span><small>FOR {settings.recipient.toUpperCase()||"YOU"}</small></a>
      <nav className="view-switch" aria-label="Museum views"><button className="active" onClick={()=>{setCollection(false);setSelected(null);}}><Footprints size={16}/> Explore</button><button onClick={()=>setCollection(true)}><Grid2X2 size={16}/> Collection <span className="count">{items.length}</span></button></nav>
      <div className="header-actions"><ColourMode/><button className="icon-button help-button" onClick={()=>setHelp(true)} aria-label="How to explore"><HelpCircle size={20}/></button><button className="letter-button" onClick={()=>setLetter(true)}><Mail size={17}/><span>A letter for you</span></button></div>
    </header>
    <div className="exhibition-marker"><span className="marker-line"/> A GARDEN OF ART & LITTLE FOREVERS <span className="marker-number">/ ♡</span></div>
    <p className="birthday-dedication">Happy birthday, {settings.recipient||"my love"} ♡</p>
    {(!sceneReady||!loaded)&&!sceneError&&!loadError&&<div className="loading-view" role="status"><Landmark size={36} strokeWidth={1}/><h1>Opening the gallery</h1><p>Preparing your collection…</p><LoaderCircle className="spin" size={20}/></div>}
    {sceneReady&&loaded&&!artReady&&<div className="art-loading-note" role="status"><LoaderCircle size={14} className="spin"/> Hanging the artworks… You can explore.</div>}
    {(sceneError||loadError)&&<div className="scene-notice" role="alert"><h2>{loadError?'Collection unavailable':'3D view unavailable'}</h2><p>{loadError||sceneError}</p><button className="primary-button" onClick={()=>loadError?load():setCollection(true)}>{loadError?'Try again':'Open collection'}</button></div>}
    {locked&&<><span className="crosshair"/><div className="walk-notice">W A S D to walk · E to inspect · Esc to release mouse</div></>}
    <aside className="gallery-info">
      <p className="eyebrow">{room==='Main hall'?'THE GARDEN OF US':room==='West gallery'?'THE DRAWING GARDEN':'MEMORIES IN BLOOM'}</p>
      <h1>{room}</h1><p className="gallery-caption">Under the same sky. In our own little world.</p>
      <div className="room-nav" aria-label="Visit a gallery">{ROOMS.map((r,i)=><button key={r} className={room===r?'current':''} onClick={()=>visit(r)} aria-label={'Visit '+r}><span>0{i+1}</span> {r==='Main hall'?'Main hall':r.replace(' gallery','')}</button>)}</div>
    </aside>
    <div className="movement-bar"><span className="drag-hint"><MousePointer2 size={16}/> Drag to look <span className="divider"/> <kbd>W</kbd><kbd>A</kbd><kbd>S</kbd><kbd>D</kbd> to walk</span><button className="walk-button" onClick={()=>locked?document.exitPointerLock():world.current?.lock()} disabled={!sceneReady}><Footprints size={18}/>{locked?'Stop walking':'Walk inside'}</button></div>
    <div className="touch-controls" aria-label="Movement controls">{[['KeyW','Move forward',MoveUp],['KeyA','Move left',MoveLeft],['KeyS','Move backward',MoveDown],['KeyD','Move right',MoveRight]].map(([code,label,Icon])=>{const Symbol=Icon as typeof MoveUp;return <button key={String(code)} className={code==='KeyW'?'forward':''} aria-label={String(label)} onPointerDown={e=>{e.preventDefault();e.currentTarget.setPointerCapture(e.pointerId);movement(String(code),true);}} onPointerUp={()=>movement(String(code),false)} onPointerCancel={()=>movement(String(code),false)} onLostPointerCapture={()=>movement(String(code),false)}><Symbol size={21}/></button>;})}</div>
    <aside className="map-card"><div className="map-header"><span><MapPin size={13}/> YOU ARE HERE</span><button aria-label={full?'Exit full screen':'Enter full screen'} onClick={fullscreen}>{full?<Minimize size={16}/>:<Maximize size={16}/>}</button></div>
      <svg className="floor-map" viewBox="0 0 200 138" role="img" aria-label={'Floor plan. You are in the '+room}>
        <rect className="map-floor" x="10" y="12" width="180" height="114" fill="#eceadf" stroke="#afb7a9" strokeWidth="1.5"/>
        <path className="map-walls" d="M65 12v19m0 29v19m0 28v19M135 12v19m0 29v19m0 28v19" stroke="#afb7a9" strokeWidth="2"/>
        <path className="map-garden" d="M85 31h30v55H85z" fill="none" stroke="#cad1c5" strokeDasharray="3 3"/>
        {items.filter(i=>i.kind==='model').map(i=>{const s=SLOTS.find(s=>s.id===i.slot)!;return <rect key={i.id} x={100+s.x*5-3} y={69+s.z*4.75-3} width="6" height="6" fill="#b5aa85"/>;})}
        <text x="36" y="72">01</text><text x="158" y="72">02</text>
        <g transform={`translate(${100+position.x*5} ${69+position.z*4.75}) rotate(${-position.yaw*180/Math.PI})`}><path d="M0-17-11 4h22Z" fill="#789697" opacity=".13"/><circle className="map-visitor" r="4" fill="#456c73" stroke="#fff" strokeWidth="1.5"/></g>
      </svg><p>{room} <span>{items.length} works on view</span></p>
    </aside>
    <Sheet open={collection} onOpenChange={setCollection}><SheetContent className="collection-panel"><div className="panel-heading"><p className="eyebrow">MADE OF LITTLE MOMENTS</p><SheetTitle>The collection</SheetTitle><SheetDescription>{items.length} exhibits across three galleries. Select a work to take a closer look.</SheetDescription></div>
      <div className="collection-list">{items.map(item=><article className="collection-item" key={item.id}><button className="item-main" onClick={()=>{setCollection(false);setSelected(item);}}>{item.kind==='image'?<img src={item.url} alt="" loading="lazy" decoding="async"/>:<div className="model-thumb"><Box size={28} strokeWidth={1}/></div>}<span><strong>{item.title}</strong><small>{item.artist}</small><em>{SLOTS.find(s=>s.id===item.slot)?.room}</em></span></button></article>)}{loaded&&!items.length&&<div className="empty-state"><ImageIcon size={32}/><h3>A blank canvas</h3><p>Our drawings and memories will find their home here.</p></div>}</div><p className="panel-footnote"><Heart size={14}/> A collection to wander through, together.</p>
    </SheetContent></Sheet>
    <Dialog open={!!selected} onOpenChange={open=>!open&&setSelected(null)}><DialogContent className="art-dialog">{selected&&<>
      {selected.kind==='image'?<div className="art-preview"><img src={selected.url} alt={selected.title}/></div>:<div className="model-preview"><Box size={56} strokeWidth={.8}/><span>3D SCULPTURE</span></div>}
      <div className="art-details"><p className="eyebrow">{SLOTS.find(s=>s.id===selected.slot)?.room}</p><DialogTitle>{selected.title}</DialogTitle><DialogDescription>{selected.artist}{selected.year?' · '+selected.year:''}</DialogDescription>{selected.description&&<p>{selected.description}</p>}{selected.source&&<a className="source-link" href={selected.source} target="_blank" rel="noreferrer">The Metropolitan Museum of Art · Public Domain</a>}<div className="detail-actions"><button className="primary-button" onClick={()=>visitItem(selected)}><Eye size={17}/> View in gallery</button></div></div>
    </>}</DialogContent></Dialog>
    <Dialog open={letter} onOpenChange={setLetter}><DialogContent className="love-letter"><Heart size={31} strokeWidth={1}/><p className="eyebrow">FOR {settings.recipient.toUpperCase()||'YOU'}, WITH LOVE</p><DialogTitle>{settings.greeting}</DialogTitle><DialogDescription>A birthday letter from Sadun</DialogDescription><div className="letter-body">{settings.message.split('\n').filter(Boolean).map((paragraph,i)=><p key={i}>{paragraph}</p>)}</div><p className="letter-signature">{settings.signature}</p><button className="primary-button" onClick={()=>setLetter(false)}>Let’s wander together <Heart size={15}/></button></DialogContent></Dialog>
    <Dialog open={help} onOpenChange={setHelp}><DialogContent className="help-dialog"><p className="eyebrow">MAKE YOURSELF AT HOME</p><DialogTitle>A museum at your own pace.</DialogTitle><DialogDescription>Every gallery is open. Wander freely, or use the gallery buttons to move between rooms.</DialogDescription><dl><div><dt>W A S D</dt><dd>Walk through the museum</dd></div><div><dt>Drag / mouse</dt><dd>Look in any direction</dd></div><div><dt>Arrow keys</dt><dd>Move forward, back, and turn</dd></div><div><dt>Click / E</dt><dd>Read about an artwork</dd></div><div><dt>Shift</dt><dd>Walk a little faster</dd></div><div><dt>Esc</dt><dd>Release the mouse in walk mode</dd></div></dl><p>On a phone, drag the scene to look around and use the movement buttons to walk.</p><button className="primary-button" onClick={()=>setHelp(false)}>Explore the museum</button></DialogContent></Dialog>
    <Toaster position="top-center" theme={colourMode} richColors/>
  </main>;
}
