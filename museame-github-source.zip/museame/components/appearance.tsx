'use client';
import {useEffect,useState} from 'react';
import {useTheme} from 'next-themes';
import {Check,Monitor,Moon,Sun,Palette as PaletteIcon,LoaderCircle} from 'lucide-react';
import {PALETTES,isPalette,type Palette} from '@/lib/settings';

const previewKey='museum-palette-preview',eventName='museum-palette-change';
export function readPalettePreview():Palette|null{
  try{const value=localStorage.getItem(previewKey);return isPalette(value)?value:null;}catch{return null;}
}
export function previewPalette(palette:Palette|null){
  try{if(palette)localStorage.setItem(previewKey,palette);else localStorage.removeItem(previewKey);}catch{}
  window.dispatchEvent(new CustomEvent(eventName,{detail:palette}));
}
export function useMuseumAppearance(saved:Palette){
  const {resolvedTheme}=useTheme();
  useEffect(()=>{
    const apply=(event?:Event)=>{
      const chosen=event instanceof CustomEvent&&isPalette(event.detail)?event.detail:readPalettePreview()??saved;
      document.documentElement.dataset.museumPalette=chosen;
    };
    apply();window.addEventListener('storage',apply);window.addEventListener(eventName,apply);
    return()=>{window.removeEventListener('storage',apply);window.removeEventListener(eventName,apply);};
  },[saved]);
  useEffect(()=>{
    let meta=document.querySelector<HTMLMetaElement>('meta[name="theme-color"]');
    if(!meta){meta=document.createElement('meta');meta.name='theme-color';document.head.appendChild(meta);}
    meta.content=resolvedTheme==='dark'?'#17232c':'#f6f2e9';
  },[resolvedTheme]);
  return resolvedTheme==='dark'?'dark':'light';
}
export function ColourMode(){
  const {theme='system',setTheme}=useTheme(),Icon=theme==='dark'?Moon:theme==='light'?Sun:Monitor;
  return <label className="colour-mode" title="Light, dark, or follow your browser"><Icon size={17}/><select aria-label="Colour mode" value={theme} onChange={event=>setTheme(event.target.value)}><option value="system">System</option><option value="light">Light</option><option value="dark">Dark</option></select></label>;
}
export function AppearanceSettings({saved,storageReady,busy,onSave}:{saved:Palette;storageReady:boolean;busy:boolean;onSave:(palette:Palette)=>Promise<void>}){
  const [selected,setSelected]=useState<Palette>(()=>readPalettePreview()??saved);
  const choose=(palette:Palette)=>{setSelected(palette);previewPalette(palette);};
  return <section className="appearance-settings"><div className="appearance-intro"><p className="eyebrow">COLOURS FROM OUR LITTLE WORLD</p><h2>Make it feel like home.</h2><p>Choose a palette inspired by the stone, trees, candles, and night sky. Each one includes a light and a dark version.</p></div>
    <fieldset className="palette-grid"><legend className="sr-only">Museum colour theme</legend>{PALETTES.map(palette=><label className={'palette-card '+(selected===palette.id?'selected':'')} key={palette.id}><input type="radio" name="museum-palette" value={palette.id} checked={selected===palette.id} onChange={()=>choose(palette.id)} disabled={busy}/><span className="palette-swatches" aria-hidden="true">{palette.colors.map(colour=><i key={colour} style={{background:colour}}/>)}</span><span className="palette-title">{palette.name}{selected===palette.id&&<Check size={17}/>}</span><span>{palette.description}</span></label>)}</fieldset>
    <div className="appearance-example"><span className="eyebrow">A LITTLE PREVIEW</span><h3>Under the same sky.</h3><p>Our drawings, our memories, our love.</p><span className="example-button"><PaletteIcon size={16}/> Your museum, your colours</span></div>
    <div className="appearance-actions"><button className="primary-button" disabled={busy||!storageReady} onClick={()=>void onSave(selected)}>{busy?<LoaderCircle size={16} className="spin"/>:<Check size={16}/>} Save for all visitors</button><button className="secondary-button" disabled={busy} onClick={()=>{setSelected(saved);previewPalette(null);}}>Reset preview</button></div>
    <p className="appearance-note" role="status">{storageReady?'Selections preview immediately in this browser. Save to apply the palette for everyone.':'Selections are remembered in this browser. Saving for all visitors becomes available when the museum’s Supabase project is ready.'}</p>
    <div className="appearance-mode"><div><h3>Light or dark</h3><p>System follows your browser’s preference. Each visitor can choose their own mode.</p></div><ColourMode/></div>
  </section>;
}
