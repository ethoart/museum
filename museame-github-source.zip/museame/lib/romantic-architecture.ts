import * as T from 'three';
import { mergeGeometries } from 'three/examples/jsm/utils/BufferGeometryUtils.js';
import type { MuseumWorld } from './museum-world';
import { gardenTextures } from './garden-textures';
import { SLOTS } from './exhibition';
import { buildMuseumScenery } from './museum-scenery';

// All architecture and garden objects are original, generated geometry.
export function buildRomanticMuseum(world:MuseumWorld,loadSky=true){
  const {scene}=world;
  const stone=world.material('#e4d8be',.94),chalk=world.material('#f0e7d0',.92),edge=world.material('#cabb9d',.94);
  const rose=world.material('#c88f83',1),sage=world.material('#8d9d81',1),wood=world.material('#92795b',.95),gold=world.material('#bb9757',.54,.2);
  let seed=12421;const rand=()=>{seed=(seed*16807)%2147483647;return(seed-1)/2147483646;};
  const textures=gardenTextures(rand);
  for(const material of[stone,chalk,edge]){material.map=textures.stone;material.bumpMap=textures.stone;material.bumpScale=.025;}
  const linen=new T.MeshStandardMaterial({map:textures.linen,bumpMap:textures.linen,bumpScale:.018,roughness:1});
  const box=(w:number,h:number,d:number,x:number,y:number,z:number,m:T.Material,parent:T.Object3D=scene)=>world.box(w,h,d,x,y,z,m,parent);
  const solid=(w:number,h:number,d:number,x:number,y:number,z:number,m=stone)=>{box(w,h,d,x,y,z,m);if(y-h/2<.2)world.obstacles.push({x,z,w,d});};
  function mesh(geometry:T.BufferGeometry,material:T.Material,x:number,y:number,z:number,parent:T.Object3D=scene){const result=new T.Mesh(geometry,material);result.position.set(x,y,z);result.castShadow=true;result.receiveShadow=true;parent.add(result);return result;}
  function cylinder(top:number,bottom:number,h:number,x:number,y:number,z:number,m:T.Material,parent:T.Object3D=scene){return mesh(new T.CylinderGeometry(top,bottom,h,24),m,x,y,z,parent);}
  function curve(points:T.Vector3[],radius:number,m:T.Material,parent:T.Object3D=scene){return mesh(new T.TubeGeometry(new T.CatmullRomCurve3(points),24,radius,7,false),m,0,0,0,parent);}

  const scenery=buildMuseumScenery(world,textures,rand,loadSky);

  // Travertine paving: large, quiet tiles and an inlaid sun around the sculpture.
  box(36.8,.25,24.8,0,-.125,0,new T.MeshStandardMaterial({map:textures.floor,bumpMap:textures.floor,bumpScale:.045,roughness:.76}));
  // Narrow mosaic borders and gold inlay leave the walking routes level.
  const mosaic=world.material('#657d7b',.78);
  for(const x of[-17.35,-7.7,-6.3,6.3,7.7,17.35]){
    box(.12,.008,22.5,x,.009,0,mosaic);box(.025,.01,22.5,x+.12,.011,0,gold);
    for(let z=-10.8;z<11;z+=.48){const tile=box(.075,.014,.075,x,.014,z,chalk);tile.rotation.y=Math.PI/4;tile.castShadow=false;}
  }
  for(const z of[-11.35,11.35]){box(34.6,.008,.12,0,.009,z,mosaic);box(34.6,.009,.025,0,.011,z+.12,gold);}
  for(const r of[2.75,3.0]){const ring=mesh(new T.RingGeometry(r,r+.035,96),gold,0,.01,-2);ring.rotation.x=-Math.PI/2;ring.castShadow=false;}
  for(let i=0;i<24;i++){const a=i/24*Math.PI*2;const tile=box(.035,.006,.13,Math.sin(a)*2.88,.015,-2+Math.cos(a)*2.88,gold);tile.rotation.y=a;tile.castShadow=false;}

  // Roman arches are actual openings, including the spandrels above the curve.
  function arch(x:number,z:number,width:number,spring:number,height:number,yaw:number,depth=.44){
    const r=width/2,group=new T.Group();group.position.set(x,0,z);group.rotation.y=yaw;scene.add(group);
    const fill=new T.Shape();fill.moveTo(-r,height);fill.lineTo(r,height);fill.lineTo(r,spring);fill.absarc(0,spring,r,0,Math.PI,false);fill.lineTo(-r,height);
    const cap=mesh(new T.ExtrudeGeometry(fill,{depth,bevelEnabled:false,curveSegments:32}),stone,0,0,-depth/2,group);
    cap.castShadow=true;
    const rim=new T.Shape();rim.absarc(0,spring,r+.25,0,Math.PI,false);rim.lineTo(-r,spring);rim.absarc(0,spring,r,Math.PI,0,true);rim.closePath();
    mesh(new T.ExtrudeGeometry(rim,{depth:depth+.13,bevelEnabled:true,bevelThickness:.018,bevelSize:.025,bevelSegments:1,curveSegments:32}),chalk,0,0,-depth/2-.065,group);
    for(let i=1;i<12;i++){const a=i/12*Math.PI;const seam=box(.014,.24,depth+.17,Math.cos(a)*(r+.125),spring+Math.sin(a)*(r+.125),0,edge,group);seam.rotation.z=a-Math.PI/2;}
    box(width+.65,.16,depth+.22,0,height-.1,0,chalk,group);
  }
  function column(x:number,z:number,height=3.18,r=.34){
    cylinder(r+.16,r+.19,.18,x,.09,z,chalk);cylinder(r+.09,r+.15,.16,x,.25,z,edge);
    cylinder(r*.85,r,height-.72,x,(height-.72)/2+.34,z,chalk);
    cylinder(r+.07,r*.9,.12,x,height-.32,z,edge);cylinder(r+.15,r+.07,.12,x,height-.2,z,chalk);
    box(r*3,.15,r*3,x,height-.065,z,chalk);
    for(let i=0;i<12;i++){const a=i/12*Math.PI*2;cylinder(.018,.021,height-1,x+Math.sin(a)*r*.92,(height-1)/2+.44,z+Math.cos(a)*r*.92,stone);}
    world.obstacles.push({x,z,w:(r+.19)*2,d:(r+.19)*2});
  }
  // Internal arcades keep the original four circulation routes and every exhibit slot.
  for(const x of[-7,7]){
    for(const [z,d] of[[-10,4],[0,4],[10,4]])solid(.44,7,d,x,3.5,z);
    for(const z of[-5,5])arch(x,z,6,3.2,7,Math.PI/2);
    for(const z of[-8,-2,2,8])column(x,z,3.22,.32);
    box(.72,.22,24,x,6.96,0,chalk);
  }
  // Taller side walls give artworks a full stone backdrop below the high windows.
  const sideWall=5.6,sideRoof=9.5;
  for(const z of[-12,12]){
    solid(7,7,.44,0,3.5,z);
    for(const x of[-5.25,5.25]){arch(x,z,3.5,2.85,7,0);column(x-1.75,z,2.9,.25);column(x+1.75,z,2.9,.25);}
    for(const x of[-12.5,12.5])solid(11,sideWall,.44,x,sideWall/2,z);
    for(const x of[-12.5,12.5]){
      for(const side of[-1,1])arch(x+side*2.65,z,4.6,sideWall,sideRoof,0);
      // Supports above the picture rail preserve uninterrupted hanging space below.
      for(const offset of[-5.15,0,5.15]){box(.48,.32,.62,x+offset,sideWall+.12,z,chalk);box(.64,.12,.76,x+offset,sideWall+.34,z,edge);}
    }
  }
  for(const x of[-18,18]){
    solid(.44,sideWall,24,x,sideWall/2,0);
    for(const z of[-8,0,8])arch(x,z,7.3,sideWall,sideRoof,Math.PI/2);
    for(const z of[-11.85,-3.85,4.15,11.85]){box(.62,.32,.48,x,sideWall+.12,z,chalk);box(.76,.12,.64,x,sideWall+.34,z,edge);}
  }
  // Layered skirting, picture rails, and tiny dentils finish the walls without using art space.
  for(const x of[-18,18]){
    for(const [h,y,d] of[[.24,.12,.62],[.08,.3,.68],[.1,sideWall-.18,.63]])box(d,h,24,x,y,0,chalk);
    for(let z=-11.5;z<12;z+=.55)box(.58,.16,.12,x,sideWall-.29,z,edge);
  }
  for(const z of[-12,12])for(const x of[-12.5,12.5]){
    for(const [h,y,d] of[[.24,.12,.62],[.08,.3,.68],[.1,sideWall-.18,.63]])box(11,h,d,x,y,z,chalk);
    for(let offset=-5;offset<=5;offset+=.55)box(.12,.16,.58,x+offset,sideWall-.29,z,edge);
  }
  for(const x of[-7,7])for(const z of[-10,0,10]){box(.63,.23,3.75,x,.115,z,chalk);box(.7,.07,3.75,x,.28,z,edge);}
  // Cornices, warm side-gallery roofs, and open sky over the central atrium.
  for(const x of[-12.5,12.5]){box(11,.23,24.5,x,sideRoof+.05,0,stone);for(const z of[-11,-6,0,6,11])box(11,.14,.22,x,sideRoof-.17,z,edge);}
  for(const x of[-7,7])for(const z of[-11.9,11.9])column(x,z,7,.39);
  for(const z of[-12,12]){box(14.7,.22,.7,0,7.03,z,chalk);box(14.8,.1,.84,0,7.19,z,edge);}
  // A pediment and quiet inscription above the main painting.
  const pedimentShape=new T.Shape();pedimentShape.moveTo(-3.2,0);pedimentShape.lineTo(0,1.05);pedimentShape.lineTo(3.2,0);pedimentShape.closePath();
  mesh(new T.ExtrudeGeometry(pedimentShape,{depth:.15,bevelEnabled:false}),chalk,0,5.7,-11.63);
  box(6.6,.14,.36,0,5.68,-11.62,edge);
  world.label('M U S E U M   O F   L O V E',5.5,.48,0,5.08,-11.73,0);
  world.label('OUR LITTLE FOREVER',3.25,.24,0,4.53,-11.72,0);
  world.label('THE DRAWING GARDEN',3.5,.28,-12.5,5.03,-11.72,0);
  world.label('MEMORIES IN BLOOM',3.5,.28,12.5,5.03,-11.72,0);

  // Small olive trees in carved urns leave the enlarged collection unobstructed.
  scenery.plantOlive(-5,8.7,.46);scenery.plantOlive(5,8.7,.46);
  scenery.plantOlive(-5.2,-9.4,.43);scenery.plantOlive(5.2,-9.4,.43);
  for(const x of[-15,15])for(const z of[-8.4,8.4])scenery.plantOlive(x,z,.4);
  scenery.finishPlants();

  // Cascading ivy and wisteria hug the arches instead of blocking the walkways.
  const leafGeo=new T.SphereGeometry(1,7,5),petalGeo=new T.IcosahedronGeometry(.085,1);
  const leaves:T.Matrix4[]=[],leafColors:T.Color[]=[],flowers:T.Matrix4[]=[],flowerColors:T.Color[]=[];
  const transform=new T.Object3D();
  function clearOfArtwork(x:number,y:number,z:number,padding:number){
    return !SLOTS.some(slot=>{
      if(slot.kind!=='image')return false;
      const dx=x-slot.x,dz=z-slot.z,depth=dx*Math.sin(slot.yaw)+dz*Math.cos(slot.yaw),across=dx*Math.cos(slot.yaw)-dz*Math.sin(slot.yaw),half=(slot.maxSize??3.5)/2+.11+padding;
      return depth>-.1-padding&&depth<.65+padding&&Math.abs(across)<half&&Math.abs(y-2.4)<half;
    });
  }
  function leaf(x:number,y:number,z:number,s=.17){if(!clearOfArtwork(x,y,z,s))return;transform.position.set(x,y,z);transform.rotation.set(rand(),rand()*6,rand());transform.scale.set(s,.45*s,s*.6);transform.updateMatrix();leaves.push(transform.matrix.clone());leafColors.push(new T.Color(['#90a875','#6e957a','#afbb85'][Math.floor(rand()*3)]));}
  function blossom(x:number,y:number,z:number){if(!clearOfArtwork(x,y,z,.12))return;transform.position.set(x,y,z);transform.rotation.set(rand()*6,rand()*6,0);transform.scale.setScalar(.55+rand()*.7);transform.updateMatrix();flowers.push(transform.matrix.clone());flowerColors.push(new T.Color(['#e4d7b5','#f0e6cf','#d8b9a6'][Math.floor(rand()*3)]));}
  function vine(x:number,z:number,width:number,spring:number,yaw:number){
    const root=new T.Group();root.position.set(x,0,z);root.rotation.y=yaw;scene.add(root);
    const points:T.Vector3[]=[];for(let i=0;i<=22;i++){const a=i/22*Math.PI;points.push(new T.Vector3(Math.cos(a)*(width/2+.27),spring+Math.sin(a)*(width/2+.27),.3));}
    curve(points,.028,sage,root);root.updateMatrixWorld(true);
    for(let i=0;i<110;i++){const a=rand()*Math.PI,local=new T.Vector3(Math.cos(a)*(width/2+.28)+(rand()-.5)*.3,spring+Math.sin(a)*(width/2+.28)+(rand()-.5)*.35,.28+(rand()-.5)*.25);const p=root.localToWorld(local);leaf(p.x,p.y,p.z,.13+rand()*.12);}
    for(let i=0;i<10;i++){const a=.2+rand()*2.7,origin=root.localToWorld(new T.Vector3(Math.cos(a)*(width/2+.24),spring+Math.sin(a)*(width/2+.24),.35));const length=.3+rand()*1.15;
      const stem=[origin,new T.Vector3(origin.x+.04,origin.y-length/2,origin.z+.04),new T.Vector3(origin.x-.06,origin.y-length,origin.z)];
      if(stem.every(p=>clearOfArtwork(p.x,p.y,p.z,.08)))curve(stem,.009,wood);
      for(let j=0;j<9;j++){const t=j/9;leaf(origin.x+.07*Math.sin(j),origin.y-t*length,origin.z+.08*Math.cos(j),.13*(1-t*.5));if(i%2===0)blossom(origin.x,origin.y-t*length,origin.z+.09);}
    }
  }
  for(const x of[-7,7])for(const z of[-5,5])vine(x+(x<0?.25:-.25),z,6,3.2,Math.PI/2);
  for(const x of[-5.25,5.25])vine(x,-11.66,3.5,2.85,0);

  // Low beds of grass and flowers, arranged clear of the artwork and paths.
  for(const x of[-6.2,6.2])for(const z of[-10.1,0,10.1]){
    box(.76,.27,1.8,x,.135,z,edge);box(.64,.04,1.68,x,.29,z,wood);
    for(let i=0;i<45;i++){const px=x+(rand()-.5)*.55,pz=z+(rand()-.5)*1.5,y=.38+rand()*.2;leaf(px,y,pz,.16+rand()*.12);if(i%3===0)blossom(px,y+.1,pz);}
    world.obstacles.push({x,z,w:.85,d:1.9});
  }
  const leafInstances=new T.InstancedMesh(leafGeo,new T.MeshStandardMaterial({roughness:1}),leaves.length);
  leaves.forEach((matrix,i)=>{leafInstances.setMatrixAt(i,matrix);leafInstances.setColorAt(i,leafColors[i]);});leafInstances.castShadow=true;scene.add(leafInstances);
  const flowerInstances=new T.InstancedMesh(petalGeo,new T.MeshStandardMaterial({roughness:1,emissive:'#8d5d63',emissiveIntensity:.04}),flowers.length);
  flowers.forEach((matrix,i)=>{flowerInstances.setMatrixAt(i,matrix);flowerInstances.setColorAt(i,flowerColors[i]);});scene.add(flowerInstances);

  // Cozy stone seats with linen cushions, small side tables, and candles.
  const glows:T.Sprite[]=[],flames:T.Mesh[]=[];
  const glowCanvas=document.createElement('canvas');glowCanvas.width=glowCanvas.height=64;const gc=glowCanvas.getContext('2d')!,gradient=gc.createRadialGradient(32,32,0,32,32,32);gradient.addColorStop(0,'rgba(255,243,193,1)');gradient.addColorStop(.18,'rgba(255,221,151,.55)');gradient.addColorStop(1,'rgba(255,208,120,0)');gc.fillStyle=gradient;gc.fillRect(0,0,64,64);const glowTexture=new T.CanvasTexture(glowCanvas);
  function candle(x:number,y:number,z:number,h=.25){cylinder(.08,.085,h,x,y+h/2,z,chalk);const flame=mesh(new T.SphereGeometry(.048,8,6),new T.MeshBasicMaterial({color:new T.Color(3.4,2.0,.75)}),x,y+h+.07,z);flame.scale.y=1.7;flame.castShadow=false;flame.raycast=()=>{};flames.push(flame);const halo=new T.Sprite(new T.SpriteMaterial({map:glowTexture,color:'#ffe1a5',transparent:true,depthWrite:false,opacity:.6,blending:T.AdditiveBlending}));halo.position.set(x,y+h+.06,z);halo.scale.setScalar(.63);halo.raycast=()=>{};scene.add(halo);glows.push(halo);}
  for(const x of[-3.9,3.9]){
    box(1.05,.16,3.45,x,.49,4.4,stone);for(const z of[3.18,5.62])box(.78,.4,.28,x,.2,z,edge);
    for(const z of[3.28,4.42,5.55]){const cushion=mesh(new T.SphereGeometry(1,16,10),linen,x,.64,z);cushion.scale.set(.5,.13,.5);}
    box(.1,.37,3.4,x+(x<0?-.47:.47),.68,4.4,stone);
    world.obstacles.push({x,z:4.4,w:1.1,d:3.5});world.contactShadow(x,4.4,2,4.4,scene);
    cylinder(.39,.29,.42,x,.21,7,stone);candle(x-.12,.43,6.94,.26);candle(x+.13,.43,7.06,.17);world.obstacles.push({x,z:7,w:.8,d:.8});
  }
  for(const x of[-2,2]){cylinder(.31,.38,.22,x,.11,-8.6,stone);candle(x,.23,-8.6,.4);candle(x+.17,.23,-8.5,.21);world.obstacles.push({x,z:-8.6,w:.75,d:.75});}
  for(const x of[-10.2,10.2]){cylinder(.24,.3,.3,x,.15,8.8,rose);candle(x,.32,8.8,.28);world.obstacles.push({x,z:8.8,w:.6,d:.6});}

  // Blue moonlight and warm gallery lamps keep the painted night inviting and readable.
  scene.add(new T.HemisphereLight('#d6e1e2','#af9d7e',1.0));
  const moon=new T.DirectionalLight('#e1e7e4',1.5);moon.position.set(-11,24,14);moon.castShadow=true;moon.shadow.mapSize.set(2048,2048);moon.shadow.camera.left=-26;moon.shadow.camera.right=26;moon.shadow.camera.top=25;moon.shadow.camera.bottom=-25;moon.shadow.normalBias=.03;moon.shadow.bias=-.0002;moon.shadow.radius=3;moon.shadow.intensity=.64;moon.shadow.camera.near=1;moon.shadow.camera.far=90;scene.add(moon);
  for(const x of[-12.5,0,12.5])for(const z of[-7,6]){const fill=new T.RectAreaLight('#ffe9cb',x===0?1.85:4.0,8,8);fill.position.set(x,x===0?6.3:8.8,z);fill.rotation.x=-Math.PI/2;scene.add(fill);}
  for(const x of[-4.4,4.4]){const fill=new T.PointLight('#ffd9a2',7,7,2);fill.position.set(x,1.5,7);scene.add(fill);}
  // Brass picture lights sit above every hanging position, including the empty ones.
  const lampGlow=new T.MeshBasicMaterial({color:new T.Color(2.3,1.6,.8)});
  for(const slot of SLOTS.filter(slot=>slot.kind==='image')){
    const fixture=new T.Group();fixture.position.set(slot.x,0,slot.z);fixture.rotation.y=slot.yaw;scene.add(fixture);
    box(.16,.18,.05,0,4.55,.03,gold,fixture);box(.045,.045,.32,0,4.58,.18,gold,fixture);
    box(.75,.065,.13,0,4.56,.35,gold,fixture);const bulb=box(.66,.013,.09,0,4.52,.35,lampGlow,fixture);bulb.castShadow=false;
  }
  const motesGeometry=new T.BufferGeometry(),positions=new Float32Array(90*3),bases=new Float32Array(90*3);
  for(let i=0;i<90;i++){bases[i*3]=(rand()-.5)*31;bases[i*3+1]=.7+rand()*5.2;bases[i*3+2]=(rand()-.5)*21;}positions.set(bases);motesGeometry.setAttribute('position',new T.BufferAttribute(positions,3));
  const motes=new T.Points(motesGeometry,new T.PointsMaterial({map:glowTexture,color:'#fff0c6',size:.16,transparent:true,opacity:.65,depthWrite:false,blending:T.AdditiveBlending}));motes.raycast=()=>{};scene.add(motes);
  // Merge static surfaces by finish to keep the lush scene inexpensive to draw.
  // Animated flames and instanced planting retain their own objects.
  scene.updateMatrixWorld(true);
  const batches=new Map<string,{source:T.Mesh[];geometry:T.BufferGeometry[];material:T.Material;cast:boolean;receive:boolean;pick:boolean}>();
  scene.traverse(object=>{
    if(!(object instanceof T.Mesh)||object instanceof T.InstancedMesh||object.userData.keepSeparate||flames.includes(object)||Array.isArray(object.material))return;
    const pick=object.raycast===T.Mesh.prototype.raycast,key=object.material.uuid+':'+object.castShadow+':'+object.receiveShadow+':'+pick;
    let batch=batches.get(key);if(!batch){batch={source:[],geometry:[],material:object.material,cast:object.castShadow,receive:object.receiveShadow,pick};batches.set(key,batch);}
    const transformed=object.geometry.clone().applyMatrix4(object.matrixWorld);
    const geometry=transformed.index?transformed.toNonIndexed():transformed;
    if(geometry!==transformed)transformed.dispose();
    batch.geometry.push(geometry);batch.source.push(object);
  });
  const retired=new Set<T.BufferGeometry>();
  for(const batch of batches.values()){
    const geometry=mergeGeometries(batch.geometry);batch.geometry.forEach(g=>g.dispose());if(!geometry)continue;
    const combined=new T.Mesh(geometry,batch.material);combined.castShadow=batch.cast;combined.receiveShadow=batch.receive;if(!batch.pick)combined.raycast=()=>{};scene.add(combined);
    batch.source.forEach(object=>{object.removeFromParent();retired.add(object.geometry);});
  }
  retired.forEach(geometry=>geometry.dispose());
  const motionPreference=window.matchMedia('(prefers-reduced-motion: reduce)');
  return (time:number)=>{if(motionPreference.matches)return;const t=time*.001;scenery.update(t);for(let i=0;i<90;i++){positions[i*3]=bases[i*3]+Math.sin(t*.2+i)*.2;positions[i*3+1]=bases[i*3+1]+Math.sin(t*.35+i*2)*.3;positions[i*3+2]=bases[i*3+2]+Math.cos(t*.18+i)*.2;}motesGeometry.attributes.position.needsUpdate=true;flames.forEach((flame,i)=>{flame.scale.y=1.7+Math.sin(t*3+i)*.12;});glows.forEach((glow,i)=>{(glow.material as T.SpriteMaterial).opacity=.52+Math.sin(t*2+i)*.06;});};
}
