import * as T from 'three';
import { GLTFLoader } from 'three/examples/jsm/loaders/GLTFLoader.js';
import { MeshoptDecoder } from 'meshoptimizer/decoder';
import { RoomEnvironment } from 'three/examples/jsm/environments/RoomEnvironment.js';
import { RectAreaLightUniformsLib } from 'three/examples/jsm/lights/RectAreaLightUniformsLib.js';
import { EffectComposer } from 'three/examples/jsm/postprocessing/EffectComposer.js';
import { RenderPass } from 'three/examples/jsm/postprocessing/RenderPass.js';
import { UnrealBloomPass } from 'three/examples/jsm/postprocessing/UnrealBloomPass.js';
import { ShaderPass } from 'three/examples/jsm/postprocessing/ShaderPass.js';
import { FXAAShader } from 'three/examples/jsm/shaders/FXAAShader.js';
import { OutputPass } from 'three/examples/jsm/postprocessing/OutputPass.js';
import { buildRomanticMuseum } from './romantic-architecture';
import { SLOTS, type Exhibit } from './exhibition';
type Callbacks = {onPosition:(x:number,z:number,yaw:number)=>void;onSelect:(id:string)=>void;onLock:(locked:boolean)=>void;onError:(message:string)=>void};
type Obstacle = {x:number;z:number;w:number;d:number};
export class MuseumWorld {
  scene=new T.Scene(); camera=new T.PerspectiveCamera(64,1,.05,180); renderer:T.WebGLRenderer;
  gallery=new T.Group(); keys=new Set<string>(); obstacles:Obstacle[]=[]; exhibits:Exhibit[]=[];
  yaw=0; pitch=0; blocked=false; disposed=false; frame=0; generation=0; dragging=false; moved=0;
  lastX=0;lastY=0;lastTime=0;lastReport=0; cleanups:(()=>void)[]=[]; envTarget:T.WebGLRenderTarget;
  composer:EffectComposer; edgePass?:ShaderPass; bloom:UnrealBloomPass; animateGarden:(time:number)=>void=()=>{};
  constructor(public host:HTMLElement,public cb:Callbacks) {
    RectAreaLightUniformsLib.init();
    this.renderer=new T.WebGLRenderer({antialias:true,powerPreference:'high-performance'});
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio||1,2));
    this.renderer.shadowMap.enabled=true;this.renderer.shadowMap.type=T.PCFSoftShadowMap;
    this.renderer.outputColorSpace=T.SRGBColorSpace;this.renderer.toneMapping=T.ACESFilmicToneMapping;this.renderer.toneMappingExposure=.93;
    this.renderer.domElement.setAttribute('aria-label','Interactive 3D museum. Drag to look around. Use W A S D to walk.');
    this.renderer.domElement.tabIndex=0;host.appendChild(this.renderer.domElement);
    this.scene.background=new T.Color('#263e56');this.scene.fog=new T.FogExp2('#69818c',.0075);
    this.camera.position.set(.7,1.72,9.5);this.yaw=.065;this.pitch=.025;
    const pmrem=new T.PMREMGenerator(this.renderer),environment=new RoomEnvironment();
    this.envTarget=pmrem.fromScene(environment,.025);this.scene.environment=this.envTarget.texture;this.scene.environmentIntensity=.2;environment.dispose();pmrem.dispose();
    this.architecture();this.scene.add(this.gallery);
    // The glow pipeline renders offscreen, so smoothing must be enabled here too.
    const gl=this.renderer.getContext() as WebGL2RenderingContext;
    const supported=gl.getInternalformatParameter(gl.RENDERBUFFER,gl.RGBA16F,gl.SAMPLES) as Int32Array|null;
    const samples=Math.max(0,...Array.from(supported??[]).filter(value=>value<=4));
    const target=new T.WebGLRenderTarget(1,1,{type:T.HalfFloatType,samples});
    this.composer=new EffectComposer(this.renderer,target);this.composer.addPass(new RenderPass(this.scene,this.camera));
    this.bloom=new UnrealBloomPass(new T.Vector2(1,1),.17,.65,1.3);this.composer.addPass(this.bloom);this.composer.addPass(new OutputPass());
    if(samples<2){this.edgePass=new ShaderPass(FXAAShader);this.composer.addPass(this.edgePass);}
    this.bind();this.resize();
    this.frame=requestAnimationFrame(this.tick);
  }
  material(color:string,roughness=.75,metalness=0) {return new T.MeshStandardMaterial({color,roughness,metalness});}
  box(w:number,h:number,d:number,x:number,y:number,z:number,material:T.Material,parent:T.Object3D=this.scene) {
    const m=new T.Mesh(new T.BoxGeometry(w,h,d),material);m.position.set(x,y,z);m.castShadow=true;m.receiveShadow=true;parent.add(m);return m;
  }
  architecture(){this.animateGarden=buildRomanticMuseum(this);}
  label(text:string,w:number,h:number,x:number,y:number,z:number,yaw:number,_?:T.Material,parent:T.Object3D=this.scene) {
    const canvas=document.createElement('canvas');canvas.width=1024;canvas.height=Math.round(1024*h/w);const c=canvas.getContext('2d')!;
    c.fillStyle='#e8dcc3';c.fillRect(0,0,canvas.width,canvas.height);c.fillStyle='#78694e';c.font=`${canvas.height*.52}px Georgia`;c.textAlign='center';c.textBaseline='middle';c.fillText(text,512,canvas.height/2,980);
    const tex=new T.CanvasTexture(canvas);tex.colorSpace=T.SRGBColorSpace;
    const mesh=new T.Mesh(new T.PlaneGeometry(w,h),new T.MeshStandardMaterial({map:tex,roughness:1}));mesh.position.set(x,y,z);mesh.rotation.y=yaw;parent.add(mesh);return mesh;
  }
  contactShadow(x:number,z:number,w:number,d:number,parent:T.Object3D) {
    const canvas=document.createElement('canvas');canvas.width=canvas.height=128;const c=canvas.getContext('2d')!,g=c.createRadialGradient(64,64,8,64,64,64);g.addColorStop(0,'rgba(28,23,16,.33)');g.addColorStop(.5,'rgba(28,23,16,.15)');g.addColorStop(1,'rgba(28,23,16,0)');c.fillStyle=g;c.fillRect(0,0,128,128);
    const mesh=new T.Mesh(new T.PlaneGeometry(w,d),new T.MeshBasicMaterial({map:new T.CanvasTexture(canvas),transparent:true,depthWrite:false}));mesh.rotation.x=-Math.PI/2;mesh.position.set(x,.006,z);parent.add(mesh);
  }
  disposeGroup(group:T.Object3D) {
    group.traverse(o=>{const m=o as T.Mesh;if(m.geometry)m.geometry.dispose();if(m.material)for(const material of Array.isArray(m.material)?m.material:[m.material]){for(const value of Object.values(material))if(value instanceof T.Texture)value.dispose();material.dispose();}});
  }
  async setExhibits(exhibits:Exhibit[]) {
    const generation=++this.generation;this.exhibits=exhibits;this.disposeGroup(this.gallery);this.gallery.clear();
    const queue=[...exhibits].sort((a,b)=>{const distance=(item:Exhibit)=>{const slot=SLOTS.find(s=>s.id===item.slot);return slot?Math.hypot(slot.x-this.camera.position.x,slot.z-this.camera.position.z):Infinity;};return distance(a)-distance(b);});
    const load=async(item:Exhibit)=>{
      const slot=SLOTS.find(s=>s.id===item.slot);if(!slot)return;
      const group=new T.Group();group.userData.id=item.id;group.position.set(slot.x,0,slot.z);group.rotation.y=slot.yaw;
      try {
        if(item.kind==='image') {
          const tex=await new T.TextureLoader().loadAsync(item.url);tex.colorSpace=T.SRGBColorSpace;tex.anisotropy=8;
          if(this.disposed||generation!==this.generation){tex.dispose();return;}
          // Full artwork remains available in the detail panel. Gallery textures
          // use less GPU memory so a full collection also fits smaller devices.
          const textureScale=Math.min(1,1024/Math.max(tex.image.width,tex.image.height));
          if(textureScale<1){const canvas=document.createElement('canvas');canvas.width=Math.max(1,Math.round(tex.image.width*textureScale));canvas.height=Math.max(1,Math.round(tex.image.height*textureScale));canvas.getContext('2d')!.drawImage(tex.image,0,0,canvas.width,canvas.height);tex.image=canvas;tex.needsUpdate=true;}
          const size=Math.min(item.size,slot.maxSize??3.5),ratio=tex.image.width/tex.image.height,w=ratio>1?size:size*ratio,h=ratio>1?size/ratio:size,y=2.4;
          const frame=this.material(item.frame==='oak'?'#6f4d2f':item.frame==='black'?'#252824':'#ece9e0',.58);
          this.box(w+.22,h+.22,.1,0,y,.04,frame,group);
          this.box(w+.08,h+.08,.025,0,y,.1,this.material('#f3efdf'),group);
          const art=new T.Mesh(new T.PlaneGeometry(w,h),new T.MeshStandardMaterial({map:tex,roughness:.91,emissive:'#ffffff',emissiveMap:tex,emissiveIntensity:.11}));art.position.set(0,y,.116);group.add(art);
          this.label(item.title,.85,.16,w/2-.31,y-h/2-.25,.07,0,undefined,group);
        } else {
          const plinthWidth=Math.max(1.65,item.size*.85),plinth=this.material('#e2d5b9',.88);
          for(const [radius,height,y] of[[plinthWidth*.58,.14,.07],[plinthWidth*.5,.64,.46],[plinthWidth*.56,.06,.81]]){const base=new T.Mesh(new T.CylinderGeometry(radius,radius,height,48),plinth);base.position.y=y;base.castShadow=true;base.receiveShadow=true;group.add(base);}
          this.contactShadow(0,0,plinthWidth+1.5,plinthWidth+1.5,group);
          let object:T.Object3D;
          if(item.builtin) {
            const finish=new T.MeshStandardMaterial({color:item.builtin==='knot'?'#c7a367':'#9cb7a5',metalness:.55,roughness:.4});
            if(item.builtin==='knot'){
              object=new T.Group();
              const points:T.Vector3[]=[];for(let i=0;i<=80;i++){const t=i/80*Math.PI*2;points.push(new T.Vector3(.055*16*Math.sin(t)**3,.055*(13*Math.cos(t)-5*Math.cos(2*t)-2*Math.cos(3*t)-Math.cos(4*t)),0));}
              const heartGeometry=new T.TubeGeometry(new T.CatmullRomCurve3(points,true),120,.095,14,true);
              for(const side of[-1,1]){const heart=new T.Mesh(heartGeometry,finish);heart.position.set(side*.36,side*.08,side*.1);heart.rotation.set(.1,side*.36,side*-.16);object.add(heart);}
            }else{object=new T.Mesh(new T.TorusKnotGeometry(.63,.12,160,24,3,2),finish);object.rotation.x=.3;}
          } else {
            const gltf=await new GLTFLoader().setMeshoptDecoder(MeshoptDecoder).loadAsync(item.url);object=gltf.scene;
          }
          if(this.disposed||generation!==this.generation){this.disposeGroup(object);this.disposeGroup(group);return;}
          object.rotation.y+=T.MathUtils.degToRad(item.rotation);object.updateMatrixWorld(true);
          let bounds=new T.Box3().setFromObject(object),dimensions=bounds.getSize(new T.Vector3());const max=Math.max(dimensions.x,dimensions.y,dimensions.z);
          if(!Number.isFinite(max)||max===0)throw new Error('This model has no visible geometry.');
          object.scale.multiplyScalar(item.size/max);
          object.updateMatrixWorld(true);bounds=new T.Box3().setFromObject(object);const center=bounds.getCenter(new T.Vector3());object.position.x-=center.x;object.position.z-=center.z;object.position.y+=.845-bounds.min.y;
          object.traverse(o=>{if(o instanceof T.Mesh){o.castShadow=true;o.receiveShadow=true;}});group.add(object);
          this.label(item.title,1.2,.19,0,.51,plinthWidth/2+.006,0,undefined,group);
        }
        if(this.disposed||generation!==this.generation){this.disposeGroup(group);return;}this.gallery.add(group);
      } catch { this.disposeGroup(group);if(!this.disposed&&generation===this.generation)this.cb.onError(`Could not display “${item.title}”. Please check its file.`); }
    };
    await Promise.all(Array.from({length:Math.min(3,queue.length)},async()=>{while(queue.length&&!this.disposed&&generation===this.generation){await load(queue.shift()!);}}));
  }
  valid(x:number,z:number) {
    const radius=.28;if(x < -17.5||x>17.5||z < -11.5||z>11.5)return false;
    const objects=[...this.obstacles,...this.exhibits.filter(e=>e.kind==='model').map(e=>{const slot=SLOTS.find(s=>s.id===e.slot)!;return{x:slot.x,z:slot.z,w:Math.max(1.75,e.size+.1),d:Math.max(1.75,e.size+.1)};})];
    return !objects.some(o=>Math.abs(x-o.x)<o.w/2+radius&&Math.abs(z-o.z)<o.d/2+radius);
  }
  setBlocked(value:boolean){this.blocked=value;this.keys.clear();this.dragging=false;if(value&&document.pointerLockElement)document.exitPointerLock();}
  go(room:string) {this.keys.clear();this.camera.position.set(room==='West gallery'?-11:room==='East gallery'?11:0,1.72,9.5);this.yaw=0;this.pitch=0;}
  focus(item:Exhibit) {const s=SLOTS.find(s=>s.id===item.slot)!;const distance=item.kind==='image'?4:4.3;this.camera.position.set(s.x+Math.sin(s.yaw)*distance,1.72,s.z+Math.cos(s.yaw)*distance);this.yaw=s.yaw;this.pitch=.07;}
  lock(){this.renderer.domElement.requestPointerLock()?.catch(()=>this.cb.onError('Drag to look around; use W A S D to move.'));}
  pick(x:number,y:number) {const ray=new T.Raycaster();ray.setFromCamera(new T.Vector2(x,y),this.camera);const hits=ray.intersectObjects(this.scene.children,true);if(hits[0]){let object:T.Object3D|null=hits[0].object;while(object&&!object.userData.id)object=object.parent;if(object)this.cb.onSelect(object.userData.id);}}
  bind() {
    const canvas=this.renderer.domElement;
    const on=(target:EventTarget,name:string,fn:EventListener)=>{target.addEventListener(name,fn);this.cleanups.push(()=>target.removeEventListener(name,fn));};
    on(window,'keydown',((e:KeyboardEvent)=>{if(this.blocked||e.ctrlKey||e.metaKey||e.altKey)return;if(['INPUT','TEXTAREA','SELECT','BUTTON'].includes((e.target as HTMLElement)?.tagName))return;
      if(['KeyW','KeyA','KeyS','KeyD','ArrowUp','ArrowDown','ArrowLeft','ArrowRight','ShiftLeft','ShiftRight'].includes(e.code)){e.preventDefault();this.keys.add(e.code);}if(e.code==='KeyE')this.pick(0,0);
    })as EventListener);
    on(window,'keyup',((e:KeyboardEvent)=>{this.keys.delete(e.code);})as EventListener);
    on(window,'blur',(()=>{this.keys.clear();this.dragging=false;})as EventListener);
    on(document,'visibilitychange',(()=>{this.keys.clear();this.dragging=false;})as EventListener);
    on(document,'pointerlockchange',(()=>{this.keys.clear();this.cb.onLock(document.pointerLockElement===canvas);})as EventListener);
    on(canvas,'pointerdown',((e:PointerEvent)=>{if(this.blocked)return;canvas.focus();this.dragging=true;this.moved=0;this.lastX=e.clientX;this.lastY=e.clientY;if(!document.pointerLockElement)canvas.setPointerCapture(e.pointerId);})as EventListener);
    on(document,'pointermove',((e:PointerEvent)=>{if(this.blocked||(!this.dragging&&document.pointerLockElement!==canvas))return;
      const locked=document.pointerLockElement===canvas,dx=locked?e.movementX:e.clientX-this.lastX,dy=locked?e.movementY:e.clientY-this.lastY;this.lastX=e.clientX;this.lastY=e.clientY;this.moved+=Math.abs(dx)+Math.abs(dy);this.yaw-=dx*.003;this.pitch=T.MathUtils.clamp(this.pitch-dy*.003,-1.35,1.35);
    })as EventListener);
    on(canvas,'pointerup',((e:PointerEvent)=>{if(this.blocked)return;if(this.moved<6){const rect=canvas.getBoundingClientRect();document.pointerLockElement===canvas?this.pick(0,0):this.pick((e.clientX-rect.left)/rect.width*2-1,-(e.clientY-rect.top)/rect.height*2+1);}this.dragging=false;})as EventListener);
    on(canvas,'pointercancel',(()=>{this.dragging=false;this.keys.clear();})as EventListener);
    on(canvas,'webglcontextlost',((e:Event)=>{e.preventDefault();this.cb.onError('The 3D view paused. Reload the page to reconnect.');})as EventListener);
    const observer=new ResizeObserver(()=>this.resize());observer.observe(this.host);this.cleanups.push(()=>observer.disconnect());
  }
  resize(){const w=Math.max(1,this.host.clientWidth),h=Math.max(1,this.host.clientHeight);const ratio=Math.min(window.devicePixelRatio||1,2);if(this.renderer.getPixelRatio()!==ratio){this.renderer.setPixelRatio(ratio);this.composer?.setPixelRatio(ratio);}this.camera.aspect=w/h;this.camera.updateProjectionMatrix();this.renderer.setSize(w,h);this.composer?.setSize(w,h);if(this.edgePass)this.edgePass.uniforms.resolution.value.set(1/(w*ratio),1/(h*ratio));}
  tick=(time:number)=>{
    if(this.disposed)return;const dt=Math.min((time-this.lastTime)/1000,.04);this.lastTime=time;
    if(!this.blocked){let f=Number(this.keys.has('KeyW')||this.keys.has('ArrowUp'))-Number(this.keys.has('KeyS')||this.keys.has('ArrowDown')),s=Number(this.keys.has('KeyD'))-Number(this.keys.has('KeyA'));
      this.yaw+=(Number(this.keys.has('ArrowLeft'))-Number(this.keys.has('ArrowRight')))*dt*1.4;
      const n=Math.hypot(f,s)||1,speed=dt*(this.keys.has('ShiftLeft')||this.keys.has('ShiftRight')?5:2.7);f=f/n*speed;s=s/n*speed;
      const dx=-Math.sin(this.yaw)*f+Math.cos(this.yaw)*s,dz=-Math.cos(this.yaw)*f-Math.sin(this.yaw)*s;
      if(this.valid(this.camera.position.x+dx,this.camera.position.z))this.camera.position.x+=dx;
      if(this.valid(this.camera.position.x,this.camera.position.z+dz))this.camera.position.z+=dz;
    }
    this.camera.rotation.set(this.pitch,this.yaw,0,'YXZ');this.animateGarden(time);this.composer.render();
    if(time-this.lastReport>100){this.lastReport=time;this.cb.onPosition(this.camera.position.x,this.camera.position.z,this.yaw);}
    this.frame=requestAnimationFrame(this.tick);
  };
  dispose(){this.disposed=true;this.generation++;cancelAnimationFrame(this.frame);this.cleanups.forEach(f=>f());if(document.pointerLockElement===this.renderer.domElement)document.exitPointerLock();this.disposeGroup(this.scene);this.envTarget.dispose();this.composer.passes.forEach(pass=>pass.dispose());this.composer.dispose();this.renderer.dispose();this.renderer.domElement.remove();}
}
