import { readJson } from './request-body';
import { config, failure, HttpError, storageConfigured, supabase, writeAllowed } from './storage';
const encoder=new TextEncoder(), lifetime=8*60*60;
const localSessions=new Map<string,number>(), localAttempts=new Map<string,{count:number;expires:number}>();
const hex=(bytes:ArrayBuffer)=>Array.from(new Uint8Array(bytes),v=>v.toString(16).padStart(2,'0')).join('');
const unhex=(s:string)=>new Uint8Array(s.match(/.{2}/g)!.map(v=>parseInt(v,16)));
export async function digest(value:string){return hex(await crypto.subtle.digest('SHA-256',encoder.encode(value)));}
function localOnly(req:Request){return config().LOCAL_PREVIEW==='true'&&['localhost','127.0.0.1'].includes(new URL(req.url).hostname);}
function cookieName(req:Request){return new URL(req.url).protocol==='https:'?'__Host-museum_admin':'museum_admin';}
function cookie(req:Request,token:string,maxAge=lifetime){return `${cookieName(req)}=${token}; Path=/; HttpOnly; SameSite=Strict; Max-Age=${maxAge}${new URL(req.url).protocol==='https:'?'; Secure':''}`;}
function token(req:Request){return req.headers.get('cookie')?.split(';').map(s=>s.trim()).find(s=>s.startsWith(cookieName(req)+'='))?.split('=')[1]||'';}
async function sessionKey(req:Request){const value=token(req);return /^[a-f0-9]{64}$/.test(value)?digest(value):'';}
export async function authenticated(req:Request){
  const key=await sessionKey(req);if(!key)return false;
  if(localOnly(req)&&!storageConfigured())return (localSessions.get(key)||0)>Date.now();
  if(!storageConfigured())return false;
  const rows=await(await supabase('/rest/v1/museum_sessions?token_hash=eq.'+key+'&expires_at=gt.'+encodeURIComponent(new Date().toISOString())+'&select=token_hash')).json() as unknown[];
  return rows.length===1;
}
export async function requireAdmin(req:Request):Promise<Response|null>{
  if(!writeAllowed(req))return failure(new Error('This request is not allowed.'),403);
  try{if(!await authenticated(req))return failure(new Error('Please sign in to the admin page.'),401);return null;}catch(e){return failure(e);}
}
async function allowLogin(req:Request){
  const key=await digest('museum-login:'+ (req.headers.get('cf-connecting-ip')||'local'));
  if(localOnly(req)&&!storageConfigured()){
    let entry=localAttempts.get(key);if(!entry||entry.expires<Date.now()){entry={count:0,expires:Date.now()+15*60000};localAttempts.set(key,entry);}
    return ++entry.count<=8;
  }
  return await(await supabase('/rest/v1/rpc/museum_allow_login',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({client_key:key})})).json() as boolean;
}
export async function login(req:Request){
  if(!writeAllowed(req))return failure(new Error('This request is not allowed.'),403);
  try{
    if(Number(req.headers.get('content-length'))>4096)throw new HttpError('Invalid sign-in request.',413);
    const hash=config().ADMIN_PASSWORD_HASH, username=config().ADMIN_USERNAME;
    if(!hash||!username)throw new HttpError('The admin account has not been configured yet.',503);
    if(!await allowLogin(req))throw new HttpError('Too many sign-in attempts. Please try again in 15 minutes.',429);
    const data=await readJson(req,4096) as {username?:string;password?:string};
    if(typeof data.password!=='string'||data.password.length>256)throw new HttpError('Incorrect username or password.',401);
    const [scheme,iterations,salt,expected]=hash.split(':');
    if(scheme!=='pbkdf2-sha256'||!/^\d+$/.test(iterations)||!salt||!expected)throw new HttpError('The admin account needs configuration.',503);
    const material=await crypto.subtle.importKey('raw',encoder.encode(data.password),'PBKDF2',false,['deriveBits']);
    const actual=new Uint8Array(await crypto.subtle.deriveBits({name:'PBKDF2',salt:unhex(salt),iterations:Number(iterations),hash:'SHA-256'},material,256));
    const wanted=unhex(expected);let mismatch=actual.length^wanted.length;for(let i=0;i<actual.length;i++)mismatch|=actual[i]^wanted[i];
    if(mismatch||data.username!==username)throw new HttpError('Incorrect username or password.',401);
    const value=hex(crypto.getRandomValues(new Uint8Array(32)).buffer), key=await digest(value), expiry=Date.now()+lifetime*1000;
    if(localOnly(req)&&!storageConfigured())localSessions.set(key,expiry);
    else await supabase('/rest/v1/museum_sessions',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({token_hash:key,expires_at:new Date(expiry).toISOString()})});
    return Response.json({authenticated:true,username},{headers:{'Set-Cookie':cookie(req,value),'Cache-Control':'no-store'}});
  }catch(e){return failure(e);}
}
export async function logout(req:Request){
  if(!writeAllowed(req))return failure(new Error('This request is not allowed.'),403);
  try{const key=await sessionKey(req);if(key){if(localOnly(req)&&!storageConfigured())localSessions.delete(key);else await supabase('/rest/v1/museum_sessions?token_hash=eq.'+key,{method:'DELETE'});}
    return Response.json({ok:true},{headers:{'Set-Cookie':cookie(req,'',0),'Cache-Control':'no-store'}});
  }catch(e){return failure(e);}
}
export async function session(req:Request){try{const signedIn=await authenticated(req);return Response.json({authenticated:signedIn,username:signedIn?config().ADMIN_USERNAME:undefined,storageReady:signedIn?storageConfigured():undefined},{headers:{'Cache-Control':'no-store'}});}catch(e){return failure(e);}}
