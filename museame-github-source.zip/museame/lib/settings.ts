export const PALETTES=[
  {id:'candlelight',name:'Candlelight',description:'Warm parchment and antique gold',colors:['#17232c','#e2bd7f','#f6f2e9']},
  {id:'olive',name:'Olive garden',description:'Soft olive and warm stone',colors:['#192720','#c0cba2','#f2f3e9']},
  {id:'moonlight',name:'Moonlight',description:'Night blue and misty silver',colors:['#172630','#accad8','#eef3f3']},
  {id:'rose',name:'Rose clay',description:'Terracotta and candlelit cream',colors:['#302322','#e5b7a2','#faf0e9']},
] as const;
export type Palette=typeof PALETTES[number]['id'];
export type MuseumSettings={recipient:string;greeting:string;message:string;signature:string;palette:Palette};
export const isPalette=(value:unknown):value is Palette=>PALETTES.some(item=>item.id===value);
export const settingsDefaults:MuseumSettings = {
  recipient: 'Manika',
  greeting: 'Happy birthday, my love.',
  message: 'Manika, some feelings become words, some become drawings, and some become the memories we keep forever. This little museum is for all of them.\n\nFor the worlds you draw, the things I try to capture on paper, and the love we make together, one ordinary, beautiful day at a time. Your art lets me see the world through your eyes. Loving you has made my own world more beautiful.\n\nMay every room remind you how deeply you are loved. Here is to more drawings, more adventures, and a lifetime of memories still waiting to become our art.',
  signature: 'With all my love, Sadun',
  palette: 'candlelight',
};
export function validateSettingsPatch(data:Record<string,unknown>,current:MuseumSettings){
  const value={...settingsDefaults,...current};
  for(const key of ['recipient','greeting','message','signature'] as const){
    if(!(key in data))continue;
    if(typeof data[key]!=='string'||data[key].length>(key==='message'?1500:150))throw new Error('Please use a shorter '+key+'.');
    value[key]=data[key].trim();
  }
  if('palette' in data){if(!isPalette(data.palette))throw new Error('Choose one of the museum colour themes.');value.palette=data.palette;}
  if(!value.greeting)throw new Error('Add a birthday greeting.');
  return value;
}
