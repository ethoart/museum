import { requireAdmin } from './auth';
import { readJson } from './request-body';
import { assetId,config,deleteAsset,failure,getExhibits,HttpError,saveExhibit,supabase } from './storage';
import { validateExhibit,type Exhibit } from './exhibition';
import { checkUploadSize,glbJsonLength,imageMime,MAX_UPLOAD_BYTES,validateModelJson } from './upload-limits';

type Pending={id:string;exhibit_id:string;metadata:Omit<Exhibit,'id'|'url'>;previous_url:string|null;expected_size:number;original_size:number;mime:string;expires_at:string};
const pendingPath='/rest/v1/museum_uploads';
async function forget(id:string){await supabase(`${pendingPath}?id=eq.${id}`,{method:'DELETE'});}
async function cleanupExpired(){
  const expired=await(await supabase(`${pendingPath}?expires_at=lt.${encodeURIComponent(new Date(Date.now()-3600000).toISOString())}&select=id&limit=20`)).json() as {id:string}[];
  if(!expired.length)return;
  const live=new Set((await getExhibits()).map(assetId));
  for(const {id} of expired){if(!live.has(id))await deleteAsset(id);await forget(id);}
}
export async function prepare(req:Request){
  const denied=await requireAdmin(req);if(denied)return denied;
  try{
    const input=await readJson(req),metadata=validateExhibit(input),size=Number(input.bytes),original=Number(input.originalBytes);
    checkUploadSize(size);checkUploadSize(original);
    const mime=String(input.mime),allowed=metadata.kind==='model'?['model/gltf-binary']:['image/jpeg','image/png','image/webp'];
    if(!allowed.includes(mime))throw new HttpError('This file type cannot be displayed.');
    const all=await getExhibits(),replaceId=typeof input.replaceId==='string'?input.replaceId:'',old=replaceId?all.find(item=>item.id===replaceId):undefined;
    if(replaceId&&!old)throw new HttpError('The exhibit was removed. Refresh your collection.',404);
    if(old&&old.kind!==metadata.kind)throw new HttpError('Keep the same type when replacing an exhibit.');
    if(all.some(item=>item.id!==old?.id&&item.slot===metadata.slot))throw new HttpError('That position is occupied. Choose another.',409);
    const bucket=await(await supabase('/storage/v1/bucket/museum-art')).json() as {file_size_limit?:number|null};
    const limit=Math.min(MAX_UPLOAD_BYTES,Number(config().SUPABASE_MAX_FILE_BYTES)||MAX_UPLOAD_BYTES,bucket.file_size_limit||MAX_UPLOAD_BYTES);
    if(size>limit)throw new HttpError(`The optimized file exceeds this Supabase project's ${Math.floor(limit/1024/1024)} MB storage limit. Use a smaller model or increase the project's storage limit.`,413);
    await cleanupExpired();
    const id=crypto.randomUUID(),pending:Pending={id,exhibit_id:old?.id??id,metadata,previous_url:old?.url??null,expected_size:size,original_size:original,mime,expires_at:new Date(Date.now()+2*3600000).toISOString()};
    await supabase(pendingPath,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(pending)});
    try{
      const signed=await(await supabase('/storage/v1/object/upload/sign/museum-art/'+id,{method:'POST',headers:{'Content-Type':'application/json'},body:'{}'})).json() as {url?:string;token?:string};
      const base=new URL(config().SUPABASE_URL!),token=signed.token||(signed.url?new URL(signed.url,base).searchParams.get('token'):null);
      if(!token)throw new HttpError('Could not prepare this upload. Try again.',503);
      if(base.hostname.endsWith('.supabase.co')&&!base.hostname.endsWith('.storage.supabase.co'))base.hostname=base.hostname.replace('.supabase.co','.storage.supabase.co');
      return Response.json({uploadId:id,token,endpoint:base.origin+'/storage/v1/upload/resumable',bucket:'museum-art',objectName:id},{headers:{'Cache-Control':'no-store'}});
    }catch(error){await forget(id).catch(()=>{});throw error;}
  }catch(error){return failure(error);}
}
// Read only bounded headers/JSON. A 100 MB upload never enters Worker memory.
async function prefix(id:string,length:number){
  const response=await supabase('/storage/v1/object/authenticated/museum-art/'+id,{headers:{Range:`bytes=0-${length-1}`}});
  const total=Number(response.headers.get('content-range')?.split('/')[1]||response.headers.get('content-length'));
  const reader=response.body?.getReader();if(!reader)throw new HttpError('The uploaded file is empty.');
  const chunks:Uint8Array[]=[];let count=0;
  try{while(count<length){const {done,value}=await reader.read();if(done)break;const part=value.subarray(0,length-count);chunks.push(part);count+=part.byteLength;}}
  finally{await reader.cancel();reader.releaseLock();}
  const bytes=new Uint8Array(count);let offset=0;for(const chunk of chunks){bytes.set(chunk,offset);offset+=chunk.length;}
  return {bytes,total};
}
async function verify(pending:Pending){
  const header=await prefix(pending.id,32);
  if(header.total!==pending.expected_size)throw new HttpError('The upload is incomplete or has the wrong size. Try again.');
  if(pending.metadata.kind==='image'){
    if(imageMime(header.bytes)!==pending.mime)throw new HttpError('The uploaded image has an unexpected format.');
  }else{
    const length=glbJsonLength(header.bytes,header.total),json=await prefix(pending.id,20+length);
    if(json.bytes.length!==20+length)throw new HttpError('The model metadata is incomplete.');
    validateModelJson(JSON.parse(new TextDecoder().decode(json.bytes.subarray(20))));
  }
}
export async function complete(req:Request,id:string){
  const denied=await requireAdmin(req);if(denied)return denied;
  try{
    const all=await getExhibits(),url='/api/assets/'+id,existing=all.find(item=>item.url===url);
    if(existing)return Response.json({exhibit:existing});
    const rows=await(await supabase(`${pendingPath}?id=eq.${id}&select=*`)).json() as Pending[],pending=rows[0];
    if(!pending)throw new HttpError('This upload was not found. Try uploading again.',404);
    if(Date.parse(pending.expires_at)<Date.now())throw new HttpError('This upload expired. Start it again.',410);
    const old=pending.previous_url?all.find(item=>item.id===pending.exhibit_id):undefined;
    if(pending.previous_url&&(!old||old.url!==pending.previous_url))throw new HttpError('This exhibit changed during the upload. Refresh and try again.',409);
    if(all.some(item=>item.id!==pending.exhibit_id&&item.slot===pending.metadata.slot))throw new HttpError('That display position was filled during the upload. Choose another.',409);
    await verify(pending);
    const exhibit:Exhibit={...validateExhibit(pending.metadata),id:pending.exhibit_id,url,originalBytes:pending.original_size,storedBytes:pending.expected_size};
    await saveExhibit(exhibit);
    if(old){const previous=assetId(old);if(previous)await deleteAsset(previous).catch(()=>console.error('Previous exhibit asset needs cleanup'));}
    await forget(id).catch(()=>console.error('Completed upload record needs cleanup'));
    return Response.json({exhibit},{status:pending.previous_url?200:201});
  }catch(error){return failure(error);}
}
export async function cancel(req:Request,id:string){
  const denied=await requireAdmin(req);if(denied)return denied;
  try{
    if((await getExhibits()).some(item=>assetId(item)===id))return Response.json({ok:true});
    const rows=await(await supabase(`${pendingPath}?id=eq.${id}&select=id`)).json() as {id:string}[];
    if(rows.length){await deleteAsset(id);await forget(id);}
    return Response.json({ok:true});
  }catch(error){return failure(error);}
}
