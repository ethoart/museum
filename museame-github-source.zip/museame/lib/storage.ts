import { env } from 'cloudflare:workers';
import { SEED, type Exhibit } from './exhibition';
import { settingsDefaults, type MuseumSettings } from './settings';
export function config() { return env as unknown as Record<string, string | undefined>; }
export function storageConfigured() { return !!(config().SUPABASE_URL && config().SUPABASE_SECRET_KEY); }
export class HttpError extends Error { constructor(message:string,public status=400){super(message);} }
export async function supabase(path:string,init:RequestInit={}) {
  const { SUPABASE_URL, SUPABASE_SECRET_KEY }=config();
  if(!SUPABASE_URL||!SUPABASE_SECRET_KEY)throw new HttpError('Connect Supabase to save your collection.',503);
  const url=new URL(SUPABASE_URL);
  if(url.protocol!=='https:' && config().LOCAL_PREVIEW!=='true')throw new HttpError('Invalid storage configuration.',503);
  const headers=new Headers(init.headers);headers.set('apikey',SUPABASE_SECRET_KEY);
  // New secret keys use apikey; the legacy service-role JWT also needs Bearer auth.
  if(!SUPABASE_SECRET_KEY.startsWith('sb_secret_'))headers.set('Authorization','Bearer '+SUPABASE_SECRET_KEY);
  const response=await fetch(url.origin+path,{...init,headers,signal:AbortSignal.timeout(30000)});
  if(!response.ok){
    const data=await response.json().catch(()=>({})) as {code?:string};
    if(data.code==='23505')throw new HttpError('That display position is occupied. Refresh and choose another.',409);
    console.error('Supabase request failed',path.split('?')[0],response.status,data.code||'');
    throw new HttpError('Supabase could not complete this request. Check the connection and try again.',503);
  }
  return response;
}
export async function getExhibits():Promise<Exhibit[]> {
  if(!storageConfigured())return SEED;
  const rows=await (await supabase('/rest/v1/museum_exhibits?select=exhibit&deleted=eq.false&order=id')).json() as {exhibit:Exhibit}[];
  return rows.map(r=>r.exhibit);
}
export async function saveExhibit(exhibit:Exhibit,deleted=false){
  await supabase('/rest/v1/museum_exhibits?on_conflict=id',{method:'POST',headers:{'Content-Type':'application/json',Prefer:'resolution=merge-duplicates,return=minimal'},body:JSON.stringify({id:exhibit.id,exhibit,deleted})});
}
export async function uploadAsset(id:string,bytes:ArrayBuffer,mime:string){
  await supabase('/storage/v1/object/museum-art/'+id,{method:'POST',headers:{'Content-Type':mime,'x-upsert':'false'},body:bytes});
}
export async function deleteAsset(id:string){
  await supabase('/storage/v1/object/museum-art',{method:'DELETE',headers:{'Content-Type':'application/json'},body:JSON.stringify({prefixes:[id]})});
}
export function assetId(item:Exhibit){return item.url.match(/^\/api\/assets\/([a-z0-9-]{1,80})$/)?.[1];}
export async function getSettings():Promise<MuseumSettings>{
  if(!storageConfigured())return settingsDefaults;
  const rows=await(await supabase('/rest/v1/museum_settings?id=eq.birthday&select=value')).json() as {value:MuseumSettings}[];
  return {...settingsDefaults,...rows[0]?.value};
}
export function writeAllowed(req:Request) {
  const origin=req.headers.get('origin');
  return req.headers.get('sec-fetch-site')!=='cross-site' && !!origin && origin===new URL(req.url).origin;
}
export function failure(error:unknown,status?:number) { return Response.json({error:error instanceof Error?error.message:'Something went wrong. Please try again.'},{status:status||(error instanceof HttpError?error.status:400),headers:{'Cache-Control':'no-store'}}); }
