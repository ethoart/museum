import { WebIO,Logger } from '@gltf-transform/core';
import { ALL_EXTENSIONS,EXTTextureWebP } from '@gltf-transform/extensions';
import { dedup,prune,meshopt,listTextureSlots } from '@gltf-transform/functions';
import { MeshoptEncoder } from 'meshoptimizer/encoder';
import { MeshoptDecoder } from 'meshoptimizer/decoder';
import { checkUploadSize,glbJsonLength,imageMime,validateModelJson } from './upload-limits';

type Progress=(message:string)=>void;
async function compactImage(blob:Blob,mime:string,maxSide=2048,quality=.88){
  const bitmap=await createImageBitmap(blob);
  try{
    if(bitmap.width>16000||bitmap.height>16000||bitmap.width*bitmap.height>64000000)throw new Error('Use images up to 64 megapixels and 16,000 pixels per side.');
    const scale=Math.min(1,maxSide/Math.max(bitmap.width,bitmap.height));
    const canvas=new OffscreenCanvas(Math.max(1,Math.round(bitmap.width*scale)),Math.max(1,Math.round(bitmap.height*scale)));
    const context=canvas.getContext('2d');if(!context)throw new Error('Image processing is unavailable in this browser.');
    context.drawImage(bitmap,0,0,canvas.width,canvas.height);
    const result=await canvas.convertToBlob({type:mime,quality});
    return scale===1&&result.size>=blob.size?blob:result;
  }finally{bitmap.close();}
}
export async function optimizeUpload(file:File,kind:'image'|'model',progress:Progress=()=>{}){
  checkUploadSize(file.size);
  if(kind==='image'){
    progress('Preparing a lighter image…');
    const mime=imageMime(new Uint8Array(await file.slice(0,32).arrayBuffer()));
    const original=new Blob([file],{type:mime}),result=await compactImage(original,'image/webp');
    return new File([result],result.type==='image/webp'?'artwork.webp':file.name,{type:result.type});
  }
  progress('Reading your 3D model…');
  const bytes=new Uint8Array(await file.arrayBuffer()),length=glbJsonLength(bytes,file.size);
  const json=JSON.parse(new TextDecoder().decode(bytes.subarray(20,20+length)));validateModelJson(json);
  const supported=new Set(ALL_EXTENSIONS.map(extension=>extension.EXTENSION_NAME));
  const unknown=(json.extensionsUsed||[]).filter((name:string)=>!supported.has(name));
  if(unknown.length)throw new Error('This model uses unsupported features: '+unknown.join(', ')+'. Export a standard GLB.');
  await Promise.all([MeshoptEncoder.ready,MeshoptDecoder.ready]);
  const io=new WebIO().registerExtensions(ALL_EXTENSIONS).registerDependencies({'meshopt.encoder':MeshoptEncoder,'meshopt.decoder':MeshoptDecoder});
  const document=await io.readBinary(bytes);document.setLogger(new Logger(Logger.Verbosity.SILENT));
  progress('Removing duplicate model data…');await document.transform(dedup(),prune());
  const textures=document.getRoot().listTextures();
  // Process textures one at a time to keep memory bounded for large source files.
  for(let i=0;i<textures.length;i++){
    const texture=textures[i],image=texture.getImage();if(!image)continue;
    const type=texture.getMimeType();if(!['image/png','image/jpeg','image/webp'].includes(type))throw new Error('Use PNG, JPG, or WebP textures inside the model.');
    progress(`Optimizing model texture ${i+1} of ${textures.length}…`);
    const slots=listTextureSlots(texture),isColor=slots.length>0&&slots.every(slot=>['baseColorTexture','emissiveTexture'].includes(slot));
    // Normal/roughness/metalness maps keep lossless channels; color maps use WebP.
    const result=await compactImage(new Blob([image as Uint8Array<ArrayBuffer>],{type}),isColor?'image/webp':'image/png',2048,isColor?.88:1);
    texture.setImage(new Uint8Array(await result.arrayBuffer())).setMimeType(result.type);
  }
  if(textures.some(texture=>texture.getMimeType()==='image/webp'))document.createExtension(EXTTextureWebP).setRequired(true);
  progress('Compressing 3D geometry…');
  await document.transform(meshopt({encoder:MeshoptEncoder,level:'medium',quantizePosition:14,quantizeTexcoord:12,quantizeNormal:10}));
  const result=await io.writeBinary(document);
  // Small or already optimized assets should never become larger unnecessarily.
  return result.byteLength<file.size?new File([result],'model.glb',{type:'model/gltf-binary'}):new File([file],file.name,{type:'model/gltf-binary'});
}
