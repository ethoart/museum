import * as T from 'three';
import type { MuseumWorld } from './museum-world';
import type { gardenTextures } from './garden-textures';

type Textures=ReturnType<typeof gardenTextures>;

export function buildMuseumScenery(world:MuseumWorld,textures:Textures,random:()=>number,loadSky:boolean){
  const {scene}=world,clock={value:0};
  const skyMaterial=new T.MeshBasicMaterial({color:'#263e56',side:T.BackSide,depthWrite:false,fog:false,toneMapped:false});
  skyMaterial.onBeforeCompile=shader=>{
    shader.uniforms.uMuseumTime=clock;
    shader.uniforms.uHorizon={value:new T.Color('#69818c')};
    shader.vertexShader='varying float vSkyHeight;\n'+shader.vertexShader.replace('#include <begin_vertex>','#include <begin_vertex>\nvSkyHeight=normalize(position).y;');
    shader.fragmentShader='uniform float uMuseumTime; uniform vec3 uHorizon; varying float vSkyHeight;\n'+shader.fragmentShader.replace('#include <map_fragment>',`
      #ifdef USE_MAP
        vec2 paintedUv=vMapUv;
        float dome=sin(paintedUv.y*3.14159265);
        paintedUv.x+=dome*.010*sin(paintedUv.y*18.85+uMuseumTime*.22);
        paintedUv.y+=dome*.006*sin(paintedUv.x*25.13-uMuseumTime*.16);
        paintedUv=vec2(fract(paintedUv.x),clamp(paintedUv.y,.002,.998));
        vec3 paint=texture2D(map,paintedUv).rgb;
        float seam=min(paintedUv.x,1.-paintedUv.x);
        vec3 joined=(texture2D(map,vec2(seam,paintedUv.y)).rgb+texture2D(map,vec2(1.-seam,paintedUv.y)).rgb)*.5;
        paint=mix(paint,joined,1.-smoothstep(0.,.035,seam));
        float stars=smoothstep(.28,.75,dot(paint,vec3(.2126,.7152,.0722)));
        paint*=.88+stars*.09*sin(uMuseumTime*.8+paintedUv.x*47.+paintedUv.y*19.);
        paint=mix(uHorizon,paint,smoothstep(-.08,.29,vSkyHeight));
        diffuseColor.rgb*=paint;
      #endif
    `);
  };
  skyMaterial.customProgramCacheKey=()=> 'museum-painted-sky-v2';
  const sky=new T.Mesh(new T.SphereGeometry(145,64,32),skyMaterial);
  sky.name='painted-night-sky';sky.rotation.y=.65;sky.raycast=()=>{};sky.userData.keepSeparate=true;sky.userData.animationClock=clock;scene.add(sky);

  const waterMaterial=new T.MeshStandardMaterial({color:'#51777f',roughness:.27,metalness:.42,envMapIntensity:.7});
  waterMaterial.onBeforeCompile=shader=>{
    shader.uniforms.uMuseumTime=clock;
    shader.vertexShader='varying vec2 vMuseumWater;\n'+shader.vertexShader.replace('#include <begin_vertex>','#include <begin_vertex>\nvMuseumWater=position.xy;');
    shader.fragmentShader='uniform float uMuseumTime; varying vec2 vMuseumWater;\n'+shader.fragmentShader.replace('#include <normal_fragment_begin>',`#include <normal_fragment_begin>
      normal=normalize(normal+vec3(.025*sin(vMuseumWater.x*3.2+vMuseumWater.y*.6+uMuseumTime*.42),.018*cos(vMuseumWater.y*2.7-uMuseumTime*.33),0.));`);
  };
  waterMaterial.customProgramCacheKey=()=> 'museum-water-v1';
  if(loadSky){
    const texture=new T.TextureLoader().load('/textures/starry-night-sky.png',loaded=>{
      if(world.disposed){loaded.dispose();return;}
      skyMaterial.map=loaded;skyMaterial.color.set('#ffffff');skyMaterial.needsUpdate=true;
      waterMaterial.envMap=loaded;waterMaterial.needsUpdate=true;
    });
    texture.colorSpace=T.SRGBColorSpace;texture.wrapS=T.RepeatWrapping;texture.mapping=T.EquirectangularReflectionMapping;
    world.cleanups.push(()=>texture.dispose());
  }
  const stone=new T.MeshStandardMaterial({color:'#ded2b9',map:textures.stone,bumpMap:textures.stone,bumpScale:.018,roughness:.86});
  const edge=world.material('#b9af97',.92),brass=world.material('#ac8650',.43,.5),soil=world.material('#4e4d3b',1);
  const bark=new T.MeshStandardMaterial({color:'#8a7860',map:textures.bark,bumpMap:textures.bark,bumpScale:.045,roughness:.96});
  const box=(w:number,h:number,d:number,x:number,y:number,z:number,material:T.Material=stone,parent:T.Object3D=scene)=>world.box(w,h,d,x,y,z,material,parent);
  function mesh(geometry:T.BufferGeometry,material:T.Material,x:number,y:number,z:number,parent:T.Object3D=scene){const object=new T.Mesh(geometry,material);object.position.set(x,y,z);object.castShadow=true;object.receiveShadow=true;parent.add(object);return object;}
  function water(w:number,d:number,x:number,y:number,z:number){const pool=mesh(new T.PlaneGeometry(w,d),waterMaterial,x,y,z);pool.rotation.x=-Math.PI/2;pool.castShadow=false;pool.userData.keepSeparate=true;pool.name='reflecting-water';return pool;}

  // A continuous landform, with a calm valley and smooth ridges behind the garden.
  const heightAt=(x:number,z:number)=>{
    const radius=Math.hypot(x,z),blend=T.MathUtils.smoothstep(radius,30,53);
    const ridge=(cx:number,cz:number,w:number,h:number)=>h*Math.exp(-((x-cx)**2+(z-cz)**2)/(w*w));
    return -.72+blend*(.65+1.35*Math.sin(x*.05)*Math.cos(z*.065)+ridge(-60,-61,27,13)+ridge(54,-80,30,17)+ridge(-58,61,28,11)+ridge(63,52,25,15));
  };
  const terrain=new T.PlaneGeometry(220,220,100,100);terrain.rotateX(-Math.PI/2);
  const position=terrain.attributes.position,colors=new Float32Array(position.count*3);
  const lower=new T.Color('#677a68'),upper=new T.Color('#536c78'),patch=new T.Color();
  for(let i=0;i<position.count;i++){
    const x=position.getX(i),z=position.getZ(i),h=heightAt(x,z);position.setY(i,h);
    patch.copy(lower).lerp(upper,T.MathUtils.clamp(h/16,0,1)).multiplyScalar(.94+.07*Math.sin(x*.8)*Math.sin(z*.55));patch.toArray(colors,i*3);
  }
  terrain.setAttribute('color',new T.BufferAttribute(colors,3));terrain.computeVertexNormals();
  const land=mesh(terrain,new T.MeshStandardMaterial({vertexColors:true,roughness:1}),0,0,0);land.castShadow=false;
  water(90,46,0,-.67,-73);
  // Three broad steps ground the museum in a continuous garden terrace.
  box(52,.22,40,0,-.49,0);box(41.8,.1,29.8,0,-.28,0,edge);box(39.7,.1,27.7,0,-.18,0);box(37.6,.1,25.6,0,-.08,0,edge);
  const paving=textures.floor.clone();paving.repeat.set(26,20);paving.needsUpdate=true;
  const terrace=mesh(new T.PlaneGeometry(51.8,39.8),new T.MeshStandardMaterial({map:paving,bumpMap:paving,bumpScale:.015,roughness:.83}),0,-.375,0);terrace.rotation.x=-Math.PI/2;terrace.castShadow=false;
  // Pools and inset planting beds are visible through the two end arcades.
  for(const z of[-16.8,16.8])for(const x of[-5.25,5.25]){
    box(3.9,.14,4.7,x,-.29,z,edge);box(3.55,.1,4.35,x,-.21,z,soil);
    water(3.4,4.2,x,-.15,z);
    for(const side of[-1,1]){box(.16,.15,4.65,x+side*1.88,-.16,z);box(3.9,.15,.16,x,-.16,z+side*2.26);}
  }
  // Low classical rails give open windows a deliberate edge, without hiding the view.
  for(const z of[-12.12,12.12])for(const x of[-5.25,5.25]){
    box(3.15,.13,.28,x,.1,z);box(3.22,.12,.32,x,.91,z);
    for(let i=-3;i<=3;i++){
      const bx=x+i*.44;
      mesh(new T.LatheGeometry([new T.Vector2(.085,0),new T.Vector2(.065,.08),new T.Vector2(.035,.23),new T.Vector2(.075,.36),new T.Vector2(.05,.55),new T.Vector2(.08,.68)],12),stone,bx,.17,z);
    }
  }
  // Olive leaves use individual folded blades; branching stays visible through the crown.
  const blade=new T.BufferGeometry();
  blade.setAttribute('position',new T.Float32BufferAttribute([0,-1,0,-.3,-.3,0,-.24,.45,0,0,1,0,.24,.45,0,.3,-.3,0,0,0,.1],3));
  blade.setIndex([0,1,6,1,2,6,2,3,6,3,4,6,4,5,6,5,0,6]);blade.computeVertexNormals();
  const leafMatrices:T.Matrix4[]=[],leafColors:T.Color[]=[],dummy=new T.Object3D();
  const palette=['#586e4d','#7e8e69','#9ca880','#637f64'].map(color=>new T.Color(color));
  function leaf(p:T.Vector3,scale:number,direction:number){
    dummy.position.copy(p);dummy.rotation.set((random()-.5)*2,direction,(random()-.5)*2.4);dummy.scale.set(.075*scale,.19*scale,.11*scale);dummy.updateMatrix();leafMatrices.push(dummy.matrix.clone());leafColors.push(palette[Math.floor(random()*palette.length)]);
  }
  function branch(points:T.Vector3[],radius:number,parent:T.Object3D){
    const curve=new T.CatmullRomCurve3(points),geometry=new T.TubeGeometry(curve,14,radius,7,false),attribute=geometry.attributes.position,p=new T.Vector3();
    for(let ring=0;ring<=14;ring++){
      const center=curve.getPointAt(ring/14),taper=1-ring/14*.86;
      for(let side=0;side<=7;side++){const index=ring*8+side;p.fromBufferAttribute(attribute,index).sub(center).multiplyScalar(taper).add(center);attribute.setXYZ(index,p.x,p.y,p.z);}
    }
    geometry.computeVertexNormals();mesh(geometry,bark,0,0,0,parent);
  }
  function plantOlive(x:number,z:number,scale:number,planter=true){
    const group=new T.Group();group.position.set(x,planter?0:-.37,z);group.scale.setScalar(scale);scene.add(group);group.updateMatrixWorld(true);
    if(planter){
      const urn=new T.LatheGeometry([new T.Vector2(.3,0),new T.Vector2(.34,.08),new T.Vector2(.32,.15),new T.Vector2(.47,.22),new T.Vector2(.6,.58),new T.Vector2(.57,.72),new T.Vector2(.64,.74),new T.Vector2(.64,.83),new T.Vector2(.51,.83)],28);
      mesh(urn,stone,0,0,0,group);mesh(new T.CylinderGeometry(.53,.53,.04,24),soil,0,.78,0,group);
      for(const y of[.14,.7]){const band=mesh(new T.TorusGeometry(y===.14?.33:.595,.018,5,28),brass,0,y,0,group);band.rotation.x=Math.PI/2;}
      world.obstacles.push({x,z,w:1.28*scale,d:1.28*scale});world.contactShadow(x,z,2.1*scale,2.1*scale,scene);
    }
    const start=planter?.76:0;
    branch([new T.Vector3(0,start,0),new T.Vector3(.12,1.25,0),new T.Vector3(-.09,2.1,.04),new T.Vector3(.13,3.65,-.06)],.14,group);
    for(let i=0;i<8;i++){
      const angle=i*2.39996,r=.68+random()*.44,tip=new T.Vector3(Math.cos(angle)*r,2.7+random()*1.15,Math.sin(angle)*r);
      const base=new T.Vector3(0,1.45+i*.12,0);branch([base,new T.Vector3(tip.x*.4,2.65,tip.z*.4),tip],.047,group);
      for(let twig=0;twig<5;twig++){
        const a=angle+(twig-2)*.65,root=tip.clone().multiplyScalar(.72);root.y=tip.y-.25;
        const end=tip.clone().add(new T.Vector3(Math.cos(a)*.48,.12+random()*.23,Math.sin(a)*.48));branch([root,tip,end],.016,group);
        for(let j=0;j<10;j++)for(const side of[-1,1]){
          const p=tip.clone().lerp(end,j/10).add(new T.Vector3(Math.cos(a+Math.PI/2)*side*(.08+random()*.12),(random()-.5)*.14,Math.sin(a+Math.PI/2)*side*(.08+random()*.12)));
          leaf(group.localToWorld(p),scale*(.85+random()*.3),a+side*.65);
        }
      }
    }
  }
  // Varied silhouettes frame the views instead of a ring of identical tree blobs.
  for(const z of[-17.5,17.5])for(const x of[-11,11]){box(3.4,.25,3.4,x,-.28,z,edge);box(3.15,.03,3.15,x,-.135,z,soil);plantOlive(x,z,1.05,false);}
  for(const x of[-23.5,23.5])for(const z of[-12,0,12])plantOlive(x,z,.88+random()*.2,false);
  const cypressMaterial=world.material('#405f50',.97);
  for(const x of[-17,-9,9,17])for(const z of[-24,24]){
    const group=new T.Group();group.position.set(x,heightAt(x,z),z);group.scale.setScalar(.82+random()*.28);scene.add(group);
    mesh(new T.CylinderGeometry(.07,.13,1.7,9),bark,0,.75,0,group);
    const profile=[new T.Vector2(0,.6),new T.Vector2(.45,.75),new T.Vector2(.72,1.5),new T.Vector2(.61,2.7),new T.Vector2(.4,4.1),new T.Vector2(.15,5.2),new T.Vector2(0,5.9)];
    const canopy=new T.LatheGeometry(profile,18),v=canopy.attributes.position;
    for(let i=0;i<v.count;i++){const ripple=1+.055*Math.sin(v.getY(i)*7+i*1.6);v.setX(i,v.getX(i)*ripple);v.setZ(i,v.getZ(i)*ripple);}canopy.computeVertexNormals();mesh(canopy,cypressMaterial,0,0,0,group);
  }
  // Carved lanterns and planted borders finish the garden perimeter.
  const lanternGlow=new T.MeshStandardMaterial({color:'#fff0cf',emissive:'#ffdaa0',emissiveIntensity:1.1,roughness:.5});
  const shrub=world.material('#526b51',1),flower=world.material('#d8cfa9',.95);
  for(const x of[-24,24])for(const z of[-17,-7,7,17]){
    box(.54,.16,.54,x,-.23,z);box(.36,.43,.36,x,.065,z,edge);box(.29,.27,.29,x,.4,z,lanternGlow);box(.49,.08,.49,x,.58,z,brass);
  }
  for(const side of[-1,1])for(let i=0;i<21;i++){
    const x=-23+i*2.3,z=side*19.1;
    const bush=mesh(new T.SphereGeometry(1,8,6),shrub,x,-.16,z);bush.scale.set(.75,.42,.48);
    if(i%2===0)for(let j=0;j<5;j++){const p=mesh(new T.IcosahedronGeometry(.065,0),flower,x+(random()-.5)*.8,.16+random()*.1,z+(random()-.5)*.45);p.castShadow=false;}
  }
  return {
    sky,plantOlive,
    finishPlants(){const foliage=new T.InstancedMesh(blade,new T.MeshStandardMaterial({roughness:.85,side:T.DoubleSide}),leafMatrices.length);foliage.name='olive-leaves';leafMatrices.forEach((matrix,i)=>{foliage.setMatrixAt(i,matrix);foliage.setColorAt(i,leafColors[i]);});foliage.castShadow=true;foliage.receiveShadow=true;scene.add(foliage);},
    update(time:number){clock.value=time;sky.rotation.y=.65+time*.004;},
  };
}
