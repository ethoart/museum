import type { Exhibit } from './exhibition';
import { checkUploadSize } from './upload-limits';
type Progress=(message:string)=>void;
export const formatFileSize=(size:number)=>size>=1024*1024?(size/1024/1024).toFixed(1)+' MB':Math.max(1,Math.round(size/1024))+' KB';
async function request<T=unknown>(url:string,method:string,body?:unknown):Promise<T>{
  const response=await fetch(url,{method,headers:{'Content-Type':'application/json'},body:body?JSON.stringify(body):undefined});
  const data=await response.json() as {error?:string};if(!response.ok)throw new Error(data.error||'The upload could not finish. Try again.');return data as T;
}
function optimize(file:File,kind:'image'|'model',onProgress:Progress,signal:AbortSignal){
  return new Promise<File>((resolve,reject)=>{
    const worker=new Worker('/assets/optimizer.js',{type:'module'});
    const dispose=()=>{worker.terminate();signal.removeEventListener('abort',abort);};
    const abort=()=>{dispose();reject(new Error('Upload cancelled.'));};
    signal.addEventListener('abort',abort,{once:true});
    worker.onmessage=({data})=>{if(data.message)onProgress(data.message);if(data.error){dispose();reject(new Error(data.error));}if(data.file){dispose();resolve(data.file);}};
    worker.onerror=()=>{dispose();reject(new Error('The optimizer could not start. Refresh the page and try again.'));};
    if(signal.aborted){abort();return;}worker.postMessage({file,kind});
  });
}
export async function uploadExhibit(file:File,draft:Omit<Exhibit,'id'|'url'>,replaceId:string|undefined,onProgress:Progress,signal:AbortSignal){
  checkUploadSize(file.size);const optimized=await optimize(file,draft.kind,onProgress,signal);
  const summary=`${formatFileSize(file.size)} → ${formatFileSize(optimized.size)}`;
  onProgress(`Ready to upload · ${summary}`);
  const ticket=await request<{endpoint:string;token:string;bucket:string;objectName:string;uploadId:string}>('/api/uploads','POST',{...draft,replaceId,bytes:optimized.size,originalBytes:file.size,mime:optimized.type});
  try{
    const {Upload}=await import('tus-js-client');
    await new Promise<void>((resolve,reject)=>{
      const upload=new Upload(optimized,{endpoint:ticket.endpoint,headers:{'x-signature':ticket.token},metadata:{bucketName:ticket.bucket,objectName:ticket.objectName,contentType:optimized.type,cacheControl:'86400'},chunkSize:6*1024*1024,uploadDataDuringCreation:true,removeFingerprintOnSuccess:true,storeFingerprintForResuming:false,retryDelays:[0,1000,3000,5000,10000],
        onProgress:(sent,total)=>onProgress(`Uploading ${Math.round(sent/total*100)}% · ${summary}`),
        onError:()=>{signal.removeEventListener('abort',abort);reject(new Error('Upload interrupted. Please try again.'));},
        onSuccess:()=>{signal.removeEventListener('abort',abort);resolve();}});
      const abort=()=>{void upload.abort().finally(()=>reject(new Error('Upload cancelled.')));};
      signal.addEventListener('abort',abort,{once:true});if(signal.aborted){abort();return;}upload.start();
    });
    if(signal.aborted)throw new Error('Upload cancelled.');
    onProgress('Adding it to your museum…');
    const data=await request<{exhibit:Exhibit}>('/api/uploads/'+ticket.uploadId,'POST');return {exhibit:data.exhibit,summary};
  }catch(error){await request('/api/uploads/'+ticket.uploadId,'DELETE').catch(()=>{});throw error;}
}
