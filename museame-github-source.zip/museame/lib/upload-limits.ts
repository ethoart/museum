export const MAX_UPLOAD_BYTES=100*1024*1024;
export const MAX_GLB_JSON_BYTES=4*1024*1024;
export function checkUploadSize(size:number){
  if(!Number.isSafeInteger(size)||size<=0||size>MAX_UPLOAD_BYTES)throw new Error('Choose a file up to 100 MB.');
}
export function imageMime(bytes:Uint8Array){
  if(bytes[0]===0x89&&bytes[1]===0x50&&bytes[2]===0x4e&&bytes[3]===0x47)return 'image/png';
  if(bytes[0]===0xff&&bytes[1]===0xd8&&bytes[2]===0xff)return 'image/jpeg';
  if(new TextDecoder().decode(bytes.subarray(0,4))==='RIFF'&&new TextDecoder().decode(bytes.subarray(8,12))==='WEBP')return 'image/webp';
  throw new Error('Use a JPG, PNG, or WebP image.');
}
export function glbJsonLength(bytes:Uint8Array,total:number){
  const view=new DataView(bytes.buffer,bytes.byteOffset,bytes.byteLength);
  if(bytes.byteLength<20||view.getUint32(0,true)!==0x46546c67||view.getUint32(4,true)!==2||view.getUint32(8,true)!==total||view.getUint32(16,true)!==0x4e4f534a)throw new Error('Use a valid GLB 2.0 model.');
  const length=view.getUint32(12,true);
  if(length>total-20||length>MAX_GLB_JSON_BYTES||length%4)throw new Error('The model metadata is incomplete or too large. Export a lighter GLB.');
  return length;
}
export function validateModelJson(gltf:Record<string,any>){
  if(gltf.asset?.version!=='2.0')throw new Error('Use a GLB 2.0 model.');
  if([...(gltf.buffers||[]),...(gltf.images||[])].some(x=>x.uri&&!x.uri.startsWith('data:')))throw new Error('Embed all model textures and buffers inside the GLB file.');
  if((gltf.nodes?.length||0)>2000||(gltf.accessors||[]).reduce((n:number,a:{count?:number})=>n+(a.count||0),0)>4000000)throw new Error('This model is too detailed. Export a lighter version for the web.');
  if((gltf.extensionsRequired||[]).some((x:string)=>['KHR_draco_mesh_compression','KHR_texture_basisu'].includes(x)))throw new Error('Use GLB with embedded PNG, JPG, or WebP textures. Draco and KTX2 files need to be exported without those codecs.');
}
