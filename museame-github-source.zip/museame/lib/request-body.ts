import { HttpError } from './storage';
// Bound streamed requests too; Content-Length is not always present or trustworthy.
async function readBody(req:Request,limit:number){
  if(Number(req.headers.get('content-length'))>limit)throw new HttpError('This request is too large.',413);
  const reader=req.body?.getReader();if(!reader)return new Uint8Array();
  const chunks:Uint8Array[]=[];let length=0;
  try{while(true){const {done,value}=await reader.read();if(done)break;length+=value.byteLength;if(length>limit){await reader.cancel();throw new HttpError('This request is too large.',413);}chunks.push(value);}}
  finally{reader.releaseLock();}
  const result=new Uint8Array(length);let offset=0;for(const chunk of chunks){result.set(chunk,offset);offset+=chunk.length;}return result;
}
export async function readJson(req:Request,limit=10000):Promise<Record<string,unknown>>{
  const value=JSON.parse(new TextDecoder().decode(await readBody(req,limit)));
  if(!value||typeof value!=='object'||Array.isArray(value))throw new HttpError('Invalid request.');return value;
}
export async function readForm(req:Request){
  const body=await readBody(req,32*1024*1024);
  return new Response(body,{headers:{'Content-Type':req.headers.get('content-type')||''}}).formData();
}
