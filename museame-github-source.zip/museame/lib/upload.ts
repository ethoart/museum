import { glbJsonLength,imageMime,validateModelJson } from './upload-limits';
// Compatibility endpoint only. The admin uses direct resumable storage uploads.
export async function readUpload(file:File,kind:'image'|'model'){
  if(!file.size||file.size>30*1024*1024)throw new Error('Use the admin upload form for files up to 100 MB.');
  const bytes=await file.arrayBuffer(),u=new Uint8Array(bytes);
  if(kind==='image')return {bytes,mime:imageMime(u)};
  const length=glbJsonLength(u,file.size);
  validateModelJson(JSON.parse(new TextDecoder().decode(u.subarray(20,20+length))));
  return {bytes,mime:'model/gltf-binary'};
}
