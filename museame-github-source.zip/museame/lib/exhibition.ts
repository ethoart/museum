export type Exhibit = {
  id: string; title: string; artist: string; year: string; kind: 'image' | 'model';
  url: string; slot: string; size: number; rotation: number; frame: 'oak' | 'black' | 'white';
  description?: string; source?: string; builtin?: string;
  originalBytes?:number; storedBytes?:number;
};
export const ROOMS = ['Main hall', 'West gallery', 'East gallery'] as const;
export type Slot = { id: string; label: string; room: string; kind: 'image' | 'model'; x: number; z: number; yaw: number; maxSize?:number };
export const SLOTS: Slot[] = [
  {id:'main-n',label:'Main hall · North wall',room:'Main hall',kind:'image',x:0,z:-11.77,yaw:0},
  {id:'main-nw',label:'Main hall · West arcade, north',room:'Main hall',kind:'image',x:-6.77,z:-10,yaw:Math.PI/2,maxSize:2.8},
  {id:'main-ne',label:'Main hall · East arcade, north',room:'Main hall',kind:'image',x:6.77,z:-10,yaw:-Math.PI/2,maxSize:2.8},
  {id:'main-w',label:'Main hall · West wall',room:'Main hall',kind:'image',x:-6.77,z:0,yaw:Math.PI/2,maxSize:2.8},
  {id:'main-e',label:'Main hall · East wall',room:'Main hall',kind:'image',x:6.77,z:0,yaw:-Math.PI/2,maxSize:2.8},
  {id:'main-sw',label:'Main hall · West arcade, south',room:'Main hall',kind:'image',x:-6.77,z:10,yaw:Math.PI/2,maxSize:2.8},
  {id:'main-se',label:'Main hall · East arcade, south',room:'Main hall',kind:'image',x:6.77,z:10,yaw:-Math.PI/2,maxSize:2.8},
  {id:'main-s',label:'Main hall · Entrance wall',room:'Main hall',kind:'image',x:0,z:11.77,yaw:Math.PI},
  {id:'west-n',label:'West gallery · North',room:'West gallery',kind:'image',x:-12.5,z:-11.77,yaw:0},
  {id:'west-w1',label:'West gallery · Wall 1',room:'West gallery',kind:'image',x:-17.77,z:-6,yaw:Math.PI/2},
  {id:'west-w2',label:'West gallery · Wall 2',room:'West gallery',kind:'image',x:-17.77,z:0,yaw:Math.PI/2},
  {id:'west-w3',label:'West gallery · Wall 3',room:'West gallery',kind:'image',x:-17.77,z:6,yaw:Math.PI/2},
  {id:'west-s',label:'West gallery · South',room:'West gallery',kind:'image',x:-12.5,z:11.77,yaw:Math.PI},
  {id:'east-n',label:'East gallery · North',room:'East gallery',kind:'image',x:12.5,z:-11.77,yaw:0},
  {id:'east-e1',label:'East gallery · Wall 1',room:'East gallery',kind:'image',x:17.77,z:-6,yaw:-Math.PI/2},
  {id:'east-e2',label:'East gallery · Wall 2',room:'East gallery',kind:'image',x:17.77,z:0,yaw:-Math.PI/2},
  {id:'east-e3',label:'East gallery · Wall 3',room:'East gallery',kind:'image',x:17.77,z:6,yaw:-Math.PI/2},
  {id:'east-s',label:'East gallery · South',room:'East gallery',kind:'image',x:12.5,z:11.77,yaw:Math.PI},
  ...([-1,1] as const).flatMap(side=>{
    const wing=side===-1?'west':'east',room=side===-1?'West gallery':'East gallery';
    const inner=[-10,0,10].map((z,i):Slot=>({id:`${wing}-inner${i+1}`,label:`${room} · Inner wall ${i+1}`,room,kind:'image',x:side*7.23,z,yaw:side*Math.PI/2,maxSize:2.8}));
    const outer=[-10,10].map((z,i):Slot=>({id:`${wing}-outer${i+1}`,label:`${room} · Outer wall, ${i===0?'north':'south'}`,room,kind:'image',x:side*17.77,z,yaw:-side*Math.PI/2,maxSize:3}));
    const ends=[-1,1].flatMap(end=>[-1,1].map((offset):Slot=>({id:`${wing}-${end===-1?'north':'south'}-${offset===-1?'left':'right'}`,label:`${room} · ${end===-1?'North':'South'} wall, ${offset===-1?'left':'right'}`,room,kind:'image',x:side*12.5+offset*3.6,z:end*11.77,yaw:end===-1?0:Math.PI,maxSize:2.8})));
    return [...inner,...outer,...ends];
  }),
  {id:'plinth-main',label:'Main hall · Central plinth',room:'Main hall',kind:'model',x:0,z:-2,yaw:0},
  {id:'plinth-west',label:'West gallery · North plinth',room:'West gallery',kind:'model',x:-12.4,z:-3.4,yaw:0},
  {id:'plinth-west2',label:'West gallery · South plinth',room:'West gallery',kind:'model',x:-12.4,z:3.4,yaw:0},
  {id:'plinth-east',label:'East gallery · North plinth',room:'East gallery',kind:'model',x:12.4,z:-3.4,yaw:0},
  {id:'plinth-east2',label:'East gallery · South plinth',room:'East gallery',kind:'model',x:12.4,z:3.4,yaw:0},
];
export const SEED: Exhibit[] = [
  {id:'wheat-field',title:'Wheat Field with Cypresses',artist:'Vincent van Gogh',year:'1889',kind:'image',url:'/art/met-436535.jpg',slot:'main-n',size:3.5,rotation:0,frame:'oak',source:'https://www.metmuseum.org/art/collection/search/436535',description:'Oil on canvas. From the Open Access collection of The Metropolitan Museum of Art.'},
  {id:'irises',title:'Irises',artist:'Vincent van Gogh',year:'1890',kind:'image',url:'/art/met-436528.jpg',slot:'main-w',size:2.8,rotation:0,frame:'oak',source:'https://www.metmuseum.org/art/collection/search/436528'},
  {id:'self-portrait',title:'Self-Portrait with a Straw Hat',artist:'Vincent van Gogh',year:'1887',kind:'image',url:'/art/met-436532.jpg',slot:'main-e',size:2.6,rotation:0,frame:'oak',source:'https://www.metmuseum.org/art/collection/search/436532'},
  {id:'vase-flowers',title:'A Woman Seated beside a Vase of Flowers',artist:'Edgar Degas',year:'1865',kind:'image',url:'/art/met-436121.jpg',slot:'west-n',size:3.2,rotation:0,frame:'black',source:'https://www.metmuseum.org/art/collection/search/436121'},
  {id:'circus-sideshow',title:'Circus Sideshow (Parade de cirque)',artist:'Georges Seurat',year:'1887–88',kind:'image',url:'/art/met-437654.jpg',slot:'east-n',size:3.5,rotation:0,frame:'black',source:'https://www.metmuseum.org/art/collection/search/437654'},
  {id:'infinite-form',title:'Two Hearts, One Home',artist:'Museum of Love',year:'2026',kind:'model',url:'',slot:'plinth-main',size:2.5,rotation:0,frame:'oak',builtin:'knot',description:'Two original intertwined hearts in warm gold. A little reminder that our stories belong together.'},
  {id:'folded-light',title:'Folded Light',artist:'Museum of Love',year:'2026',kind:'model',url:'',slot:'plinth-east',size:2.1,rotation:25,frame:'oak',builtin:'ribbon',description:'An original digital sculpture exploring light and a continuous, folded surface.'},
];
export function validateExhibit(data: Record<string, unknown>): Omit<Exhibit,'id'|'url'> {
  const kind = data.kind;
  if (kind !== 'image' && kind !== 'model') throw new Error('Choose artwork or a 3D model.');
  const slot = SLOTS.find(s=>s.id===data.slot && s.kind===kind);
  if (!slot) throw new Error('Choose a suitable display position.');
  if(typeof data.title!=='string' || !data.title.trim() || data.title.length>100) throw new Error('Add a title of up to 100 characters.');
  const size=Number(data.size), rotation=Number(data.rotation);
  if(!Number.isFinite(size)||size<0.5||size>(slot.maxSize??3.5) || !Number.isFinite(rotation)||rotation<0||rotation>360) throw new Error('Choose a size that fits this display position and a valid rotation.');
  if(!['oak','black','white'].includes(String(data.frame))) throw new Error('Choose a frame.');
  return {title:data.title.trim(),artist:String(data.artist||'Unknown artist').slice(0,100),year:String(data.year||'').slice(0,40),kind,slot:slot.id,size,rotation,frame:data.frame as Exhibit['frame'],description:String(data.description||'').slice(0,2000)};
}
