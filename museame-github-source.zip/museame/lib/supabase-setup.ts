import {authenticated,requireAdmin} from './auth';
import {config,failure,HttpError} from './storage';
import {readJson} from './request-body';

export type LocalSetup={schema:()=>Promise<string>;connect:(input:Record<string,unknown>)=>Promise<Record<string,string>>};
export async function setupSupabase(request:Request,setup:LocalSetup|undefined){
  try{
    if(request.method==='POST'){const denied=await requireAdmin(request);if(denied)return denied;}
    else if(!await authenticated(request))throw new HttpError('Please sign in to the admin page.',401);
    if(!setup||config().LOCAL_PREVIEW!=='true'||!['127.0.0.1','localhost'].includes(new URL(request.url).hostname))throw new HttpError('Use the local museum admin to connect this computer. For a published museum, configure the hosting server secrets.',403);
    if(request.method==='GET')return new Response(await setup.schema(),{headers:{'Content-Type':'application/sql; charset=utf-8','Content-Disposition':'attachment; filename="museum-of-love-setup.sql"','Cache-Control':'no-store'}});
    if(request.method!=='POST')return new Response('Method not allowed',{status:405});
    const values=await setup.connect(await readJson(request,8192));
    Object.assign(config(),values);
    // Existing local sessions are intentionally no longer accepted once the
    // database is connected. Signing in again creates a shared database session.
    return Response.json({connected:true,signInAgain:true},{headers:{'Cache-Control':'no-store'}});
  }catch(error){return failure(error);}
}
