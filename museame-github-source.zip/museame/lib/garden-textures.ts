import * as T from 'three';

// Small, repeatable material maps. Geometry supplies the larger carved details.
export function gardenTextures(random:()=>number){
  function surface(base:string,finish:'stone'|'floor'|'linen'|'bark'){
    const canvas=document.createElement('canvas');canvas.width=canvas.height=512;
    const c=canvas.getContext('2d')!;c.fillStyle=base;c.fillRect(0,0,512,512);
    for(let i=0;i<4200;i++){
      c.fillStyle=`rgba(${i%2?'255,250,231':'108,93,85'},${.018+random()*.075})`;
      const x=random()*512,y=random()*512;
      c.fillRect(x,y,finish==='linen'?1:1+random()*8,1+random()*2);
    }
    if(finish==='bark'){
      for(let x=0;x<512;x+=3){c.strokeStyle=`rgba(55,43,30,${.05+random()*.2})`;c.lineWidth=.5+random()*2;c.beginPath();c.moveTo(x,0);for(let y=0;y<=512;y+=16)c.lineTo(x+Math.sin(y*.03+x)*3,y);c.stroke();}
    }else if(finish==='linen'){
      for(let i=0;i<512;i+=4){c.fillStyle='rgba(255,255,255,.1)';c.fillRect(i,0,1,512);c.fillStyle='rgba(55,40,67,.09)';c.fillRect(0,i,512,1);}
    }else{
      for(let j=0;j<30;j++){
        const start=random()*512;c.beginPath();c.moveTo(0,start);
        for(let x=0;x<=512;x+=16)c.lineTo(x,start+Math.sin(x*.018+j)*6+Math.sin(x*.04+j*2)*2);
        c.strokeStyle=`rgba(123,107,93,${finish==='floor'?.09:.045})`;c.lineWidth=.5+random()*1.8;c.stroke();
      }
      if(finish==='floor'){
        c.strokeStyle='#aa9b90';c.lineWidth=3;c.strokeRect(1,1,510,510);
        c.strokeStyle='rgba(255,250,237,.55)';c.lineWidth=2;c.strokeRect(4,4,504,504);
      }
    }
    const texture=new T.CanvasTexture(canvas);texture.colorSpace=T.SRGBColorSpace;
    texture.wrapS=texture.wrapT=T.RepeatWrapping;texture.anisotropy=4;
    return texture;
  }
  const stone=surface('#eee6d6','stone'),floor=surface('#d8cbbd','floor'),linen=surface('#c5c7b8','linen'),bark=surface('#b2a28a','bark');
  floor.repeat.set(18,12);linen.repeat.set(2,2);
  return {stone,floor,linen,bark};
}
