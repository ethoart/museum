# Museum of Love

A birthday museum for Manika, made for Sadun: a walk-through 3D space for both of your drawings, photographs, sculptures, and shared memories.

An original Roman garden setting with textured travertine arches, small olive trees, wisteria, sage linen seating, candles, a heart sculpture, and floating lights. The painted night sky is an original panorama inspired by Van Gogh’s The Starry Night. The side-gallery hanging walls are 5.6 metres tall with 9.5-metre upper arches and roofs. The sky drifts and shimmers visibly above continuous hills, terraces, reflecting pools, detailed olive trees and cypresses. Soft moonlight, warm gallery lights, mosaic borders, and coordinated interface palettes complete the setting. Light and dark modes can follow the browser or be selected in the header. The admin Appearance tab offers Candlelight, Olive Garden, Moonlight, and Rose Clay palettes. Decorative motion respects reduced-motion preferences. The gentle atmosphere also draws on Sky: Children of the Light; no game assets are used.

## Current status

The visitor experience and protected admin page work locally. The username is `sadun`; its password is configured in the local server environment as a salted hash. The corresponding hosted secret is also saved, pending deployment.

The Supabase account connection is verified. Creating the new museum project is pending the owner’s organization choice and Supabase’s cost confirmation. This workspace has not yet been connected to a museum project. The admin now includes a working local connection form. Until connected, the museum displays seven starter works and the birthday letter. Saving uploads and shared settings is disabled until the project is configured. Colour previews are remembered only in this browser until saved to Supabase.

The website is not published. An AWS deployment package and step-by-step guide are now included. The older Site registration is preserved in `.openai/hosting.json`; it is not used by the AWS installation.

## Host on AWS t3.small

For your preferred **GitHub → npm → PM2 → Cloudflare Tunnel** setup, follow [GITHUB-PM2-CLOUDFLARE.md](GITHUB-PM2-CLOUDFLARE.md). The repository target is `ethoart/museame`. It includes private token entry, automatic startup and your own domain. The files have been prepared and tested locally; GitHub upload and live tunnel deployment are not yet complete.

Follow [AWS-HOSTING.md](AWS-HOSTING.md) for Ubuntu 24.04, Node 24 LTS, Caddy HTTPS, automatic restarts, private server settings and Supabase. Use `museum-of-love-aws.zip` to avoid installing dependencies or building on the 2 GiB server. The full source is in `museum-of-love-source.zip`.

The AWS service runs `scripts/serve-production.mjs`, using a separate Node bundle built by `npm run build`. It streams files, validates the domain and trusted proxy headers, uses secure admin cookies, and disables local setup. Secrets are entered privately on the server and are excluded from both ZIPs. The local preview command remains separate. The production adapter has automated tests; actual Linux/EC2 installation and live Supabase uploads still need deployment verification.

## Visit and curate

- Visitor museum: `/`
- Protected curator room: `/admin`
- Drag to look; W A S D to walk. Arrow keys move and turn. Shift walks faster.
- **Walk inside** enables mouse look; Esc releases it. Click or press E to inspect art.
- Gallery buttons move between three connected rooms. Touch movement buttons appear on small screens.
- The birthday letter is available from the museum header.

Only `/admin` shows creation, editing, file replacement, deletion, and birthday settings. The server independently authorizes every mutation. Signing out revokes the session. Sessions expire after eight hours.

Upload JPG, PNG, WebP, or GLB originals up to 100 MB (100 MiB). A browser worker optimizes them before storage: images are limited to a 2048-pixel longest side and compressed as WebP when useful; GLB models have duplicate data removed, textures resized, and geometry compressed with Meshopt. Color textures use WebP while normal/roughness textures keep lossless channels. Models must embed their resources. Meshopt is supported; Draco and KTX2 models need re-exporting without those codecs. Keep original files separately: the museum stores the optimized version. Images are limited to 64 megapixels and 16,000 pixels per side. There are 36 artwork positions and 5 sculpture plinths: 8 paintings in the main hall and 14 in each side gallery. Display sizes automatically fit the selected wall, with smaller limits near corners and columns. Titles, artists, descriptions, frames, display sizes, placement, and model rotation are editable. Replacing an exhibit preserves its position and removes the old upload after the new one is saved.

Uploads show progress and original/stored sizes. Direct resumable transfers retry brief connection failures without restarting the whole file; leaving the page cancels the current browser session. The server verifies a bounded file header before publishing an exhibit, without buffering a 100 MB upload. Pending files cannot appear as exhibits. Abandoned completed objects are cleaned on a later upload after expiry.

Supabase Free limits each **stored** file to 50 MB. A 100 MB original is accepted if optimization brings it within the project’s limit. Files still above 50 MB require a qualifying paid plan and an increased project-wide storage limit. The 100 MB museum limit does not promise every source model will fit on Free. [Supabase file limits](https://supabase.com/docs/guides/storage/uploads/file-limits).

Visitors can enter while artworks load. Three downloads run at once, starting near the visitor; gallery textures are capped at 1024 pixels to reduce graphics memory, while the detail panel uses the stored image. Uploaded URLs are cached privately for one day and replacements receive fresh URLs.

## Connect Supabase from admin

The Supabase account connection in chat lets the assistant manage projects. It does not automatically give the website its project URL or server key.

1. Open `/admin` and sign in.
2. Select **Connect Supabase** in the storage notice.
3. Create or choose the museum project in Supabase and enter its project URL.
4. Download the setup SQL from the panel, paste it into that project’s SQL Editor, and run it.
5. Copy a **secret server key** from Supabase Settings → API Keys into the private key field. Select the project’s stored-file limit.
6. Select **Connect museum**. The server checks the museum tables, private bucket, and sign-in function, then saves the connection privately in `.env.local`.
7. Sign in again. The new session uses the database; uploads and shared appearance settings become available.

This connection form runs only on the local loopback preview, requires an admin session, validates the destination, refuses redirects, and never returns the key to the visitor application. Public keys cannot be used for this server connection. A failed check leaves the current configuration unchanged. The downloadable setup script also requires admin sign-in. Published sites need private hosting settings configured separately.

## Manual Supabase setup

1. Create a new Supabase project for Museum of Love.
2. Run `supabase/schema.sql` in its SQL editor. This creates the exhibit/settings/session tables, an atomic login limiter, pending upload records, and a private `museum-art` bucket. It also adds the starter works and Manika’s letter. Rerunning the file preserves edited or removed works.
3. Set `SUPABASE_URL` and `SUPABASE_SECRET_KEY` in `.env.local` for local use, and in the hosting server's environment for deployment. On AWS, the included helper writes `/etc/museum/museum.env`. Use a server secret key, never a public browser variable.
4. Set `SUPABASE_MAX_FILE_BYTES=52428800` for Free, or the project-wide limit up to `104857600` on a qualifying paid plan. The bucket configuration alone cannot override the plan limit.
5. Keep `ADMIN_USERNAME=sadun` and the existing `ADMIN_PASSWORD_HASH` environment value. Secrets are deliberately excluded from source archives.
6. Restart the local server or deploy a new hosted version, then verify a real upload, replacement, reload, and removal.

Database and asset-reading requests go through the server; uploads use a short-lived signed token scoped to one file; no privileged Supabase key reaches the browser. The bucket and tables have no anonymous/user mutation policies. The server reads exhibited assets for visitors after checking that the object still belongs to the active collection. Authentication sessions and throttling are shared through Supabase. Before configuration, loopback-only preview sessions are held in memory and expire on server restart.

Official references: [Supabase secret keys](https://supabase.com/docs/guides/getting-started/api-keys), [private buckets](https://supabase.com/docs/guides/storage/buckets/fundamentals), [storage access control](https://supabase.com/docs/guides/storage/security/access-control).

## Appearance and rendering

Use the header’s mode selector for Light, Dark, or System. System follows the browser or operating system; a visitor’s explicit choice stays in their browser. Browser controls and supported browser chrome follow the chosen light/dark mode too. The 3D museum keeps its painted night sky in both modes.

In `/admin` → **Appearance**, palette choices preview immediately in this browser, including other open museum tabs. **Save for all visitors** persists the palette to Supabase. **Reset preview** returns to the museum’s saved palette. The birthday letter and palette can be saved independently.

The glow pipeline now uses up to four supported MSAA samples in its offscreen render targets, with an FXAA fallback on devices that cannot multisample the chosen format. Device pixel ratio is capped at 2 instead of 1.5. This addresses jagged silhouette edges; actual GPU appearance and performance remain subject to browser verification.

## Run the source

Requires Node.js 22.13 or newer.

```sh
npm install
npm run build
npm run dev
```

Open http://127.0.0.1:5173. `npm run start` serves an existing build. The local server loads `.env.local` and uses the same Supabase service as hosting. The portable build bundles React/Three.js and a Cloudflare-compatible Worker directly; the original framework configuration is retained but is not the active build path.

## Verification

```sh
npm run typecheck
npm run test:api
npm run test:garden
npm run test:optimizer
npm run test:setup
npm run test:appearance
npm run test:production
```

The application TypeScript check and production build pass. Garden geometry checks verify all four arches are open, all 41 display viewing positions and gallery corners are reachable with every sculpture plinth occupied at maximum size, and benches and planters have collision boundaries. They also check that maximum-sized artwork frames have wall backing, clear views, and no overlaps. Repeated architectural and planting details are merged or instanced into 57 scene meshes. Sky animation and reduced-motion behavior pass CPU checks. Visual browser inspection was blocked by browser security; the updated walls, smoothing, theme controls, connection form, and upload workflow still need an in-browser review. API integration tests cover authorization, cookie flags, request-origin protection, image/model uploads, file replacement and cleanup, occupied positions, upload rollback, settings, logout revocation, and login throttling. The resumable-upload tests also cover authorization, 100 MB size metadata, bounded verification reads, size/MIME mismatches, cancellation, plan limits, repeat completion, and expired-file cleanup. All 40 principal text/background colour pairs meet a 4.5:1 contrast ratio across the eight palette/mode combinations. Settings tests cover palette updates without changing the birthday letter. Local setup tests cover unauthorized access, request origins, SQL download protection, body limits, rejecting public keys and unsafe destinations, private-bucket checks, sign-in-function checks, preserving the admin account, failed connection rollback, credential replacement, and session renewal. Those tests use a simulated Supabase service; live Supabase and TUS transfer verification remain pending. A representative real GLB fixture shrank from 366,636 to 79,996 bytes (78%) and decoded successfully with the gallery’s Three.js loader. Image tests use a CPU canvas adapter; a transparent 3072 × 1536 PNG became a 2048 × 1024 WebP while retaining transparency. Savings depend on the source file.

Earlier browser checks covered the 3D view, gallery navigation, birthday letter, admin login, settings and model editor, and the absence of editing controls on the visitor route. Public WebMCP tools only list works and navigate galleries; starting uploads is available only in the signed-in admin page. The unused starter combobox has a pre-existing dependency typing mismatch and is outside the museum application check.

## Credits

The five starter paintings come from The Metropolitan Museum of Art’s public-domain Open Access collection under CC0. Source links appear in the artwork panels; metadata is in `public/art/credits.json`. Two Hearts, One Home and Folded Light are original procedural digital studies. Replace these examples with your own drawings and memories in the admin page.

The sky was created with the built-in image generation tool and is saved in `public/textures/starry-night-sky.png`. Its complete generation prompt is recorded in `public/textures/sky-credits.json`. It is an original interpretation, not a reproduction of Van Gogh’s painting.
