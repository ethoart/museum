-- Museum of Love. Run once in the new Supabase project's SQL editor.
-- All data and storage access goes through the museum server.
create table if not exists public.museum_exhibits (
  id text primary key,
  exhibit jsonb not null,
  deleted boolean not null default false,
  slot text generated always as (case when deleted then null else exhibit->>'slot' end) stored unique
);
create table if not exists public.museum_settings (id text primary key, value jsonb not null);
create table if not exists public.museum_uploads (
  id uuid primary key, exhibit_id text not null, metadata jsonb not null,
  previous_url text, expected_size bigint not null check (expected_size between 1 and 104857600),
  original_size bigint not null check (original_size between 1 and 104857600),
  mime text not null, expires_at timestamptz not null
);
create index if not exists museum_uploads_expiry on public.museum_uploads(expires_at);
alter table public.museum_uploads enable row level security;
revoke all on public.museum_uploads from anon,authenticated;
grant all on public.museum_uploads to service_role;
create table if not exists public.museum_sessions (token_hash text primary key, expires_at timestamptz not null);
create index if not exists museum_sessions_expiry on public.museum_sessions(expires_at);
create table if not exists public.museum_login_attempts (client_key text primary key, attempts integer not null, expires_at timestamptz not null);
alter table public.museum_exhibits enable row level security;
alter table public.museum_settings enable row level security;
alter table public.museum_sessions enable row level security;
alter table public.museum_login_attempts enable row level security;
revoke all on public.museum_exhibits,public.museum_settings,public.museum_sessions,public.museum_login_attempts from anon,authenticated;
grant all on public.museum_exhibits,public.museum_settings,public.museum_sessions,public.museum_login_attempts to service_role;

-- Atomic and shared across server instances: eight attempts per IP in 15 minutes.
create or replace function public.museum_allow_login(client_key text) returns boolean
language plpgsql security definer set search_path = '' as $$
declare allowed boolean;
begin
  delete from public.museum_sessions where expires_at < now();
  delete from public.museum_login_attempts where expires_at < now();
  insert into public.museum_login_attempts as quota (client_key,attempts,expires_at)
    values (museum_allow_login.client_key,1,now()+interval '15 minutes')
    on conflict on constraint museum_login_attempts_pkey do update set attempts=quota.attempts+1
    returning quota.attempts <= 8 into allowed;
  return allowed;
end;
$$;
revoke all on function public.museum_allow_login(text) from public,anon,authenticated;
grant execute on function public.museum_allow_login(text) to service_role;

insert into storage.buckets (id,name,public,file_size_limit,allowed_mime_types)
values ('museum-art','museum-art',false,104857600,array['image/jpeg','image/png','image/webp','model/gltf-binary'])
on conflict (id) do update set public=false,file_size_limit=excluded.file_size_limit,allowed_mime_types=excluded.allowed_mime_types;
-- Supabase's project-wide limit also applies. Free plans allow 50 MB stored files;
-- 100 MB originals are optimized before upload. Set the project limit to 100 MB
-- on a qualifying plan if files remain above 50 MB after optimization.

-- Starter works and birthday letter are appended by scripts/prepare-database.mjs.
-- BEGIN INITIAL COLLECTION
insert into public.museum_exhibits (id,exhibit) values ('wheat-field','{"id":"wheat-field","title":"Wheat Field with Cypresses","artist":"Vincent van Gogh","year":"1889","kind":"image","url":"/art/met-436535.jpg","slot":"main-n","size":3.5,"rotation":0,"frame":"oak","source":"https://www.metmuseum.org/art/collection/search/436535","description":"Oil on canvas. From the Open Access collection of The Metropolitan Museum of Art."}'::jsonb) on conflict (id) do nothing;
insert into public.museum_exhibits (id,exhibit) values ('irises','{"id":"irises","title":"Irises","artist":"Vincent van Gogh","year":"1890","kind":"image","url":"/art/met-436528.jpg","slot":"main-w","size":2.8,"rotation":0,"frame":"oak","source":"https://www.metmuseum.org/art/collection/search/436528"}'::jsonb) on conflict (id) do nothing;
insert into public.museum_exhibits (id,exhibit) values ('self-portrait','{"id":"self-portrait","title":"Self-Portrait with a Straw Hat","artist":"Vincent van Gogh","year":"1887","kind":"image","url":"/art/met-436532.jpg","slot":"main-e","size":2.6,"rotation":0,"frame":"oak","source":"https://www.metmuseum.org/art/collection/search/436532"}'::jsonb) on conflict (id) do nothing;
insert into public.museum_exhibits (id,exhibit) values ('vase-flowers','{"id":"vase-flowers","title":"A Woman Seated beside a Vase of Flowers","artist":"Edgar Degas","year":"1865","kind":"image","url":"/art/met-436121.jpg","slot":"west-n","size":3.2,"rotation":0,"frame":"black","source":"https://www.metmuseum.org/art/collection/search/436121"}'::jsonb) on conflict (id) do nothing;
insert into public.museum_exhibits (id,exhibit) values ('circus-sideshow','{"id":"circus-sideshow","title":"Circus Sideshow (Parade de cirque)","artist":"Georges Seurat","year":"1887–88","kind":"image","url":"/art/met-437654.jpg","slot":"east-n","size":3.5,"rotation":0,"frame":"black","source":"https://www.metmuseum.org/art/collection/search/437654"}'::jsonb) on conflict (id) do nothing;
insert into public.museum_exhibits (id,exhibit) values ('infinite-form','{"id":"infinite-form","title":"Two Hearts, One Home","artist":"Museum of Love","year":"2026","kind":"model","url":"","slot":"plinth-main","size":2.5,"rotation":0,"frame":"oak","builtin":"knot","description":"Two original intertwined hearts in warm gold. A little reminder that our stories belong together."}'::jsonb) on conflict (id) do nothing;
insert into public.museum_exhibits (id,exhibit) values ('folded-light','{"id":"folded-light","title":"Folded Light","artist":"Museum of Love","year":"2026","kind":"model","url":"","slot":"plinth-east","size":2.1,"rotation":25,"frame":"oak","builtin":"ribbon","description":"An original digital sculpture exploring light and a continuous, folded surface."}'::jsonb) on conflict (id) do nothing;
insert into public.museum_settings (id,value) values ('birthday','{"recipient":"Manika","greeting":"Happy birthday, my love.","message":"Manika, some feelings become words, some become drawings, and some become the memories we keep forever. This little museum is for all of them.\n\nFor the worlds you draw, the things I try to capture on paper, and the love we make together, one ordinary, beautiful day at a time. Your art lets me see the world through your eyes. Loving you has made my own world more beautiful.\n\nMay every room remind you how deeply you are loved. Here is to more drawings, more adventures, and a lifetime of memories still waiting to become our art.","signature":"With all my love, Sadun","palette":"candlelight"}'::jsonb) on conflict (id) do nothing;
